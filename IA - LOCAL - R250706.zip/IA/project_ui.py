# project_ui.py
import streamlit as st
import pandas as pd
from datetime import datetime, date, timedelta
from typing import Dict, List
from project_manager import ProjectManager
import plotly.express as px
import plotly.graph_objects as go
import calendar
import time  # Pour les délais dans les fonctions IA

class ProjectUI:
    """Interface utilisateur pour le gestionnaire de projet."""
    
    def __init__(self, project_manager: ProjectManager):
        self.pm = project_manager
        
        # Initialiser les variables de session si nécessaire
        if 'current_project_id' not in st.session_state:
            st.session_state.current_project_id = None
        if 'project_view_mode' not in st.session_state:
            st.session_state.project_view_mode = 'dashboard'
        # NOUVEAU : Pour le calendrier
        if 'calendar_date' not in st.session_state:
            st.session_state.calendar_date = date.today()
        if 'selected_calendar_day' not in st.session_state:
            st.session_state.selected_calendar_day = None

    
    def render_project_section(self):
        """Rend la section complète de gestion de projet."""
        
        st.markdown("""
        <div class="project-header">
            <h2>📁 Gestionnaire de Projet Construction</h2>
        </div>
        """, unsafe_allow_html=True)
        
        # Menu de navigation principal - AJOUT DE KANBAN ET CALENDRIER
        cols = st.columns(8)
        
        with cols[0]:
            if st.button("🏠 Tableau de Bord", use_container_width=True):
                st.session_state.project_view_mode = 'dashboard'
                st.rerun()
        
        with cols[1]:
            if st.button("📋 Projets", use_container_width=True):
                st.session_state.project_view_mode = 'projects'
                st.rerun()
        
        with cols[2]:
            if st.button("✅ Tâches", use_container_width=True):
                st.session_state.project_view_mode = 'tasks'
                st.rerun()

        with cols[3]:
            if st.button("🧮 Kanban", use_container_width=True):
                st.session_state.project_view_mode = 'kanban'
                st.rerun()
        
        with cols[4]:
            if st.button("📅 Calendrier", use_container_width=True):
                st.session_state.project_view_mode = 'calendar'
                st.rerun()

        with cols[5]:
            if st.button("📊 Gantt", use_container_width=True):
                st.session_state.project_view_mode = 'gantt'
                st.rerun()

        with cols[6]:
            if st.button("📈 Rapports", use_container_width=True):
                st.session_state.project_view_mode = 'reports'
                st.rerun()

        with cols[7]:
            if st.button("➕ Nouveau Projet", use_container_width=True):
                st.session_state.project_view_mode = 'new_project'
                st.rerun()
       
        st.divider()
        
        # Rendu selon le mode sélectionné
        if st.session_state.project_view_mode == 'dashboard':
            self.render_dashboard()
        elif st.session_state.project_view_mode == 'projects':
            self.render_projects_list()
        elif st.session_state.project_view_mode == 'tasks':
            self.render_tasks_view()
        elif st.session_state.project_view_mode == 'kanban':
            self.render_kanban_view()
        elif st.session_state.project_view_mode == 'calendar':
            self.render_calendar_view()
        elif st.session_state.project_view_mode == 'reports':
            self.render_reports()
        elif st.session_state.project_view_mode == 'new_project':
            self.render_new_project_form()
        elif st.session_state.project_view_mode == 'project_detail':
            self.render_project_detail()
        elif st.session_state.project_view_mode == 'gantt':
            self.render_global_gantt_view()
    
    def render_dashboard(self):
        """Affiche le tableau de bord principal avec insights IA."""
        st.markdown("### 🏠 Tableau de Bord")
        
        # Récupérer les statistiques
        summary = self.pm.get_dashboard_summary()
        
        if not summary:
            st.info("Aucune donnée disponible. Créez votre premier projet pour commencer !")
            return
        
        # Métriques principales
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                "Projets Totaux", 
                summary['projects'].get('total_projects', 0),
                delta=f"{summary['projects'].get('active_projects', 0)} actifs"
            )
        
        with col2:
            st.metric(
                "Projets Terminés", 
                summary['projects'].get('completed_projects', 0)
            )
        
        with col3:
            st.metric(
                "Tâches Totales", 
                summary['tasks'].get('total_tasks', 0),
                delta=f"{summary['tasks'].get('active_tasks', 0)} actives"
            )
        
        with col4:
            budget_total = summary['projects'].get('total_budget_current', 0)
            st.metric(
                "Budget Total", 
                f"{budget_total:,.0f} $"
            )
        
        st.divider()
        
        # === NOUVELLE SECTION : INSIGHTS IA ===
        self.render_dashboard_ai_insights()
        
        st.divider()
        
        # Graphiques (section existante)
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### Répartition des Projets par Statut")
            if summary['projects'].get('total_projects', 0) > 0:
                statuses = ['En cours', 'Terminé', 'En planification']
                values = [
                    summary['projects'].get('active_projects', 0),
                    summary['projects'].get('completed_projects', 0),
                    summary['projects'].get('planning_projects', 0)
                ]
                
                fig = px.pie(
                    values=values,
                    names=statuses,
                    color_discrete_sequence=['#3B82F6', '#22C55E', '#F59E0B']
                )
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Aucun projet à afficher")
        
        with col2:
            st.markdown("#### Projets Récents")
            recent_projects = summary.get('recent_projects', [])
            if recent_projects:
                for project in recent_projects:
                    status_color = {
                        'En cours': '🟢',
                        'Terminé': '✅',
                        'En planification': '🟡',
                        'En attente': '🔴'
                    }.get(project['status'], '⚫')
                    
                    st.markdown(f"""
                    <div class="project-card" style="margin-bottom: 10px; padding: 10px; border-left: 4px solid #3B82F6;">
                        <strong>{status_color} {project['name']}</strong><br>
                        <small>Statut: {project['status']} • Mis à jour: {project['updated_at'][:10]}</small>
                    </div>
                    """, unsafe_allow_html=True)
            else:
                st.info("Aucun projet récent")
        
        # Tâches urgentes (section existante)
        st.markdown("#### 🚨 Tâches Urgentes")
        urgent_tasks = summary.get('urgent_tasks', [])
        if urgent_tasks:
            for task in urgent_tasks:
                st.markdown(f"""
                <div class="info-card" style="background: #FEF2F2; border-left: 4px solid #EF4444;">
                    <strong>⏰ {task['name']}</strong><br>
                    <small>Projet: {task['project_name']} • Échéance: {task['end_date_planned']}</small>
                </div>
                """, unsafe_allow_html=True)
        else:
            st.success("✅ Aucune tâche urgente")
    
    def render_projects_list(self):
        """Affiche la liste des projets."""
        st.markdown("### 📋 Gestion des Projets")
        
        # Filtres
        col1, col2 = st.columns([3, 1])
        
        with col1:
            status_filter = st.selectbox(
                "Filtrer par statut:",
                ["Tous", "En planification", "En cours", "Terminé", "En attente"],
                key="project_status_filter"
            )
        
        with col2:
            if st.button("🔄 Actualiser", use_container_width=True):
                st.rerun()
        
        # Récupérer les projets
        if status_filter == "Tous":
            projects = self.pm.list_projects()
        else:
            projects = self.pm.list_projects(status_filter=status_filter)
        
        if not projects:
            st.info("Aucun projet trouvé. Créez votre premier projet !")
            return
        
        # Affichage des projets sous forme de cartes
        for project in projects:
            with st.container():
                col1, col2, col3 = st.columns([6, 2, 2])
                
                with col1:
                    st.markdown(f"""
                    <div class="project-card">
                        <h4>🏗️ {project['name']}</h4>
                        <p><strong>Client:</strong> {project['client_name'] or 'Non spécifié'}</p>
                        <p><strong>Type:</strong> {project['project_type']} • <strong>Ville:</strong> {project['city'] or 'Non spécifiée'}</p>
                        <p><strong>Budget:</strong> {project['budget_current']:,.0f} $ • <strong>Statut:</strong> 
                        <span style="color: {'#22C55E' if project['status'] == 'Terminé' else '#3B82F6' if project['status'] == 'En cours' else '#F59E0B'};">
                        {project['status']}</span></p>
                        <small>Créé: {project['created_at'][:10]} • Mis à jour: {project['updated_at'][:10]}</small>
                    </div>
                    """, unsafe_allow_html=True)
                
                with col2:
                    if st.button("👁️ Voir", key=f"view_project_{project['id']}", use_container_width=True):
                        st.session_state.current_project_id = project['id']
                        st.session_state.project_view_mode = 'project_detail'
                        st.rerun()
                
                with col3:
                    if st.button("🗑️ Supprimer", key=f"delete_project_{project['id']}", use_container_width=True):
                        if st.session_state.get(f'confirm_delete_{project["id"]}', False):
                            self.pm.delete_project(project['id'])
                            st.success(f"Projet '{project['name']}' supprimé.")
                            st.rerun()
                        else:
                            st.session_state[f'confirm_delete_{project["id"]}'] = True
                            st.warning("Cliquez à nouveau pour confirmer la suppression.")
                
                st.divider()
    
    def render_project_detail(self):
        """Affiche les détails d'un projet spécifique. [MODIFIÉE POUR AJOUTER L'ONGLET IA]"""
        if not st.session_state.current_project_id:
            st.error("Aucun projet sélectionné.")
            return
        
        project = self.pm.get_project(st.session_state.current_project_id)
        if not project:
            st.error("Projet non trouvé.")
            return
        
        # En-tête du projet
        col1, col2 = st.columns([6, 2])
        
        with col1:
            st.markdown(f"### 🏗️ {project['name']}")
            
        with col2:
            if st.button("⬅️ Retour aux Projets", use_container_width=True):
                st.session_state.project_view_mode = 'projects'
                st.rerun()
        
        # Onglets pour les différentes sections - AJOUT DE L'ONGLET IA
        tab1, tab2, tab3, tab4, tab5 = st.tabs(["📋 Détails", "✅ Tâches", "🤖 Analyses IA", "📊 Statistiques", "📝 Notes"])
        
        with tab1:
            self.render_project_details_tab(project)
        
        with tab2:
            self.render_project_tasks_tab(project['id'])
        
        with tab3:
            self.render_project_ai_analysis_tab(project['id'])  # NOUVELLE FONCTION
        
        with tab4:
            self.render_project_statistics_tab(project['id'])
        
        with tab5:
            self.render_project_notes_tab(project['id'])
    
    def render_project_details_tab(self, project: Dict):
        """Onglet des détails du projet."""
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 📋 Informations Générales")
            st.text_input("Nom du projet", value=project['name'], key="edit_project_name")
            st.text_input("Client", value=project['client_name'], key="edit_client_name")
            st.text_input("Contact client", value=project['client_contact'], key="edit_client_contact")
            st.selectbox("Type de projet", 
                        ["Résidentiel", "Commercial", "Industriel", "Infrastructure"], 
                        index=["Résidentiel", "Commercial", "Industriel", "Infrastructure"].index(project['project_type']) 
                        if project['project_type'] in ["Résidentiel", "Commercial", "Industriel", "Infrastructure"] else 0,
                        key="edit_project_type")
        
        with col2:
            st.markdown("#### 📍 Localisation et Dates")
            st.text_input("Adresse", value=project['address'], key="edit_address")
            st.text_input("Ville", value=project['city'], key="edit_city")
            st.text_input("Code postal", value=project['postal_code'], key="edit_postal_code")
            
            # Dates
            start_date = None
            if project['start_date']:
                try:
                    start_date = datetime.fromisoformat(project['start_date']).date()
                except:
                    pass
            
            st.date_input("Date de début", value=start_date, key="edit_start_date")
        
        # Section budget et statut
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 💰 Budget")
            st.number_input("Budget initial ($)", value=float(project['budget_initial']), key="edit_budget_initial")
            st.number_input("Budget actuel ($)", value=float(project['budget_current']), key="edit_budget_current")
        
        with col2:
            st.markdown("#### 📊 Statut et Priorité")
            st.selectbox("Statut", 
                        ["En planification", "En cours", "Terminé", "En attente"],
                        index=["En planification", "En cours", "Terminé", "En attente"].index(project['status'])
                        if project['status'] in ["En planification", "En cours", "Terminé", "En attente"] else 0,
                        key="edit_status")
            st.selectbox("Priorité",
                        ["Faible", "Moyenne", "Élevée", "Critique"],
                        index=["Faible", "Moyenne", "Élevée", "Critique"].index(project['priority'])
                        if project['priority'] in ["Faible", "Moyenne", "Élevée", "Critique"] else 1,
                        key="edit_priority")
        
        # Description
        st.markdown("#### 📝 Description")
        st.text_area("Description du projet", value=project['description'], key="edit_description", height=100)
        
        # Bouton de sauvegarde
        if st.button("💾 Sauvegarder les Modifications", use_container_width=True):
            updates = {
                'name': st.session_state.edit_project_name,
                'client_name': st.session_state.edit_client_name,
                'client_contact': st.session_state.edit_client_contact,
                'project_type': st.session_state.edit_project_type,
                'address': st.session_state.edit_address,
                'city': st.session_state.edit_city,
                'postal_code': st.session_state.edit_postal_code,
                'budget_initial': st.session_state.edit_budget_initial,
                'budget_current': st.session_state.edit_budget_current,
                'status': st.session_state.edit_status,
                'priority': st.session_state.edit_priority,
                'description': st.session_state.edit_description,
                'start_date': st.session_state.edit_start_date.isoformat() if st.session_state.edit_start_date else ''
            }
            
            if self.pm.update_project(project['id'], updates):
                st.success("Projet mis à jour avec succès !")
                st.rerun()
            else:
                st.error("Erreur lors de la mise à jour du projet.")
    
    def render_project_tasks_tab(self, project_id: int):
        """Onglet de gestion des tâches."""
        st.markdown("#### ✅ Gestion des Tâches")
        
        # Formulaire d'ajout de tâche
        with st.expander("➕ Ajouter une nouvelle tâche"):
            task_name = st.text_input("Nom de la tâche", key="new_task_name")
            task_description = st.text_area("Description", key="new_task_description")
            
            col1, col2, col3 = st.columns(3)
            with col1:
                task_status = st.selectbox("Statut", ["À faire", "En cours", "Terminé"], key="new_task_status")
                task_priority = st.selectbox("Priorité", ["Faible", "Moyenne", "Élevée", "Critique"], key="new_task_priority")
            
            with col2:
                task_assigned = st.text_input("Assigné à", key="new_task_assigned")
                task_hours = st.number_input("Heures estimées", min_value=0.0, key="new_task_hours")
            
            with col3:
                task_cost = st.number_input("Coût estimé ($)", min_value=0.0, key="new_task_cost")
                task_end_date = st.date_input("Date de fin prévue", key="new_task_end_date")
            
            if st.button("➕ Créer la Tâche", use_container_width=True):
                if task_name:
                    task_data = {
                        'name': task_name,
                        'description': task_description,
                        'status': task_status,
                        'priority': task_priority,
                        'assigned_to': task_assigned,
                        'estimated_hours': task_hours,
                        'estimated_cost': task_cost,
                        'end_date_planned': task_end_date.isoformat() if task_end_date else ''
                    }
                    
                    try:
                        self.pm.create_task(project_id, task_data)
                        st.success("Tâche créée avec succès !")
                        st.rerun()
                    except Exception as e:
                        st.error(f"Erreur lors de la création de la tâche: {e}")
                else:
                    st.warning("Le nom de la tâche est requis.")
        
        # Liste des tâches existantes
        tasks = self.pm.get_project_tasks(project_id)
        
        if tasks:
            st.markdown("#### 📋 Tâches Existantes")
            
            # Statistiques rapides
            total_tasks = len(tasks)
            completed_tasks = sum(1 for task in tasks if task['status'] == 'Terminé')
            progress = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
            
            st.progress(progress / 100)
            st.caption(f"Progression: {completed_tasks}/{total_tasks} tâches terminées ({progress:.1f}%)")
            
            # Affichage des tâches
            for task in tasks:
                with st.container():
                    col1, col2, col3 = st.columns([6, 2, 2])
                    
                    with col1:
                        status_icon = {
                            'À faire': '⏳',
                            'En cours': '🔄',
                            'Terminé': '✅'
                        }.get(task['status'], '⚫')
                        
                        priority_color = {
                            'Faible': '#22C55E',
                            'Moyenne': '#3B82F6',
                            'Élevée': '#F59E0B',
                            'Critique': '#EF4444'
                        }.get(task['priority'], '#6B7280')
                        
                        st.markdown(f"""
                        <div class="project-card">
                            <h5>{status_icon} {task['name']}</h5>
                            <p>{task['description'] or 'Aucune description'}</p>
                            <p><strong>Priorité:</strong> 
                            <span style="color: {priority_color}; font-weight: bold;">{task['priority']}</span> • 
                            <strong>Assigné à:</strong> {task['assigned_to'] or 'Non assigné'}</p>
                            <p><strong>Estimation:</strong> {task['estimated_hours']}h, {task['estimated_cost']:,.0f}$ • 
                            <strong>Échéance:</strong> {task['end_date_planned'] or 'Non définie'}</p>
                        </div>
                        """, unsafe_allow_html=True)
                    
                    with col2:
                        new_status = st.selectbox(
                            "Statut",
                            ["À faire", "En cours", "Terminé"],
                            index=["À faire", "En cours", "Terminé"].index(task['status']),
                            key=f"task_status_{task['id']}"
                        )
                        
                        if new_status != task['status']:
                            if st.button("💾", key=f"update_task_{task['id']}"):
                                self.pm.update_task(task['id'], {'status': new_status})
                                st.success("Statut mis à jour !")
                                st.rerun()
                    
                    with col3:
                        if st.button("🗑️", key=f"delete_task_{task['id']}"):
                            self.pm.delete_task(task['id'])
                            st.success("Tâche supprimée !")
                            st.rerun()
                
                st.divider()
        else:
            st.info("Aucune tâche créée pour ce projet.")
    
    def render_project_ai_analysis_tab(self, project_id: int):
        """Nouvel onglet d'analyse IA pour un projet spécifique."""
        st.markdown("#### 🤖 Analyses IA du Projet")
        
        # Bouton pour lancer l'analyse
        col1, col2, col3 = st.columns([2, 1, 1])
        
        with col1:
            if st.button("🔬 Lancer Analyse IA Complète", use_container_width=True, type="primary"):
                self.perform_project_ai_analysis(project_id)
        
        with col2:
            analysis_type = st.selectbox(
                "Type d'analyse:",
                ["Complète", "Budget", "Délais", "Qualité", "Risques"],
                key="ai_analysis_type"
            )
        
        with col3:
            if st.button("💡 Insights Rapides", use_container_width=True):
                self.show_quick_insights(project_id)
        
        st.divider()
        
        # Affichage des insights automatiques (sans IA externe)
        try:
            quick_insights = self.pm.get_project_ai_insights(project_id)
            
            if quick_insights['alerts']:
                st.markdown("#### ⚠️ Alertes Importantes")
                for alert in quick_insights['alerts']:
                    severity_colors = {
                        'high': '#EF4444',
                        'medium': '#F59E0B', 
                        'low': '#22C55E'
                    }
                    color = severity_colors.get(alert['severity'], '#6B7280')
                    
                    st.markdown(f"""
                    <div style="background: linear-gradient(to right, {color}15, {color}08); 
                               border-left: 4px solid {color}; padding: 12px; margin-bottom: 8px; border-radius: 6px;">
                        <strong style="color: {color};">{alert['type'].upper()}</strong><br>
                        {alert['message']}
                    </div>
                    """, unsafe_allow_html=True)
            
            if quick_insights['recommendations']:
                st.markdown("#### 💡 Recommandations")
                for rec in quick_insights['recommendations']:
                    priority_colors = {
                        'high': '#DC2626',
                        'medium': '#D97706',
                        'low': '#059669'
                    }
                    color = priority_colors.get(rec['priority'], '#6B7280')
                    
                    st.markdown(f"""
                    <div style="background: linear-gradient(to right, #F0F7FF, #E6F3FF); 
                               border-left: 4px solid {color}; padding: 12px; margin-bottom: 8px; border-radius: 6px;">
                        <strong style="color: {color};">PRIORITÉ {rec['priority'].upper()}</strong> - {rec['category']}<br>
                        {rec['action']}
                    </div>
                    """, unsafe_allow_html=True)
            
            if quick_insights['insights']:
                st.markdown("#### 📊 Insights")
                for insight in quick_insights['insights']:
                    st.markdown(f"""
                    <div style="background: linear-gradient(to right, #F0FDF4, #E6F7EC); 
                               border-left: 4px solid #22C55E; padding: 12px; margin-bottom: 8px; border-radius: 6px;">
                        <strong>{insight['type'].upper()}</strong><br>
                        {insight['message']}<br>
                        <em style="color: #059669;">{insight['suggestion']}</em>
                    </div>
                    """, unsafe_allow_html=True)
            
            if not any([quick_insights['alerts'], quick_insights['recommendations'], quick_insights['insights']]):
                st.info("✅ Aucun problème détecté. Projet sur la bonne voie !")
                
        except Exception as e:
            st.error(f"Erreur lors de la génération des insights: {e}")
        
        # Section résultats d'analyse IA (si disponible)
        if f'ai_analysis_result_{project_id}' in st.session_state:
            st.markdown("#### 🎯 Analyse IA Détaillée")
            
            analysis_result = st.session_state[f'ai_analysis_result_{project_id}']
            
            # Affichage du résultat avec style
            st.markdown("""
            <div style="background: linear-gradient(to right, #F8FAFF, #FFFFFF); 
                       border: 1px solid #DBEAFE; border-radius: 12px; padding: 20px; margin: 15px 0;">
            """, unsafe_allow_html=True)
            
            st.markdown(analysis_result)
            
            st.markdown("</div>", unsafe_allow_html=True)
            
            # Boutons d'action
            col1, col2 = st.columns(2)
            with col1:
                if st.button("💾 Sauvegarder Analyse", key=f"save_analysis_{project_id}"):
                    self.save_ai_analysis_to_notes(project_id, analysis_result)
            
            with col2:
                if st.button("🗑️ Effacer Résultat", key=f"clear_analysis_{project_id}"):
                    del st.session_state[f'ai_analysis_result_{project_id}']
                    st.rerun()

    def perform_project_ai_analysis(self, project_id: int):
        """Lance une analyse IA complète du projet."""
        try:
            # Récupérer les données du projet
            project_data = self.pm.get_project_ai_analysis_data(project_id)
            
            if not project_data:
                st.error("Impossible de récupérer les données du projet pour l'analyse.")
                return
            
            # Accéder à l'expert advisor depuis st.session_state
            if 'expert_advisor' not in st.session_state:
                st.error("Expert IA non disponible.")
                return
            
            expert_advisor = st.session_state.expert_advisor
            
            # Sauvegarder le profil actuel
            current_profile = expert_advisor.get_current_profile()
            current_profile_name = current_profile.get('name', '') if current_profile else ''
            
            # Changer vers le profil Analyste IA
            profile_changed = expert_advisor.set_current_profile_by_name("Analyste Projet IA - Expert Construction Québec")
            
            if not profile_changed:
                st.warning("Profil Analyste IA non trouvé. Utilisation du profil actuel.")
            
            with st.spinner("🤖 Analyse IA en cours... Cela peut prendre quelques instants."):
                # Préparer le prompt d'analyse
                analysis_prompt = self.prepare_analysis_prompt(project_data)
                
                # Lancer l'analyse IA
                analysis_result = expert_advisor.obtenir_reponse(analysis_prompt, [])
                
                # Stocker le résultat
                st.session_state[f'ai_analysis_result_{project_id}'] = analysis_result
                
                st.success("✅ Analyse IA terminée !")
            
            # Restaurer le profil original si on l'avait changé
            if profile_changed and current_profile_name:
                expert_advisor.set_current_profile_by_name(current_profile_name)
            
            st.rerun()
            
        except Exception as e:
            st.error(f"Erreur lors de l'analyse IA: {e}")
            st.exception(e)

    def prepare_analysis_prompt(self, project_data: Dict) -> str:
        """Prépare le prompt d'analyse pour l'IA."""
        project = project_data['project']
        stats = project_data['statistics']
        tasks = project_data['tasks']
        
        # Construction du prompt structuré
        prompt = f"""
DEMANDE D'ANALYSE IA COMPLÈTE - PROJET DE CONSTRUCTION

📋 **INFORMATIONS PROJET**
- Nom: {project['name']}
- Type: {project['project_type']}
- Client: {project.get('client_name', 'Non spécifié')}
- Statut: {project['status']}
- Priorité: {project['priority']}

💰 **DONNÉES BUDGÉTAIRES**
- Budget initial: {project['budget_initial']:,.0f} $
- Budget actuel: {project['budget_current']:,.0f} $
- Écart budgétaire: {project['budget_current'] - project['budget_initial']:,.0f} $ ({((project['budget_current'] - project['budget_initial']) / project['budget_initial'] * 100) if project['budget_initial'] > 0 else 0:.1f}%)

📊 **STATISTIQUES GÉNÉRALES**
- Tâches totales: {stats.get('total_tasks', 0)}
- Tâches terminées: {stats.get('completed_tasks', 0)}
- Progression: {stats.get('completion_percentage', 0):.1f}%
- Heures estimées totales: {stats.get('total_estimated_hours', 0):.1f}h
- Coût estimé total des tâches: {stats.get('total_estimated_cost', 0):,.0f} $

📅 **DONNÉES TEMPORELLES**
- Date début: {project.get('start_date', 'Non définie')}
- Date fin prévue: {project.get('end_date_planned', 'Non définie')}

✅ **DÉTAIL DES TÂCHES** ({len(tasks)} tâches)
"""
        
        # Ajouter le détail des tâches problématiques
        problematic_tasks = []
        for task in tasks:
            issues = []
            if task['status'] == 'En cours' and task.get('end_date_planned'):
                from datetime import datetime, date
                try:
                    end_date = datetime.fromisoformat(task['end_date_planned']).date()
                    if end_date < date.today():
                        issues.append("EN RETARD")
                except:
                    pass
            
            if task.get('actual_cost', 0) > task.get('estimated_cost', 0) * 1.1:
                issues.append("DÉPASSEMENT COÛT")
            
            if task.get('actual_hours', 0) > task.get('estimated_hours', 0) * 1.2:
                issues.append("DÉPASSEMENT TEMPS")
            
            if issues:
                problematic_tasks.append(f"- {task['name']} ({task['status']}) - PROBLÈMES: {', '.join(issues)}")
        
        if problematic_tasks:
            prompt += "\n🚨 **TÂCHES PROBLÉMATIQUES IDENTIFIÉES:**\n" + "\n".join(problematic_tasks)
        
        prompt += f"""

🎯 **DEMANDE D'ANALYSE**

En tant qu'Analyste Projet IA spécialisé en construction québécoise, effectue une analyse complète et détaillée de ce projet. Fournis:

1. **DIAGNOSTIC GÉNÉRAL** - État global du projet et conformité aux standards

2. **ANALYSE BUDGÉTAIRE** - Écarts, risques, optimisations possibles

3. **ANALYSE TEMPORELLE** - Retards, goulots d'étranglement, prédictions

4. **ANALYSE QUALITÉ & CONFORMITÉ** - Vérifications RBQ/CCQ, recommandations

5. **IDENTIFICATION DES RISQUES** - Risques immédiats et à moyen terme

6. **RECOMMANDATIONS PRIORITAIRES** - Actions concrètes hiérarchisées

7. **PLAN D'ACTION** - Étapes spécifiques pour optimiser le projet

Sois précis, actionnable et adapte tes recommandations au contexte québécois. Utilise tes connaissances spécialisées pour des conseils pertinents selon le type de projet ({project['project_type']}).
"""
        
        return prompt

    def show_quick_insights(self, project_id: int):
        """Affiche les insights rapides sans IA externe."""
        with st.spinner("Génération des insights..."):
            insights = self.pm.get_project_ai_insights(project_id)
            
            if insights:
                st.success("Insights générés avec succès !")
                time.sleep(1)  # Petit délai pour l'effet
                st.rerun()
            else:
                st.warning("Aucun insight particulier à signaler.")

    def save_ai_analysis_to_notes(self, project_id: int, analysis_content: str):
        """Sauvegarde l'analyse IA comme note de projet."""
        try:
            self.pm.add_note(
                project_id=project_id,
                content=f"**ANALYSE IA AUTOMATIQUE**\n\n{analysis_content}",
                note_type="analysis",
                author="Analyste IA"
            )
            st.success("✅ Analyse sauvegardée dans les notes du projet.")
            time.sleep(1)
            st.rerun()
        except Exception as e:
            st.error(f"Erreur lors de la sauvegarde: {e}")

    def render_dashboard_ai_insights(self):
        """Ajoute une section d'insights IA au tableau de bord."""
        st.markdown("#### 🤖 Insights IA Globaux")
        
        try:
            # Bouton pour analyse globale
            if st.button("🔬 Analyse IA de Tous les Projets", use_container_width=True):
                self.perform_global_ai_analysis()
            
            # Affichage des insights globaux (version simple)
            global_data = self.pm.get_global_ai_analysis_data()
            
            if global_data and global_data.get('projects_analysis'):
                projects = global_data['projects_analysis']
                
                # Calculs d'insights automatiques
                total_projects = len(projects)
                active_projects = len([p for p in projects if p['status'] == 'En cours'])
                
                if total_projects > 0:
                    # Projets avec problèmes budgétaires
                    budget_issues = []
                    for project in projects:
                        if project['budget_initial'] > 0:
                            variance_pct = (project['budget_current'] - project['budget_initial']) / project['budget_initial'] * 100
                            if abs(variance_pct) > 15:
                                budget_issues.append({
                                    'name': project['name'],
                                    'variance': variance_pct
                                })
                    
                    if budget_issues:
                        st.warning(f"⚠️ {len(budget_issues)} projet(s) avec écarts budgétaires significatifs")
                        for issue in budget_issues[:3]:  # Afficher max 3
                            sign = "+" if issue['variance'] > 0 else ""
                            st.caption(f"• {issue['name']}: {sign}{issue['variance']:.1f}%")
                    
                    # Projets nécessitant attention
                    attention_needed = [p for p in projects if p['status'] == 'En cours' and p['completed_tasks'] == 0]
                    if attention_needed:
                        st.info(f"💡 {len(attention_needed)} projet(s) actifs sans tâches terminées - Vérifier progression")
                    
                    if not budget_issues and not attention_needed:
                        st.success("✅ Tous les projets semblent sur la bonne voie !")
            
            # Affichage du résultat d'analyse globale si disponible
            if 'global_ai_analysis_result' in st.session_state:
                st.markdown("#### 🎯 Analyse Globale Détaillée")
                
                with st.expander("Voir l'analyse complète", expanded=True):
                    st.markdown(st.session_state['global_ai_analysis_result'])
                
                if st.button("🗑️ Effacer Analyse Globale"):
                    del st.session_state['global_ai_analysis_result']
                    st.rerun()
            
        except Exception as e:
            st.error(f"Erreur lors de la génération des insights globaux: {e}")

    def perform_global_ai_analysis(self):
        """Lance une analyse IA globale de tous les projets."""
        try:
            # Récupérer les données globales
            global_data = self.pm.get_global_ai_analysis_data()
            
            if not global_data:
                st.error("Impossible de récupérer les données pour l'analyse globale.")
                return
            
            # Accéder à l'expert advisor
            if 'expert_advisor' not in st.session_state:
                st.error("Expert IA non disponible.")
                return
            
            expert_advisor = st.session_state.expert_advisor
            
            # Changer vers le profil Analyste IA
            current_profile = expert_advisor.get_current_profile()
            current_profile_name = current_profile.get('name', '') if current_profile else ''
            
            profile_changed = expert_advisor.set_current_profile_by_name("Analyste Projet IA - Expert Construction Québec")
            
            with st.spinner("🤖 Analyse IA globale en cours..."):
                # Préparer le prompt d'analyse globale
                global_prompt = self.prepare_global_analysis_prompt(global_data)
                
                # Lancer l'analyse IA
                analysis_result = expert_advisor.obtenir_reponse(global_prompt, [])
                
                # Stocker le résultat
                st.session_state['global_ai_analysis_result'] = analysis_result
                
                st.success("✅ Analyse IA globale terminée !")
            
            # Restaurer le profil original
            if profile_changed and current_profile_name:
                expert_advisor.set_current_profile_by_name(current_profile_name)
            
            st.rerun()
            
        except Exception as e:
            st.error(f"Erreur lors de l'analyse IA globale: {e}")

    def prepare_global_analysis_prompt(self, global_data: Dict) -> str:
        """Prépare le prompt pour l'analyse globale."""
        dashboard = global_data.get('dashboard_summary', {})
        projects = global_data.get('projects_analysis', [])
        
        prompt = f"""
DEMANDE D'ANALYSE IA GLOBALE - PORTEFEUILLE DE PROJETS CONSTRUCTION

📊 **VUE D'ENSEMBLE**
- Projets totaux: {dashboard.get('projects', {}).get('total_projects', 0)}
- Projets actifs: {dashboard.get('projects', {}).get('active_projects', 0)}
- Projets terminés: {dashboard.get('projects', {}).get('completed_projects', 0)}
- Budget total portfolio: {dashboard.get('projects', {}).get('total_budget_current', 0):,.0f} $

📋 **DÉTAIL DES PROJETS**
"""
        
        for project in projects[:10]:  # Limiter à 10 projets pour éviter un prompt trop long
            completion_pct = (project['completed_tasks'] / project['task_count'] * 100) if project['task_count'] > 0 else 0
            budget_variance = project['budget_current'] - project['budget_initial']
            
            prompt += f"""
- **{project['name']}** ({project['project_type']})
  Status: {project['status']} | Priorité: {project['priority']}
  Budget: {project['budget_current']:,.0f}$ (écart: {budget_variance:+,.0f}$)
  Progression: {completion_pct:.1f}% ({project['completed_tasks']}/{project['task_count']} tâches)
"""
        
        prompt += """

🎯 **DEMANDE D'ANALYSE GLOBALE**

En tant qu'Analyste Projet IA, effectue une analyse strategique de ce portefeuille de projets. Fournis:

1. **ÉTAT GÉNÉRAL DU PORTEFEUILLE** - Santé globale et tendances

2. **ANALYSE COMPARATIVE** - Performance relative des projets

3. **IDENTIFICATION DES PATTERNS** - Problèmes récurrents ou opportunités

4. **ANALYSE DES RISQUES PORTFOLIO** - Risques systémiques et concentrations

5. **RECOMMANDATIONS STRATÉGIQUES** - Optimisations au niveau portfolio

6. **PRIORITÉS D'ACTION** - Projets nécessitant attention immédiate

Sois stratégique et actionnable. Focus sur la vue d'ensemble et les optimisations organisationnelles.
"""
        
        return prompt
    
    def render_project_statistics_tab(self, project_id: int):
        """Onglet des statistiques du projet."""
        st.markdown("#### 📊 Statistiques du Projet")
        
        stats = self.pm.get_project_statistics(project_id)
        
        if not stats:
            st.info("Aucune statistique disponible.")
            return
        
        # Métriques principales
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Tâches Totales", stats['total_tasks'])
        
        with col2:
            st.metric("Tâches Terminées", stats['completed_tasks'])
        
        with col3:
            st.metric("Progression", f"{stats['completion_percentage']:.1f}%")
        
        with col4:
            st.metric("Heures Estimées", f"{stats['total_estimated_hours']:.1f}h")
        
        # Graphiques de progression
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("##### Répartition des Tâches")
            task_labels = ['Terminées', 'En cours', 'À faire']
            task_values = [stats['completed_tasks'], stats['active_tasks'], stats['pending_tasks']]
            
            fig = px.pie(
                values=task_values,
                names=task_labels,
                color_discrete_sequence=['#22C55E', '#3B82F6', '#F59E0B']
            )
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.markdown("##### Budget vs Réalisé")
            if stats['total_estimated_cost'] > 0 or stats['total_actual_cost'] > 0:
                budget_data = {
                    'Type': ['Estimé', 'Réalisé'],
                    'Montant': [stats['total_estimated_cost'], stats['total_actual_cost']]
                }
                
                fig = px.bar(
                    x=budget_data['Type'],
                    y=budget_data['Montant'],
                    color=budget_data['Type'],
                    color_discrete_sequence=['#3B82F6', '#22C55E']
                )
                fig.update_layout(showlegend=False)
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("Aucune donnée de coût disponible")
        
        # Écarts et analyses
        if stats['budget_variance'] != 0:
            st.markdown("##### 📈 Analyse des Écarts")
            
            col1, col2 = st.columns(2)
            
            with col1:
                variance_color = "green" if stats['budget_variance'] < 0 else "red"
                st.markdown(f"""
                **Écart Budgétaire:** 
                <span style="color: {variance_color}; font-weight: bold;">
                {stats['budget_variance']:+,.0f} $ ({stats['budget_variance_percentage']:+.1f}%)
                </span>
                """, unsafe_allow_html=True)
            
            with col2:
                time_variance_color = "green" if stats['time_variance'] < 0 else "red"
                st.markdown(f"""
                **Écart Temporel:** 
                <span style="color: {time_variance_color}; font-weight: bold;">
                {stats['time_variance']:+.1f}h ({stats['time_variance_percentage']:+.1f}%)
                </span>
                """, unsafe_allow_html=True)
    
    def render_project_notes_tab(self, project_id: int):
        """Onglet des notes du projet."""
        st.markdown("#### 📝 Notes et Commentaires")
        
        # Formulaire d'ajout de note
        with st.expander("➕ Ajouter une note"):
            note_content = st.text_area("Contenu de la note", key="new_note_content")
            note_type = st.selectbox("Type de note", 
                                   ["general", "probleme", "solution", "decision", "meeting"], 
                                   key="new_note_type")
            note_author = st.text_input("Auteur", key="new_note_author")
            
            if st.button("💾 Ajouter la Note", use_container_width=True):
                if note_content:
                    self.pm.add_note(project_id, note_content, note_type, author=note_author)
                    st.success("Note ajoutée avec succès !")
                    st.rerun()
                else:
                    st.warning("Le contenu de la note est requis.")
        
        # Affichage des notes existantes
        notes = self.pm.get_project_notes(project_id)
        
        if notes:
            for note in notes:
                note_icon = {
                    'general': '📝',
                    'probleme': '⚠️',
                    'solution': '💡',
                    'decision': '✅',
                    'meeting': '👥',
                    'analysis': '🤖'  # Pour les analyses IA
                }.get(note['note_type'], '📝')
                
                st.markdown(f"""
                <div class="info-card">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <strong>{note_icon} {note['note_type'].title()}</strong>
                        <small>{note['created_at'][:16]}</small>
                    </div>
                    <p>{note['content']}</p>
                    {f"<small><strong>Auteur:</strong> {note['author']}</small>" if note['author'] else ""}
                    {f"<small><strong>Tâche:</strong> {note['task_name']}</small>" if note['task_name'] else ""}
                </div>
                """, unsafe_allow_html=True)
        else:
            st.info("Aucune note pour ce projet.")
    
    def render_new_project_form(self):
        """Formulaire de création d'un nouveau projet."""
        st.markdown("### ➕ Nouveau Projet")
        
        with st.form("new_project_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### 📋 Informations Générales")
                project_name = st.text_input("Nom du projet *", placeholder="Ex: Maison unifamiliale Brossard")
                client_name = st.text_input("Nom du client", placeholder="Ex: Jean Dupont")
                client_contact = st.text_input("Contact client", placeholder="Ex: jean.dupont@email.com ou 514-555-0123")
                project_type = st.selectbox("Type de projet", 
                                          ["Résidentiel", "Commercial", "Industriel", "Infrastructure"])
            
            with col2:
                st.markdown("#### 📍 Localisation et Budget")
                address = st.text_input("Adresse", placeholder="Ex: 123 Rue Principale")
                city = st.text_input("Ville", placeholder="Ex: Brossard")
                postal_code = st.text_input("Code postal", placeholder="Ex: J4B 1A1")
                budget_initial = st.number_input("Budget initial ($)", min_value=0.0, value=0.0)
            
            col1, col2 = st.columns(2)
            
            with col1:
                start_date = st.date_input("Date de début prévue")
                priority = st.selectbox("Priorité", ["Faible", "Moyenne", "Élevée", "Critique"], index=1)
            
            with col2:
                end_date = st.date_input("Date de fin prévue")
                status = st.selectbox("Statut initial", ["En planification", "En cours"], index=0)
            
            description = st.text_area("Description du projet", 
                                     placeholder="Décrivez brièvement le projet, les objectifs et les spécificités...",
                                     height=100)
            
            submitted = st.form_submit_button("🚀 Créer le Projet", use_container_width=True)
            
            if submitted:
                if not project_name:
                    st.error("Le nom du projet est requis.")
                else:
                    project_data = {
                        'name': project_name,
                        'client_name': client_name,
                        'client_contact': client_contact,
                        'project_type': project_type,
                        'address': address,
                        'city': city,
                        'postal_code': postal_code,
                        'description': description,
                        'budget_initial': budget_initial,
                        'budget_current': budget_initial,
                        'start_date': start_date.isoformat() if start_date else '',
                        'end_date_planned': end_date.isoformat() if end_date else '',
                        'status': status,
                        'priority': priority
                    }
                    
                    try:
                        project_id = self.pm.create_project(project_data)
                        st.success(f"Projet '{project_name}' créé avec succès ! (ID: {project_id})")
                        st.session_state.current_project_id = project_id
                        st.session_state.project_view_mode = 'project_detail'
                        st.rerun()
                    except Exception as e:
                        st.error(f"Erreur lors de la création du projet: {e}")
    
    def render_tasks_view(self):
        """Vue globale de toutes les tâches."""
        st.markdown("### ✅ Vue d'ensemble des Tâches")
        
        # Récupérer tous les projets pour avoir toutes les tâches
        projects = self.pm.list_projects(limit=100)
        all_tasks = []
        
        for project in projects:
            tasks = self.pm.get_project_tasks(project['id'])
            for task in tasks:
                task['project_name'] = project['name']
                all_tasks.append(task)
        
        if not all_tasks:
            st.info("Aucune tâche trouvée.")
            return
        
        # Filtres
        col1, col2, col3 = st.columns(3)
        
        with col1:
            status_filter = st.selectbox("Filtrer par statut", 
                                       ["Tous", "À faire", "En cours", "Terminé"])
        
        with col2:
            priority_filter = st.selectbox("Filtrer par priorité",
                                         ["Toutes", "Critique", "Élevée", "Moyenne", "Faible"])
        
        with col3:
            project_filter = st.selectbox("Filtrer par projet",
                                        ["Tous"] + [p['name'] for p in projects])
        
        # Appliquer les filtres
        filtered_tasks = all_tasks
        
        if status_filter != "Tous":
            filtered_tasks = [t for t in filtered_tasks if t['status'] == status_filter]
        
        if priority_filter != "Toutes":
            filtered_tasks = [t for t in filtered_tasks if t['priority'] == priority_filter]
        
        if project_filter != "Tous":
            filtered_tasks = [t for t in filtered_tasks if t['project_name'] == project_filter]
        
        # Statistiques rapides
        if filtered_tasks:
            total_filtered = len(filtered_tasks)
            completed_filtered = sum(1 for t in filtered_tasks if t['status'] == 'Terminé')
            
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Tâches Affichées", total_filtered)
            with col2:
                st.metric("Terminées", completed_filtered)
            with col3:
                progress = (completed_filtered / total_filtered * 100) if total_filtered > 0 else 0
                st.metric("Progression", f"{progress:.1f}%")
        
        # Affichage des tâches
        for task in filtered_tasks:
            status_icon = {
                'À faire': '⏳',
                'En cours': '🔄',
                'Terminé': '✅'
            }.get(task['status'], '⚫')
            
            priority_color = {
                'Faible': '#22C55E',
                'Moyenne': '#3B82F6',
                'Élevée': '#F59E0B',
                'Critique': '#EF4444'
            }.get(task['priority'], '#6B7280')
            
            st.markdown(f"""
            <div class="project-card">
                <h5>{status_icon} {task['name']}</h5>
                <p><strong>Projet:</strong> {task['project_name']}</p>
                <p>{task['description'] or 'Aucune description'}</p>
                <p><strong>Priorité:</strong> 
                <span style="color: {priority_color}; font-weight: bold;">{task['priority']}</span> • 
                <strong>Assigné à:</strong> {task['assigned_to'] or 'Non assigné'} • 
                <strong>Échéance:</strong> {task['end_date_planned'] or 'Non définie'}</p>
            </div>
            """, unsafe_allow_html=True)

    def render_kanban_view(self):
        """Affiche un tableau Kanban global pour toutes les tâches."""
        st.markdown("### 🧮 Tableau Kanban Global")

        all_tasks = self.pm.get_all_tasks_with_project_info()
        projects = self.pm.list_projects(limit=100)

        if not all_tasks:
            st.info("Aucune tâche à afficher sur le Kanban. Créez des tâches dans vos projets.")
            return

        # Filtre par projet
        project_names = ["Tous les projets"] + [p['name'] for p in projects]
        selected_project = st.selectbox("Filtrer par projet:", project_names, key="kanban_project_filter")

        if selected_project != "Tous les projets":
            filtered_tasks = [t for t in all_tasks if t['project_name'] == selected_project]
        else:
            filtered_tasks = all_tasks
        
        st.divider()

        # Définition des colonnes du Kanban
        kanban_statuses = ["À faire", "En cours", "Terminé"]
        cols = st.columns(len(kanban_statuses))

        for i, status in enumerate(kanban_statuses):
            with cols[i]:
                tasks_in_column = [t for t in filtered_tasks if t['status'] == status]
                st.markdown(f"<div class='kanban-column-header'><h4>{status} ({len(tasks_in_column)})</h4></div>", unsafe_allow_html=True)
                
                with st.container(height=600): # Conteneur scrollable
                    for task in tasks_in_column:
                        priority_color = {
                            'Faible': '#22C55E', 'Moyenne': '#3B82F6',
                            'Élevée': '#F59E0B', 'Critique': '#EF4444'
                        }.get(task['priority'], '#6B7280')

                        st.markdown(f"""
                        <div class="kanban-card">
                            <div class="kanban-card-priority" style="background-color: {priority_color};"></div>
                            <strong>{task['name']}</strong>
                            <small>Projet: {task['project_name']}</small>
                            <small>Assigné à: {task.get('assigned_to') or 'N/A'}</small>
                        </div>
                        """, unsafe_allow_html=True)

                        # Sélecteur pour changer le statut
                        new_status = st.selectbox(
                            "Déplacer vers:",
                            options=kanban_statuses,
                            index=kanban_statuses.index(task['status']),
                            key=f"kanban_status_change_{task['id']}",
                            label_visibility="collapsed"
                        )
                        if new_status != task['status']:
                            self.pm.update_task(task['id'], {'status': new_status})
                            st.success(f"Tâche '{task['name']}' déplacée vers '{new_status}'.")
                            st.rerun()

    def render_calendar_view(self):
        """Affiche un calendrier des échéances des tâches."""
        st.markdown("### 📅 Calendrier des Échéances")

        # Navigation du calendrier
        cal_date = st.session_state.calendar_date
        col1, col2, col3, col4, col5 = st.columns([1, 1, 3, 1, 1])
        
        with col1:
            if st.button("⬅️ Mois Précédent", use_container_width=True):
                st.session_state.calendar_date -= timedelta(days=30)
                st.session_state.selected_calendar_day = None
                st.rerun()
        with col2:
            if st.button("Aujourd'hui", use_container_width=True):
                st.session_state.calendar_date = date.today()
                st.session_state.selected_calendar_day = None
                st.rerun()
        with col3:
            st.markdown(f"<h4 style='text-align: center; margin:0;'>{cal_date.strftime('%B %Y')}</h4>", unsafe_allow_html=True)
        with col4:
            if st.button("Mois Suivant ➡️", use_container_width=True):
                st.session_state.calendar_date += timedelta(days=30)
                st.session_state.selected_calendar_day = None
                st.rerun()

        st.divider()

        # Récupérer les tâches pour le mois affiché
        month_start = cal_date.replace(day=1)
        month_end = (month_start + timedelta(days=31)).replace(day=1) - timedelta(days=1)
        tasks_by_date = self.pm.get_tasks_for_calendar(month_start, month_end)
        
        # Afficher le calendrier
        month_calendar = calendar.monthcalendar(cal_date.year, cal_date.month)
        day_headers = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"]
        
        cols = st.columns(7)
        for i, header in enumerate(day_headers):
            cols[i].markdown(f"<div class='calendar-day-header'>{header}</div>", unsafe_allow_html=True)

        for week in month_calendar:
            cols = st.columns(7)
            for i, day in enumerate(week):
                with cols[i]:
                    if day == 0:
                        st.markdown("<div class='calendar-day-cell empty'></div>", unsafe_allow_html=True)
                    else:
                        current_day = date(cal_date.year, cal_date.month, day)
                        day_str = current_day.isoformat()
                        tasks_for_day = tasks_by_date.get(day_str, [])
                        
                        class_names = "calendar-day-cell"
                        if current_day == date.today():
                            class_names += " today"
                        if tasks_for_day:
                            class_names += " has-events"
                        if st.session_state.selected_calendar_day == current_day:
                            class_names += " selected"

                        if st.button(f"{day}", key=f"day_{day_str}", use_container_width=True):
                            st.session_state.selected_calendar_day = current_day
                            st.rerun()

                        if tasks_for_day:
                            for task in tasks_for_day[:2]: # Afficher max 2 icônes
                                priority_color = {'Critique': '🔴', 'Élevée': '🟠', 'Moyenne': '🔵'}.get(task['priority'], '⚪')
                                st.markdown(f"<span class='event-dot'>{priority_color}</span>", unsafe_allow_html=True)

        st.divider()

        # Afficher les détails du jour sélectionné
        if st.session_state.selected_calendar_day:
            day = st.session_state.selected_calendar_day
            day_str = day.isoformat()
            tasks_for_day = tasks_by_date.get(day_str, [])
            
            st.markdown(f"#### ⏰ Échéances pour le {day.strftime('%d %B %Y')}")
            if tasks_for_day:
                for task in tasks_for_day:
                    priority_color = {
                        'Faible': '#22C55E', 'Moyenne': '#3B82F6',
                        'Élevée': '#F59E0B', 'Critique': '#EF4444'
                    }.get(task['priority'], '#6B7280')
                    st.markdown(f"""
                    <div class="info-card">
                        <strong>{task['name']}</strong><br>
                        <small>Projet: {task['project_name']} • Priorité: <span style="color:{priority_color};">{task['priority']}</span></small>
                    </div>
                    """, unsafe_allow_html=True)
            else:
                st.info("Aucune échéance pour ce jour.")

    def render_reports(self):
        """Section des rapports et analyses."""
        st.markdown("### 📈 Rapports et Analyses") # Emoji changé
        
        # Types de rapports disponibles
        report_type = st.selectbox("Type de rapport",
                                 ["Résumé Global", "Performance des Projets", "Analyse Budgétaire", 
                                  "Productivité des Équipes", "Calendrier de Livraison"])
        
        if report_type == "Résumé Global":
            self.render_global_summary_report()
        elif report_type == "Performance des Projets":
            self.render_project_performance_report()
        elif report_type == "Analyse Budgétaire":
            self.render_budget_analysis_report()
        elif report_type == "Productivité des Équipes":
            self.render_team_productivity_report()
        elif report_type == "Calendrier de Livraison":
            self.render_delivery_schedule_report()
    
    def render_global_summary_report(self):
        """Rapport de résumé global."""
        st.markdown("#### 📋 Résumé Global")
        
        projects = self.pm.list_projects(limit=1000)  # Tous les projets
        
        if not projects:
            st.info("Aucun projet à analyser.")
            return
        
        # Calculs globaux
        total_budget = sum(p['budget_current'] for p in projects)
        active_projects = [p for p in projects if p['status'] == 'En cours']
        completed_projects = [p for p in projects if p['status'] == 'Terminé']
        
        # Métriques principales
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Projets Totaux", len(projects))
        
        with col2:
            st.metric("Projets Actifs", len(active_projects))
        
        with col3:
            st.metric("Projets Terminés", len(completed_projects))
        
        with col4:
            st.metric("Budget Total", f"{total_budget:,.0f} $")
        
        # Graphiques de synthèse
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("##### Répartition par Type de Projet")
            type_counts = {}
            for project in projects:
                project_type = project['project_type']
                type_counts[project_type] = type_counts.get(project_type, 0) + 1
            
            if type_counts:
                fig = px.pie(values=list(type_counts.values()), names=list(type_counts.keys()))
                st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.markdown("##### Évolution Mensuelle des Créations")
            # Grouper par mois de création
            monthly_data = {}
            for project in projects:
                try:
                    month = project['created_at'][:7]  # YYYY-MM
                    monthly_data[month] = monthly_data.get(month, 0) + 1
                except:
                    pass
            
            if monthly_data:
                months = sorted(monthly_data.keys())
                counts = [monthly_data[month] for month in months]
                
                fig = px.line(x=months, y=counts, markers=True)
                fig.update_layout(xaxis_title="Mois", yaxis_title="Nouveaux Projets")
                st.plotly_chart(fig, use_container_width=True)
    
    def render_project_performance_report(self):
        """Rapport de performance des projets - VERSION CORRIGÉE."""
        st.markdown("#### 🎯 Performance des Projets")
        
        projects = self.pm.list_projects(limit=1000)
        
        if not projects:
            st.info("Aucun projet à analyser.")
            return
        
        # Analyser chaque projet
        performance_data = []
        
        for project in projects:
            stats = self.pm.get_project_statistics(project['id'])
            if stats:
                performance_data.append({
                    'Projet': project['name'],
                    'Statut': project['status'],
                    'Progression (%)': stats['completion_percentage'],
                    'Budget ($)': project['budget_current'],
                    'Écart Budget (%)': stats.get('budget_variance_percentage', 0),
                    'Écart Temps (%)': stats.get('time_variance_percentage', 0),
                    'Tâches Totales': stats['total_tasks'],
                    'Tâches Terminées': stats['completed_tasks']
                })
        
        if performance_data:
            df = pd.DataFrame(performance_data)
            
            # Tableau interactif
            st.markdown("##### 📊 Tableau de Performance")
            st.dataframe(df, use_container_width=True)
            
            # Graphiques d'analyse - CORRECTIONS PLOTLY
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("##### Progression par Projet")
                fig = px.bar(df, x='Projet', y='Progression (%)', 
                           color='Statut', title="Progression des Projets")
                
                # ✅ CORRECTION : Utiliser update_layout au lieu de update_xaxis
                fig.update_layout(
                    xaxis_tickangle=45,
                    showlegend=True,
                    height=400
                )
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                st.markdown("##### Budget vs Écart")
                fig = px.scatter(df, x='Budget ($)', y='Écart Budget (%)', 
                               color='Statut', size='Tâches Totales',
                               hover_data=['Projet'],
                               title="Analyse Budgétaire")
                
                # ✅ CORRECTION : Configuration axes via update_layout
                fig.update_layout(
                    height=400,
                    showlegend=True
                )
                st.plotly_chart(fig, use_container_width=True)
    
    def render_budget_analysis_report(self):
        """Rapport d'analyse budgétaire."""
        st.markdown("#### 💰 Analyse Budgétaire")
        st.info("Rapport d'analyse budgétaire détaillé à implémenter.")
    
    def render_team_productivity_report(self):
        """Rapport de productivité des équipes."""
        st.markdown("#### 👥 Productivité des Équipes")
        st.info("Rapport de productivité des équipes à implémenter.")
    
    def render_delivery_schedule_report(self):
        """Rapport de calendrier de livraison."""
        st.markdown("#### 📅 Calendrier de Livraison")
        st.info("Rapport de calendrier de livraison à implémenter.")
    
    def render_global_gantt_view(self):
        """Affiche la vue globale du diagramme de Gantt."""
        st.markdown("### 📊 Diagramme de Gantt Global")
        
        # Contrôles pour le Gantt
        col1, col2, col3 = st.columns([2, 2, 1])
        
        with col1:
            view_mode = st.selectbox(
                "Mode d'affichage:",
                ["Tous les projets", "Projet spécifique"],
                key="gantt_view_mode"
            )
        
        with col2:
            if view_mode == "Projet spécifique":
                projects = self.pm.list_projects(limit=100)
                if projects:
                    project_options = {p['name']: p['id'] for p in projects}
                    selected_project = st.selectbox(
                        "Sélectionner un projet:",
                        options=list(project_options.keys()),
                        key="gantt_project_select"
                    )
                    selected_project_id = project_options[selected_project]
                else:
                    st.info("Aucun projet disponible")
                    return
            else:
                selected_project_id = None
        
        with col3:
            if st.button("🔄 Actualiser", use_container_width=True):
                st.rerun()
        
        try:
            # Récupérer les données Gantt
            if view_mode == "Tous les projets":
                gantt_data = self.pm.get_gantt_data(include_all_projects=True)
            else:
                gantt_data = self.pm.get_gantt_data(project_id=selected_project_id)
            
            tasks = gantt_data.get('tasks', [])
            
            if not tasks:
                st.info("Aucune tâche avec dates définies trouvée pour créer le diagramme de Gantt.")
                st.markdown("""
                **Pour voir le diagramme de Gantt :**
                1. Créez des projets avec des dates de début et de fin
                2. Ajoutez des tâches avec des dates planifiées
                3. Revenez ici pour visualiser le planning
                """)
                return
            
            # Créer le diagramme de Gantt avec Plotly
            import plotly.express as px
            import plotly.graph_objects as go
            
            # Créer le graphique
            fig = px.timeline(
                tasks,
                x_start="Start",
                x_end="Finish", 
                y="Resource",
                color="Status",
                hover_data=["Priority", "Complete"],
                title=f"Diagramme de Gantt - {view_mode}"
            )
            
            # Personnaliser l'apparence
            fig.update_layout(
                height=max(400, len(tasks) * 25 + 100),
                showlegend=True,
                xaxis_title="Calendrier",
                yaxis_title="Ressources/Assignés",
                font=dict(size=12),
                plot_bgcolor='rgba(0,0,0,0)',
                paper_bgcolor='rgba(0,0,0,0)'
            )
            
            # Afficher le graphique
            st.plotly_chart(fig, use_container_width=True)
            
            # Statistiques du Gantt
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Tâches Total", len(tasks))
            
            with col2:
                completed = sum(1 for t in tasks if t.get('Complete', 0) == 100)
                st.metric("Terminées", completed)
            
            with col3:
                in_progress = sum(1 for t in tasks if 0 < t.get('Complete', 0) < 100)
                st.metric("En cours", in_progress)
            
            with col4:
                not_started = sum(1 for t in tasks if t.get('Complete', 0) == 0)
                st.metric("À faire", not_started)
            
            # Légende des couleurs
            st.markdown("#### 📋 Légende des Statuts")
            
            status_colors = {
                'À faire': '#94A3B8',
                'En cours': '#3B82F6', 
                'Terminé': '#22C55E',
                'En attente': '#EF4444'
            }
            
            legend_cols = st.columns(len(status_colors))
            for i, (status, color) in enumerate(status_colors.items()):
                with legend_cols[i]:
                    st.markdown(f"""
                    <div style="display: flex; align-items: center; gap: 8px;">
                        <div style="width: 20px; height: 20px; background-color: {color}; border-radius: 4px;"></div>
                        <span>{status}</span>
                    </div>
                    """, unsafe_allow_html=True)
            
        except Exception as e:
            st.error(f"Erreur lors de la génération du diagramme de Gantt: {e}")
            st.exception(e)
            
            # Afficher des informations de debug
            with st.expander("🔍 Informations de debug"):
                gantt_data = {} # re-initialize to avoid UnboundLocalError
                if 'selected_project_id' in locals():
                     gantt_data = self.pm.get_gantt_data(project_id=selected_project_id) if view_mode != "Tous les projets" else self.pm.get_gantt_data(include_all_projects=True)
                
                st.write("Données Gantt récupérées:", gantt_data)
                if 'tasks' in gantt_data:
                    st.write("Nombre de tâches:", len(gantt_data['tasks']))
                    if gantt_data['tasks']:
                        st.write("Exemple de tâche:", gantt_data['tasks'][0])