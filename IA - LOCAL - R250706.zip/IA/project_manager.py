# project_manager.py
import sqlite3
import json
from datetime import datetime, date
from typing import List, Dict, Optional
import os

class ProjectManager:
    """Gestionnaire de projets de construction au Québec."""
    
    def __init__(self, db_path="projects.db"):
        self.db_path = db_path
        # Assurer que le dossier pour la DB existe
        db_dir = os.path.dirname(db_path)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir, exist_ok=True)
            print(f"Création du dossier pour la base de données projets: {db_dir}")
        
        print(f"Initialisation ProjectManager avec db: {self.db_path}")
        self._create_tables()
    
    def _connect(self):
        """Établit une connexion à la base de données."""
        try:
            conn = sqlite3.connect(self.db_path, isolation_level=None)
            conn.row_factory = sqlite3.Row
            return conn
        except sqlite3.Error as e:
            print(f"Erreur de connexion à la base de données projets ({self.db_path}): {e}")
            raise
    
    def _safe_float(self, value, default=0.0):
        """Convertit une valeur en float de manière sécurisée."""
        if value is None:
            return default
        try:
            return float(value)
        except (ValueError, TypeError):
            return default
    
    def _safe_int(self, value, default=0):
        """Convertit une valeur en int de manière sécurisée."""
        if value is None:
            return default
        try:
            return int(value)
        except (ValueError, TypeError):
            return default
    
    def _safe_divide(self, numerator, denominator, default=0.0):
        """Division sécurisée qui évite la division par zéro."""
        numerator = self._safe_float(numerator)
        denominator = self._safe_float(denominator)
        
        if denominator == 0:
            return default
        
        return round((numerator / denominator) * 100, 1)
    
    def _create_tables(self):
        """Crée les tables nécessaires pour les projets."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Table des projets
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS projects (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        name TEXT NOT NULL,
                        client_name TEXT,
                        client_contact TEXT,
                        project_type TEXT,
                        address TEXT,
                        city TEXT,
                        postal_code TEXT,
                        description TEXT,
                        budget_initial REAL,
                        budget_current REAL,
                        start_date TEXT,
                        end_date_planned TEXT,
                        end_date_actual TEXT,
                        status TEXT DEFAULT 'En planification',
                        priority TEXT DEFAULT 'Moyenne',
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        metadata TEXT  -- JSON pour données additionnelles
                    )
                """)
                
                # Table des tâches
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS project_tasks (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_id INTEGER NOT NULL,
                        name TEXT NOT NULL,
                        description TEXT,
                        status TEXT DEFAULT 'À faire',
                        priority TEXT DEFAULT 'Moyenne',
                        assigned_to TEXT,
                        estimated_hours REAL,
                        actual_hours REAL,
                        estimated_cost REAL,
                        actual_cost REAL,
                        start_date TEXT,
                        end_date_planned TEXT,
                        end_date_actual TEXT,
                        dependencies TEXT,  -- JSON pour les dépendances
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE
                    )
                """)
                
                # Table des documents par projet
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS project_documents (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_id INTEGER NOT NULL,
                        document_name TEXT NOT NULL,
                        document_type TEXT,
                        file_path TEXT,
                        analysis_summary TEXT,
                        uploaded_at TEXT NOT NULL,
                        FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE
                    )
                """)
                
                # Table des notes/commentaires
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS project_notes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_id INTEGER NOT NULL,
                        task_id INTEGER,
                        note_type TEXT DEFAULT 'general',
                        content TEXT NOT NULL,
                        author TEXT,
                        created_at TEXT NOT NULL,
                        FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE,
                        FOREIGN KEY (task_id) REFERENCES project_tasks (id) ON DELETE CASCADE
                    )
                """)
                
                print("Tables de gestion de projet créées.")
        except sqlite3.Error as e:
            print(f"Erreur lors de la création des tables projets: {e}")
    
    # === GESTION DES PROJETS ===
    
    def create_project(self, project_data: Dict) -> int:
        """Crée un nouveau projet."""
        now_iso = datetime.now().isoformat()
        
        required_fields = ['name']
        for field in required_fields:
            if not project_data.get(field):
                raise ValueError(f"Le champ '{field}' est requis.")
        
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Valeurs par défaut
                defaults = {
                    'client_name': '',
                    'client_contact': '',
                    'project_type': 'Résidentiel',
                    'address': '',
                    'city': '',
                    'postal_code': '',
                    'description': '',
                    'budget_initial': 0.0,
                    'budget_current': 0.0,
                    'start_date': '',
                    'end_date_planned': '',
                    'end_date_actual': '',
                    'status': 'En planification',
                    'priority': 'Moyenne',
                    'metadata': '{}'
                }
                
                # Fusionner avec les données fournies
                for key, default_value in defaults.items():
                    if key not in project_data:
                        project_data[key] = default_value
                
                cursor.execute("""
                    INSERT INTO projects (
                        name, client_name, client_contact, project_type, address, city, 
                        postal_code, description, budget_initial, budget_current, 
                        start_date, end_date_planned, end_date_actual, status, priority, 
                        created_at, updated_at, metadata
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    project_data['name'], project_data['client_name'], 
                    project_data['client_contact'], project_data['project_type'],
                    project_data['address'], project_data['city'], 
                    project_data['postal_code'], project_data['description'],
                    project_data['budget_initial'], project_data['budget_current'],
                    project_data['start_date'], project_data['end_date_planned'],
                    project_data['end_date_actual'], project_data['status'],
                    project_data['priority'], now_iso, now_iso, project_data['metadata']
                ))
                
                project_id = cursor.lastrowid
                print(f"Projet '{project_data['name']}' créé avec ID {project_id}")
                return project_id
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la création du projet: {e}")
            raise
    
    def get_project(self, project_id: int) -> Optional[Dict]:
        """Récupère un projet par son ID."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM projects WHERE id = ?", (project_id,))
                row = cursor.fetchone()
                return dict(row) if row else None
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération du projet {project_id}: {e}")
            return None
    
    def list_projects(self, status_filter: str = None, limit: int = 50) -> List[Dict]:
        """Liste les projets avec filtrage optionnel."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                if status_filter:
                    cursor.execute("""
                        SELECT * FROM projects 
                        WHERE status = ? 
                        ORDER BY updated_at DESC 
                        LIMIT ?
                    """, (status_filter, limit))
                else:
                    cursor.execute("""
                        SELECT * FROM projects 
                        ORDER BY updated_at DESC 
                        LIMIT ?
                    """, (limit,))
                
                projects = cursor.fetchall()
                return [dict(row) for row in projects]
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération de la liste des projets: {e}")
            return []
    
    def update_project(self, project_id: int, updates: Dict) -> bool:
        """Met à jour un projet."""
        if not updates:
            return False
            
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Construire la requête dynamiquement
                set_clauses = []
                values = []
                
                for key, value in updates.items():
                    if key != 'id':  # Ne pas permettre la modification de l'ID
                        set_clauses.append(f"{key} = ?")
                        values.append(value)
                
                if not set_clauses:
                    return False
                
                # Ajouter la date de mise à jour
                set_clauses.append("updated_at = ?")
                values.append(datetime.now().isoformat())
                values.append(project_id)
                
                query = f"UPDATE projects SET {', '.join(set_clauses)} WHERE id = ?"
                cursor.execute(query, values)
                
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la mise à jour du projet {project_id}: {e}")
            return False
    
    def delete_project(self, project_id: int) -> bool:
        """Supprime un projet et toutes ses données associées."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM projects WHERE id = ?", (project_id,))
                return cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Erreur lors de la suppression du projet {project_id}: {e}")
            return False
    
    # === GESTION DES TÂCHES ===
    
    def create_task(self, project_id: int, task_data: Dict) -> int:
        """Crée une nouvelle tâche pour un projet."""
        now_iso = datetime.now().isoformat()
        
        required_fields = ['name']
        for field in required_fields:
            if not task_data.get(field):
                raise ValueError(f"Le champ '{field}' est requis pour la tâche.")
        
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Valeurs par défaut pour les tâches
                defaults = {
                    'description': '',
                    'status': 'À faire',
                    'priority': 'Moyenne',
                    'assigned_to': '',
                    'estimated_hours': 0.0,
                    'actual_hours': 0.0,
                    'estimated_cost': 0.0,
                    'actual_cost': 0.0,
                    'start_date': '',
                    'end_date_planned': '',
                    'end_date_actual': '',
                    'dependencies': '[]'
                }
                
                for key, default_value in defaults.items():
                    if key not in task_data:
                        task_data[key] = default_value
                
                cursor.execute("""
                    INSERT INTO project_tasks (
                        project_id, name, description, status, priority, assigned_to,
                        estimated_hours, actual_hours, estimated_cost, actual_cost,
                        start_date, end_date_planned, end_date_actual, dependencies,
                        created_at, updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    project_id, task_data['name'], task_data['description'],
                    task_data['status'], task_data['priority'], task_data['assigned_to'],
                    task_data['estimated_hours'], task_data['actual_hours'],
                    task_data['estimated_cost'], task_data['actual_cost'],
                    task_data['start_date'], task_data['end_date_planned'],
                    task_data['end_date_actual'], task_data['dependencies'],
                    now_iso, now_iso
                ))
                
                task_id = cursor.lastrowid
                print(f"Tâche '{task_data['name']}' créée avec ID {task_id}")
                return task_id
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la création de la tâche: {e}")
            raise
    
    def get_project_tasks(self, project_id: int) -> List[Dict]:
        """Récupère toutes les tâches d'un projet."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT * FROM project_tasks 
                    WHERE project_id = ? 
                    ORDER BY created_at ASC
                """, (project_id,))
                
                tasks = cursor.fetchall()
                return [dict(row) for row in tasks]
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération des tâches du projet {project_id}: {e}")
            return []
    
    def update_task(self, task_id: int, updates: Dict) -> bool:
        """Met à jour une tâche."""
        if not updates:
            return False
            
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                set_clauses = []
                values = []
                
                for key, value in updates.items():
                    if key not in ['id', 'project_id']:
                        set_clauses.append(f"{key} = ?")
                        values.append(value)
                
                if not set_clauses:
                    return False
                
                set_clauses.append("updated_at = ?")
                values.append(datetime.now().isoformat())
                values.append(task_id)
                
                query = f"UPDATE project_tasks SET {', '.join(set_clauses)} WHERE id = ?"
                cursor.execute(query, values)
                
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la mise à jour de la tâche {task_id}: {e}")
            return False
    
    def delete_task(self, task_id: int) -> bool:
        """Supprime une tâche."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM project_tasks WHERE id = ?", (task_id,))
                return cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Erreur lors de la suppression de la tâche {task_id}: {e}")
            return False
    
    # === STATISTIQUES ET RAPPORTS ===
    
    def get_project_statistics(self, project_id: int) -> Dict:
        """Calcule les statistiques d'un projet."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Statistiques des tâches avec COALESCE pour éviter les None
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_tasks,
                        SUM(CASE WHEN status = 'Terminé' THEN 1 ELSE 0 END) as completed_tasks,
                        SUM(CASE WHEN status = 'En cours' THEN 1 ELSE 0 END) as active_tasks,
                        SUM(CASE WHEN status = 'À faire' THEN 1 ELSE 0 END) as pending_tasks,
                        COALESCE(SUM(estimated_hours), 0) as total_estimated_hours,
                        COALESCE(SUM(actual_hours), 0) as total_actual_hours,
                        COALESCE(SUM(estimated_cost), 0) as total_estimated_cost,
                        COALESCE(SUM(actual_cost), 0) as total_actual_cost
                    FROM project_tasks 
                    WHERE project_id = ?
                """, (project_id,))
                
                task_stats = cursor.fetchone()
                
                # Récupérer les informations du projet
                project = self.get_project(project_id)
                
                if not project or not task_stats:
                    return {}
                
                stats = dict(task_stats)
                
                # S'assurer que toutes les valeurs numériques sont des nombres, pas None
                numeric_fields = [
                    'total_tasks', 'completed_tasks', 'active_tasks', 'pending_tasks',
                    'total_estimated_hours', 'total_actual_hours', 
                    'total_estimated_cost', 'total_actual_cost'
                ]
                
                for field in numeric_fields:
                    stats[field] = self._safe_float(stats.get(field, 0))
                
                # Calculs supplémentaires
                if stats['total_tasks'] > 0:
                    stats['completion_percentage'] = self._safe_divide(
                        stats['completed_tasks'], 
                        stats['total_tasks']
                    )
                else:
                    stats['completion_percentage'] = 0.0
                
                # Écart budgétaire - s'assurer que budget_initial n'est pas None
                budget_initial = self._safe_float(project.get('budget_initial', 0))
                budget_current = self._safe_float(project.get('budget_current', 0))
                
                if budget_initial > 0:
                    stats['budget_variance'] = budget_current - budget_initial
                    stats['budget_variance_percentage'] = self._safe_divide(
                        stats['budget_variance'], 
                        budget_initial
                    )
                else:
                    stats['budget_variance'] = 0.0
                    stats['budget_variance_percentage'] = 0.0
                
                # Écart temporel - vérifier que les valeurs ne sont pas None
                if stats['total_estimated_hours'] > 0 and stats['total_actual_hours'] > 0:
                    stats['time_variance'] = stats['total_actual_hours'] - stats['total_estimated_hours']
                    stats['time_variance_percentage'] = self._safe_divide(
                        stats['time_variance'], 
                        stats['total_estimated_hours']
                    )
                else:
                    stats['time_variance'] = 0.0
                    stats['time_variance_percentage'] = 0.0
                
                return stats
                
        except sqlite3.Error as e:
            print(f"Erreur lors du calcul des statistiques du projet {project_id}: {e}")
            return {
                'total_tasks': 0,
                'completed_tasks': 0,
                'active_tasks': 0,
                'pending_tasks': 0,
                'completion_percentage': 0.0,
                'total_estimated_hours': 0.0,
                'total_actual_hours': 0.0,
                'total_estimated_cost': 0.0,
                'total_actual_cost': 0.0,
                'budget_variance': 0.0,
                'budget_variance_percentage': 0.0,
                'time_variance': 0.0,
                'time_variance_percentage': 0.0
            }
    
    def get_dashboard_summary(self) -> Dict:
        """Génère un résumé pour le tableau de bord."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Statistiques générales des projets
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_projects,
                        SUM(CASE WHEN status = 'Terminé' THEN 1 ELSE 0 END) as completed_projects,
                        SUM(CASE WHEN status = 'En cours' THEN 1 ELSE 0 END) as active_projects,
                        SUM(CASE WHEN status = 'En planification' THEN 1 ELSE 0 END) as planning_projects,
                        COALESCE(SUM(budget_initial), 0) as total_budget_initial,
                        COALESCE(SUM(budget_current), 0) as total_budget_current
                    FROM projects
                """)
                
                project_stats_raw = cursor.fetchone()
                project_stats = dict(project_stats_raw) if project_stats_raw else {}
                
                # Sécuriser les valeurs numériques
                for key in project_stats:
                    project_stats[key] = self._safe_float(project_stats.get(key, 0))
                
                # Statistiques des tâches globales
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_tasks,
                        SUM(CASE WHEN status = 'Terminé' THEN 1 ELSE 0 END) as completed_tasks,
                        SUM(CASE WHEN status = 'En cours' THEN 1 ELSE 0 END) as active_tasks
                    FROM project_tasks
                """)
                
                task_stats_raw = cursor.fetchone()
                task_stats = dict(task_stats_raw) if task_stats_raw else {}
                
                # Sécuriser les valeurs numériques
                for key in task_stats:
                    task_stats[key] = self._safe_float(task_stats.get(key, 0))
                
                # Projets récents
                cursor.execute("""
                    SELECT id, name, status, updated_at 
                    FROM projects 
                    ORDER BY updated_at DESC 
                    LIMIT 5
                """)
                
                recent_projects = [dict(row) for row in cursor.fetchall()]
                
                # Tâches urgentes (avec date de fin proche)
                cursor.execute("""
                    SELECT pt.id, pt.name, pt.end_date_planned, p.name as project_name
                    FROM project_tasks pt
                    JOIN projects p ON pt.project_id = p.id
                    WHERE pt.status != 'Terminé' 
                    AND pt.end_date_planned != ''
                    ORDER BY pt.end_date_planned ASC
                    LIMIT 5
                """)
                
                urgent_tasks = [dict(row) for row in cursor.fetchall()]
                
                return {
                    'projects': project_stats,
                    'tasks': task_stats,
                    'recent_projects': recent_projects,
                    'urgent_tasks': urgent_tasks
                }
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la génération du résumé tableau de bord: {e}")
            return {
                'projects': {
                    'total_projects': 0,
                    'completed_projects': 0,
                    'active_projects': 0,
                    'planning_projects': 0,
                    'total_budget_initial': 0.0,
                    'total_budget_current': 0.0
                },
                'tasks': {
                    'total_tasks': 0,
                    'completed_tasks': 0,
                    'active_tasks': 0
                },
                'recent_projects': [],
                'urgent_tasks': []
            }

    # === GESTION DES NOTES ===
    
    def add_note(self, project_id: int, content: str, note_type: str = "general", 
                 task_id: int = None, author: str = "") -> int:
        """Ajoute une note à un projet ou une tâche."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    INSERT INTO project_notes (project_id, task_id, note_type, content, author, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (project_id, task_id, note_type, content, author, datetime.now().isoformat()))
                
                return cursor.lastrowid
                
        except sqlite3.Error as e:
            print(f"Erreur lors de l'ajout de la note: {e}")
            raise
    
    def get_project_notes(self, project_id: int, limit: int = 20) -> List[Dict]:
        """Récupère les notes d'un projet."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT pn.*, pt.name as task_name
                    FROM project_notes pn
                    LEFT JOIN project_tasks pt ON pn.task_id = pt.id
                    WHERE pn.project_id = ?
                    ORDER BY pn.created_at DESC
                    LIMIT ?
                """, (project_id, limit))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération des notes du projet {project_id}: {e}")
            return []
    
    # === MÉTHODES POUR DIAGRAMME DE GANTT ===
    
    def get_gantt_data(self, project_id: int = None, include_all_projects: bool = False) -> Dict:
        """Récupère les données formatées pour le diagramme de Gantt."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                if include_all_projects:
                    # Vue globale : tous les projets
                    cursor.execute("""
                        SELECT 
                            p.id as project_id,
                            p.name as project_name,
                            p.start_date,
                            p.end_date_planned,
                            p.status as project_status,
                            p.priority as project_priority,
                            NULL as task_id,
                            NULL as task_name,
                            NULL as task_status,
                            NULL as task_priority,
                            NULL as assigned_to,
                            'project' as item_type
                        FROM projects p
                        WHERE p.start_date != '' AND p.end_date_planned != ''
                        
                        UNION ALL
                        
                        SELECT 
                            pt.project_id,
                            p.name as project_name,
                            pt.start_date,
                            pt.end_date_planned,
                            p.status as project_status,
                            p.priority as project_priority,
                            pt.id as task_id,
                            pt.name as task_name,
                            pt.status as task_status,
                            pt.priority as task_priority,
                            pt.assigned_to,
                            'task' as item_type
                        FROM project_tasks pt
                        JOIN projects p ON pt.project_id = p.id
                        WHERE pt.start_date != '' AND pt.end_date_planned != ''
                        
                        ORDER BY project_id, item_type, task_id
                    """)
                else:
                    # Vue projet spécifique
                    if not project_id:
                        return {"tasks": [], "project_info": None}
                    
                    cursor.execute("""
                        SELECT 
                            pt.id as task_id,
                            pt.name as task_name,
                            pt.start_date,
                            pt.end_date_planned,
                            pt.status,
                            pt.priority,
                            pt.assigned_to,
                            pt.estimated_hours,
                            pt.actual_hours,
                            pt.dependencies,
                            p.name as project_name,
                            p.start_date as project_start,
                            p.end_date_planned as project_end
                        FROM project_tasks pt
                        JOIN projects p ON pt.project_id = p.id
                        WHERE pt.project_id = ?
                        AND pt.start_date != '' AND pt.end_date_planned != ''
                        ORDER BY pt.start_date ASC
                    """, (project_id,))
                    
                    # Récupérer aussi les infos du projet
                    project_info = self.get_project(project_id)
                
                results = cursor.fetchall()
                tasks_data = [dict(row) for row in results]
                
                # Formater les données pour Plotly Gantt
                gantt_data = []
                
                for task in tasks_data:
                    try:
                        # Gérer les dates
                        start_date_str = task.get('start_date', '')
                        end_date_str = task.get('end_date_planned', '')
                        
                        if not start_date_str or not end_date_str:
                            continue
                        
                        # Convertir les dates ISO en objets datetime
                        start_dt = datetime.fromisoformat(start_date_str)
                        end_dt = datetime.fromisoformat(end_date_str)
                        
                        # Déterminer les couleurs selon le statut
                        if include_all_projects and task.get('item_type') == 'project':
                            # Projet principal
                            color = self._get_project_color(task.get('project_status', ''))
                            name = f"📁 {task.get('project_name', 'Projet')}"
                            resource = "PROJETS"
                            status_val = task.get('project_status', '')
                        else:
                            # Tâche
                            color = self._get_task_color(task.get('task_status', ''))
                            name = task.get('task_name', 'Tâche')
                            resource = task.get('assigned_to', 'Non assigné')
                            status_val = task.get('task_status') if 'task_status' in task else task.get('status', '')
                            if include_all_projects:
                                name = f"{task.get('project_name', '')} - {name}"
                        
                        gantt_item = {
                            'Task': name,
                            'Start': start_dt,
                            'Finish': end_dt,
                            'Resource': resource,
                            'Complete': self._get_completion_percentage(task),
                            'Description': self._build_task_description(task),
                            'Priority': task.get('priority', 'Moyenne'),
                            'Status': status_val,
                            'Color': color
                        }
                        
                        gantt_data.append(gantt_item)
                        
                    except Exception as e:
                        print(f"Erreur traitement tâche Gantt {task.get('task_id') or task.get('project_id')}: {e}")
                        continue
                
                return {
                    "tasks": gantt_data,
                    "project_info": locals().get('project_info', None),
                    "total_tasks": len(gantt_data)
                }
                
        except sqlite3.Error as e:
            print(f"Erreur récupération données Gantt: {e}")
            return {"tasks": [], "project_info": None, "total_tasks": 0}

    def _get_task_color(self, status: str) -> str:
        """Retourne la couleur selon le statut de la tâche."""
        color_map = {
            'À faire': '#94A3B8',      # Gris
            'En cours': '#3B82F6',     # Bleu
            'Terminé': '#22C55E',      # Vert
            'En attente': '#EF4444',   # Rouge
            'En pause': '#F59E0B'      # Orange
        }
        return color_map.get(status, '#6B7280')

    def _get_project_color(self, status: str) -> str:
        """Retourne la couleur selon le statut du projet."""
        color_map = {
            'En planification': '#8B5CF6',  # Violet
            'En cours': '#3B82F6',          # Bleu
            'Terminé': '#22C55E',           # Vert
            'En attente': '#EF4444'         # Rouge
        }
        return color_map.get(status, '#6B7280')

    def _get_completion_percentage(self, task: Dict) -> int:
        """Calcule le pourcentage de completion d'une tâche."""
        status = task.get('task_status', task.get('status', ''))
        
        if status == 'Terminé':
            return 100
        elif status == 'En cours':
            # Si on a des heures, calculer basé sur ça
            estimated = self._safe_float(task.get('estimated_hours', 0))
            actual = self._safe_float(task.get('actual_hours', 0))
            if estimated > 0:
                return min(int((actual / estimated) * 100), 95)  # Max 95% si en cours
            return 50  # Valeur par défaut pour "en cours"
        elif status == 'À faire':
            return 0
        elif status in ['En attente', 'En pause']:
            return 25  # Peut-être partiellement commencé
        else:
            return 0

    def _build_task_description(self, task: Dict) -> str:
        """Construit la description hover pour une tâche."""
        desc_parts = []
        
        if task.get('task_name'):
            desc_parts.append(f"Tâche: {task['task_name']}")
        
        if task.get('project_name'):
            desc_parts.append(f"Projet: {task['project_name']}")
        
        if task.get('assigned_to'):
            desc_parts.append(f"Assigné à: {task['assigned_to']}")
        
        if task.get('priority'):
            desc_parts.append(f"Priorité: {task['priority']}")
        
        estimated_hours = self._safe_float(task.get('estimated_hours', 0))
        if estimated_hours > 0:
            desc_parts.append(f"Heures estimées: {estimated_hours}")
        
        actual_hours = self._safe_float(task.get('actual_hours', 0))
        if actual_hours > 0:
            desc_parts.append(f"Heures réelles: {actual_hours}")
        
        return "<br>".join(desc_parts)

    def update_task_dates(self, task_id: int, start_date: str, end_date: str) -> bool:
        """Met à jour les dates d'une tâche depuis le Gantt."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    UPDATE project_tasks 
                    SET start_date = ?, end_date_planned = ?, updated_at = ?
                    WHERE id = ?
                """, (start_date, end_date, datetime.now().isoformat(), task_id))
                return cursor.rowcount > 0
        except sqlite3.Error as e:
            print(f"Erreur mise à jour dates tâche {task_id}: {e}")
            return False

    def get_task_dependencies(self, project_id: int) -> List[Dict]:
        """Récupère les dépendances entre tâches pour le Gantt."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT id, name, dependencies 
                    FROM project_tasks 
                    WHERE project_id = ? AND dependencies IS NOT NULL AND dependencies != '[]'
                """, (project_id,))
                
                results = []
                for row in cursor.fetchall():
                    task = dict(row)
                    try:
                        deps = json.loads(task['dependencies'])
                        if deps:
                            task['dependencies'] = deps
                            results.append(task)
                    except (json.JSONDecodeError, TypeError):
                        continue
                
                return results
        except sqlite3.Error as e:
            print(f"Erreur récupération dépendances: {e}")
            return []
            
    # === NOUVELLES MÉTHODES POUR KANBAN ET CALENDRIER ===
    
    def get_all_tasks_with_project_info(self) -> List[Dict]:
        """Récupère toutes les tâches de tous les projets avec le nom du projet associé."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    SELECT 
                        pt.*,
                        p.name as project_name
                    FROM project_tasks pt
                    JOIN projects p ON pt.project_id = p.id
                    ORDER BY p.name, pt.priority
                """)
                tasks = cursor.fetchall()
                return [dict(row) for row in tasks]
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération de toutes les tâches : {e}")
            return []

    def get_tasks_for_calendar(self, start_date: date, end_date: date) -> Dict[str, List[Dict]]:
        """
        Récupère les tâches avec une date de fin planifiée dans une période donnée,
        et les retourne groupées par date.
        """
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                # La requête sélectionne les tâches dont la date de fin est dans l'intervalle
                cursor.execute("""
                    SELECT 
                        pt.id, pt.name, pt.end_date_planned, pt.priority, pt.status,
                        p.name as project_name
                    FROM project_tasks pt
                    JOIN projects p ON pt.project_id = p.id
                    WHERE pt.status != 'Terminé' 
                    AND pt.end_date_planned BETWEEN ? AND ?
                """, (start_date.isoformat(), end_date.isoformat()))
                
                tasks = cursor.fetchall()
                
                # Grouper les tâches par date
                tasks_by_date = {}
                for task in tasks:
                    task_date_str = task['end_date_planned']
                    if task_date_str:
                        if task_date_str not in tasks_by_date:
                            tasks_by_date[task_date_str] = []
                        tasks_by_date[task_date_str].append(dict(task))
                
                return tasks_by_date
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération des tâches pour le calendrier : {e}")
            return {}

    # === NOUVELLES MÉTHODES IA ===
    
    def get_project_ai_analysis_data(self, project_id: int) -> Dict:
        """Récupère toutes les données nécessaires pour l'analyse IA d'un projet."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Données du projet principal
                project = self.get_project(project_id)
                if not project:
                    return {}
                
                # Statistiques du projet
                stats = self.get_project_statistics(project_id)
                
                # Tâches détaillées
                tasks = self.get_project_tasks(project_id)
                
                # Notes et commentaires
                notes = self.get_project_notes(project_id, limit=50)
                
                # Analyse temporelle avancée
                cursor.execute("""
                    SELECT 
                        COUNT(*) as total_tasks,
                        COUNT(CASE WHEN status = 'Terminé' AND end_date_actual <= end_date_planned THEN 1 END) as on_time_tasks,
                        COUNT(CASE WHEN status = 'Terminé' AND end_date_actual > end_date_planned THEN 1 END) as late_tasks,
                        COUNT(CASE WHEN status != 'Terminé' AND end_date_planned < date('now') THEN 1 END) as overdue_tasks,
                        AVG(CASE WHEN status = 'Terminé' AND estimated_hours > 0 
                            THEN (actual_hours - estimated_hours) / estimated_hours * 100 END) as avg_time_variance_pct
                    FROM project_tasks 
                    WHERE project_id = ?
                """, (project_id,))
                
                time_analysis = cursor.fetchone()
                time_data = dict(time_analysis) if time_analysis else {}
                
                # Analyse budgétaire avancée
                cursor.execute("""
                    SELECT 
                        SUM(estimated_cost) as total_estimated,
                        SUM(actual_cost) as total_actual,
                        COUNT(CASE WHEN actual_cost > estimated_cost * 1.1 THEN 1 END) as over_budget_tasks,
                        MAX(CASE WHEN estimated_cost > 0 
                            THEN (actual_cost - estimated_cost) / estimated_cost * 100 END) as max_cost_overrun_pct,
                        AVG(CASE WHEN estimated_cost > 0 
                            THEN (actual_cost - estimated_cost) / estimated_cost * 100 END) as avg_cost_variance_pct
                    FROM project_tasks 
                    WHERE project_id = ?
                """, (project_id,))
                
                budget_analysis = cursor.fetchone()
                budget_data = dict(budget_analysis) if budget_analysis else {}
                
                # Analyse par priorité et assignation
                cursor.execute("""
                    SELECT 
                        priority,
                        COUNT(*) as task_count,
                        COUNT(CASE WHEN status = 'Terminé' THEN 1 END) as completed_count,
                        AVG(CASE WHEN status = 'Terminé' AND estimated_hours > 0 
                            THEN actual_hours / estimated_hours END) as avg_efficiency
                    FROM project_tasks 
                    WHERE project_id = ?
                    GROUP BY priority
                """, (project_id,))
                
                priority_analysis = [dict(row) for row in cursor.fetchall()]
                
                # Analyse par assignation
                cursor.execute("""
                    SELECT 
                        COALESCE(assigned_to, 'Non assigné') as assignee,
                        COUNT(*) as task_count,
                        COUNT(CASE WHEN status = 'Terminé' THEN 1 END) as completed_count,
                        SUM(estimated_hours) as total_estimated_hours,
                        SUM(actual_hours) as total_actual_hours
                    FROM project_tasks 
                    WHERE project_id = ?
                    GROUP BY assigned_to
                """, (project_id,))
                
                assignee_analysis = [dict(row) for row in cursor.fetchall()]
                
                return {
                    'project': project,
                    'statistics': stats,
                    'tasks': tasks,
                    'notes': notes,
                    'time_analysis': time_data,
                    'budget_analysis': budget_data,
                    'priority_analysis': priority_analysis,
                    'assignee_analysis': assignee_analysis,
                    'analysis_timestamp': datetime.now().isoformat()
                }
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération des données d'analyse IA pour le projet {project_id}: {e}")
            return {}

    def get_global_ai_analysis_data(self) -> Dict:
        """Récupère les données pour une analyse IA globale de tous les projets."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Données de base du tableau de bord
                dashboard_summary = self.get_dashboard_summary()
                
                # Analyse comparative des projets
                cursor.execute("""
                    SELECT 
                        p.id,
                        p.name,
                        p.project_type,
                        p.status,
                        p.priority,
                        p.budget_initial,
                        p.budget_current,
                        p.start_date,
                        p.end_date_planned,
                        COUNT(pt.id) as task_count,
                        COUNT(CASE WHEN pt.status = 'Terminé' THEN 1 END) as completed_tasks,
                        COALESCE(SUM(pt.estimated_cost), 0) as total_task_estimated_cost,
                        COALESCE(SUM(pt.actual_cost), 0) as total_task_actual_cost,
                        COALESCE(SUM(pt.estimated_hours), 0) as total_estimated_hours,
                        COALESCE(SUM(pt.actual_hours), 0) as total_actual_hours
                    FROM projects p
                    LEFT JOIN project_tasks pt ON p.id = pt.project_id
                    GROUP BY p.id
                    ORDER BY p.updated_at DESC
                """)
                
                projects_analysis = [dict(row) for row in cursor.fetchall()]
                
                # Tendances temporelles
                cursor.execute("""
                    SELECT 
                        date(created_at) as creation_date,
                        COUNT(*) as projects_created,
                        AVG(budget_initial) as avg_budget
                    FROM projects 
                    WHERE created_at >= date('now', '-6 months')
                    GROUP BY date(created_at)
                    ORDER BY creation_date
                """)
                
                temporal_trends = [dict(row) for row in cursor.fetchall()]
                
                # Performance par type de projet
                cursor.execute("""
                    SELECT 
                        project_type,
                        COUNT(*) as project_count,
                        AVG(budget_current - budget_initial) as avg_budget_variance,
                        COUNT(CASE WHEN status = 'Terminé' THEN 1 END) as completed_count
                    FROM projects
                    GROUP BY project_type
                """)
                
                type_performance = [dict(row) for row in cursor.fetchall()]
                
                return {
                    'dashboard_summary': dashboard_summary,
                    'projects_analysis': projects_analysis,
                    'temporal_trends': temporal_trends,
                    'type_performance': type_performance,
                    'analysis_timestamp': datetime.now().isoformat()
                }
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération des données d'analyse IA globale: {e}")
            return {}

    def get_project_ai_insights(self, project_id: int) -> Dict:
        """Génère des insights automatiques pour un projet sans IA externe."""
        try:
            data = self.get_project_ai_analysis_data(project_id)
            if not data:
                return {'insights': [], 'alerts': [], 'recommendations': []}
            
            insights = []
            alerts = []
            recommendations = []
            
            project = data['project']
            stats = data['statistics']
            time_data = data['time_analysis']
            budget_data = data['budget_analysis']
            
            # Analyse budgétaire
            budget_variance_pct = self._safe_divide(
                project['budget_current'] - project['budget_initial'],
                project['budget_initial']
            )
            
            if abs(budget_variance_pct) > 10:
                alert_type = "Dépassement budgétaire" if budget_variance_pct > 0 else "Économie budgétaire"
                alerts.append({
                    'type': 'budget',
                    'severity': 'high' if abs(budget_variance_pct) > 20 else 'medium',
                    'message': f"{alert_type} de {budget_variance_pct:.1f}%"
                })
                
                if budget_variance_pct > 0:
                    recommendations.append({
                        'category': 'budget',
                        'priority': 'high',
                        'action': f"Réviser le budget et identifier les postes de dépassement. Écart actuel: {budget_variance_pct:.1f}%"
                    })
            
            # Analyse temporelle
            if time_data.get('overdue_tasks', 0) > 0:
                alerts.append({
                    'type': 'schedule',
                    'severity': 'high',
                    'message': f"{time_data['overdue_tasks']} tâche(s) en retard"
                })
                
                recommendations.append({
                    'category': 'planning',
                    'priority': 'high',
                    'action': f"Reprioriser les {time_data['overdue_tasks']} tâches en retard et ajuster les ressources"
                })
            
            # Analyse de progression
            completion_pct = stats.get('completion_percentage', 0)
            if completion_pct < 25 and len(data['tasks']) > 5:
                insights.append({
                    'type': 'progress',
                    'message': f"Projet en phase initiale ({completion_pct:.1f}% complété)",
                    'suggestion': "Moment idéal pour ajuster la planification si nécessaire"
                })
            elif completion_pct > 75:
                insights.append({
                    'type': 'progress',
                    'message': f"Projet en phase finale ({completion_pct:.1f}% complété)",
                    'suggestion': "Concentrer les efforts sur les tâches de finition et contrôle qualité"
                })
            
            # Analyse des tâches critiques
            high_priority_tasks = [t for t in data['tasks'] if t['priority'] == 'Critique' and t['status'] != 'Terminé']
            if high_priority_tasks:
                alerts.append({
                    'type': 'priority',
                    'severity': 'medium',
                    'message': f"{len(high_priority_tasks)} tâche(s) critiques en cours"
                })
            
            return {
                'insights': insights,
                'alerts': alerts,
                'recommendations': recommendations,
                'generated_at': datetime.now().isoformat()
            }
            
        except Exception as e:
            print(f"Erreur lors de la génération des insights pour le projet {project_id}: {e}")
            return {'insights': [], 'alerts': [], 'recommendations': []}