# app.py (Version fusionnée - SANS boutons de navigation)
import streamlit as st
import os
import io
import html
import markdown
from datetime import datetime
from dotenv import load_dotenv

# Importer les classes logiques et le gestionnaire de conversation
try:
    from expert_logic import ExpertAdvisor, ExpertProfileManager
    from conversation_manager import ConversationManager
except ImportError as e:
    st.error(f"Erreur d'importation des modules locaux: {e}")
    st.error("Assurez-vous que les fichiers 'expert_logic.py' et 'conversation_manager.py' existent dans le même dossier.")
    st.stop()

# Importer les modules de gestion de projet
try:
    from project_manager import ProjectManager
    from project_ui import ProjectUI
except ImportError as e:
    st.error(f"Erreur d'importation des modules de gestion de projet: {e}")
    st.error("Assurez-vous que les fichiers 'project_manager.py' et 'project_ui.py' existent dans le même dossier.")
    # Continuer sans le gestionnaire de projet (optionnel)

# NOUVEAU : Importer les modules d'inventaire
try:
    from inventory_manager import InventoryManager
    from inventory_ui import InventoryUI
except ImportError as e:
    st.error(f"Erreur d'importation des modules d'inventaire: {e}")
    st.error("Assurez-vous que les fichiers 'inventory_manager.py' et 'inventory_ui.py' existent dans le même dossier.")

# NOUVEAU : Importer les modules de base de données
try:
    from database_integration import (
        init_database_for_app, 
        track_expert_usage, 
        track_user_action,
        get_performance_metrics
    )
except ImportError as e:
    st.error(f"Erreur d'importation des modules de base de données: {e}")
    st.error("Assurez-vous que les fichiers 'database_manager.py' et 'database_integration.py' existent dans le même dossier.")
    # Continuer sans la base de données centralisée (optionnel)

# NOUVEAU : Importer les modules de base de connaissances
try:
    from knowledge_base_ui import KnowledgeBaseUI
except ImportError as e:
    st.error(f"Erreur d'importation du module base de connaissances: {e}")
    # Continuer sans la base de connaissances (optionnel)

# --- Fonction pour charger le CSS local (utilisée avant et après login) ---
def local_css(file_name):
    """Charge les styles CSS depuis un fichier local."""
    try:
        css_path = os.path.join(os.path.dirname(__file__), file_name)
        with open(css_path, "r", encoding="utf-8") as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
    except FileNotFoundError:
        st.warning(f"Fichier CSS '{file_name}' non trouvé dans {os.path.dirname(__file__)}.")
    except Exception as e:
        st.error(f"Erreur lors du chargement du CSS '{file_name}': {e}")

# --- Helper Function pour lire le CSS pour l'intégration HTML (utilisée plus tard) ---
@st.cache_data
def load_css_content(file_name):
    """Charge le contenu brut d'un fichier CSS."""
    try:
        css_path = os.path.join(os.path.dirname(__file__), file_name)
        with open(css_path, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        st.warning(f"Fichier CSS '{file_name}' non trouvé pour l'intégration HTML.")
        return "/* CSS non trouvé */"
    except Exception as e:
        st.error(f"Erreur lors de la lecture du CSS '{file_name}' pour l'intégration : {e}")
        return f"/* Erreur lecture CSS: {e} */"

# --- Fonction helper pour convertir image en base64 ---
def get_image_base64(image_path):
    """Convertit une image en base64 pour l'incorporation HTML."""
    import base64
    try:
        with open(image_path, "rb") as img_file:
            return base64.b64encode(img_file.read()).decode()
    except Exception as e:
        st.error(f"Erreur lors de la lecture de l'image: {e}")
        return ""

# --- Fonction pour détecter si on est sur mobile ---
def is_mobile_device():
    """Estimation si l'appareil est mobile basée sur la largeur de viewport."""
    # Si non défini ou première visite, définir par défaut comme non-mobile
    if 'is_mobile' not in st.session_state:
        st.session_state.is_mobile = False

    # JavaScript pour détecter la largeur d'écran et mettre à jour via le localStorage
    st.markdown("""
    <script>
    // Vérifier si l'appareil a une petite largeur d'écran
    const checkIfMobile = function() {
        const isMobile = window.innerWidth < 768;
        localStorage.setItem('streamlit_is_mobile', isMobile);
        return isMobile;
    };
    
    // Exécuter au chargement et à chaque redimensionnement
    checkIfMobile();
    window.addEventListener('resize', checkIfMobile);
    
    // Essayer de communiquer avec Streamlit
    window.addEventListener('message', function(event) {
        if (event.data.type === 'streamlit:render') {
            setTimeout(function() {
                const buttons = document.querySelectorAll('button[data-baseweb="button"]');
                if (buttons.length > 0) {
                    // Ajouter un attribut data-mobile pour utilisation future
                    buttons.forEach(function(button) {
                        button.setAttribute('data-is-mobile', checkIfMobile());
                    });
                }
            }, 500);
        }
    });
    </script>
    """, unsafe_allow_html=True)
    
    # Retourner la valeur actuelle
    return st.session_state.is_mobile

# --- Fonction pour adapter la mise en page en fonction de la détection mobile ---
def adapt_layout_for_mobile(is_mobile):
    """Adapte la mise en page en fonction de la détection mobile."""
    if is_mobile:
        # Style spécifique pour mobile
        st.markdown("""
        <style>
        /* Styles spécifiques pour mobile */
        .block-container {
            padding-left: 1rem !important;
            padding-right: 1rem !important;
            max-width: 100% !important;
        }
        
        /* Augmenter la taille des boutons pour faciliter l'interaction tactile */
        div.stButton > button {
            min-height: 44px !important;
            font-size: 16px !important;
            width: 100% !important;
        }
        
        /* Réduire les marges et paddings */
        div.stChatMessage {
            padding: 12px !important;
            margin-bottom: 12px !important;
        }
        
        /* Simplifier certains conteneurs */
        .main-header {
            padding: 15px !important;
            margin-bottom: 15px !important;
        }
        
        /* Adaptation de la sidebar */
        [data-testid="stSidebar"][aria-expanded="true"] {
            width: 85vw !important;
        }
        </style>
        """, unsafe_allow_html=True)
    else:
        # Style desktop normal
        pass

# --- Fonction pour afficher le résultat d'analyse avec un style amélioré ---
def display_analysis_result(analysis_response, analysis_details):
    """Affiche le résultat d'analyse avec un style amélioré."""
    st.markdown("""
    <style>
    .analysis-container {
        animation: fadeIn 0.6s ease-out;
        background: linear-gradient(to right, #f0f7ff, #e6f3ff);
        border-radius: 12px;
        padding: 20px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        margin-bottom: 25px;
        border-left: 5px solid #3B82F6;
    }
    .analysis-header {
        display: flex;
        align-items: center;
        margin-bottom: 15px;
        color: #1e40af;
    }
    .analysis-header h2 {
        margin: 0;
        font-size: 22px;
        font-weight: 600;
    }
    .analysis-header h2::before {
        content: "🔍 ";
        margin-right: 8px;
    }
    .analysis-section {
        background-color: white;
        border-radius: 8px;
        padding: 15px;
        margin-bottom: 15px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        border-left: 3px solid #60A5FA;
    }
    .analysis-section h3 {
        color: #3B82F6;
        font-size: 18px;
        margin-top: 0;
        margin-bottom: 10px;
    }
    </style>
    <div class="analysis-container">
        <div class="analysis-header">
            <h2>Analyse des documents</h2>
        </div>
    """, unsafe_allow_html=True)
    
    # Convertir le texte d'analyse en HTML avec sections
    content = analysis_response
    sections = content.split("**")
    
    for i in range(1, len(sections), 2):
        if i+1 < len(sections):
            section_title = sections[i].strip(":** ")
            section_content = sections[i+1]
            
            st.markdown(f"""
            <div class="analysis-section">
                <h3>{section_title}</h3>
                <div>{section_content}</div>
            </div>
            """, unsafe_allow_html=True)
    
    st.markdown("</div>", unsafe_allow_html=True)

# --- Fonction de vérification du mot de passe ET affichage page d'accueil/login ---
def display_login_or_app():
    """
    Affiche la page d'accueil statique et le formulaire de connexion si non connecté.
    Retourne True si l'utilisateur EST connecté (et l'application principale doit s'afficher),
    Retourne False si l'utilisateur N'EST PAS connecté (et le script doit s'arrêter).
    """

    # Initialiser l'état de connexion s'il n'existe pas
    if "logged_in" not in st.session_state:
        st.session_state.logged_in = False

    # Si déjà connecté, retourner True pour afficher l'app principale
    if st.session_state.logged_in:
        return True

    # --- Si non connecté : Afficher la page d'accueil STATIQUE et le LOGIN ---

    # Configuration de la page
    st.set_page_config(
        page_title="Connexion - Constructo AI 3.0",
        page_icon="🏗️",
        layout="wide",
        initial_sidebar_state="collapsed"
    )
    local_css("style.css") # Charger CSS

    # --- Créer les colonnes pour centrer le contenu statique ---
    _ , center_col, _ = st.columns([0.5, 3, 0.5], gap="large") # Ajustez les poids si nécessaire

    with center_col: # Tout le contenu statique va dans cette colonne centrale
        # >>>>> CONTENU STATIQUE DE LA PAGE D'ACCUEIL (AVANT LOGIN)

        # --- AJOUT DU LOGO CENTRÉ ---
        try:
            logo_path = os.path.join(os.path.dirname(__file__), "assets", "logo.png")
            if os.path.exists(logo_path):
                # Forcer le centrage avec CSS inline et base64
                st.markdown(
                    """
                    <div style='display: flex; justify-content: center; align-items: center; width: 100%;'>
                        <img src='data:image/png;base64,{}' style='width: 200px; height: auto;'>
                    </div>
                    """.format(get_image_base64(logo_path)),
                    unsafe_allow_html=True
                )
            else:
                st.warning("Logo 'assets/logo.png' non trouvé.")
        except Exception as e:
            st.error(f"Erreur logo: {e}")

        # Espace après le logo
        st.markdown("<br>", unsafe_allow_html=True)
        # --- FIN AJOUT DU LOGO ---

        # --- Titre principal centré avec style amélioré ---
        st.markdown("""
            <div class="main-header">
                <p>La plateforme intelligente qui révolutionne vos projets de construction au Québec</p>
            </div>
        """, unsafe_allow_html=True)

        # --- Section "Nos Solutions" avec cartes animées ---
        st.markdown("""
            <h2 style="text-align: center; margin-bottom: 20px;">Nos Solutions IA Clés</h2>
            <div class="solutions-container">
                <div class="solution-card">
                    <h3>🚀 TakeOff AI</h3>
                    <p>Automatisation du calcul des quantités et de l'estimation à l'aide d'une IA avancée pour analyser les plans et les documents de construction.</p>
                </div>
                <div class="solution-card">
                    <h3>📊 Project Manager AI</h3>
                    <p>Système de gestion de projet alimenté par l'IA qui prédit les retards, optimise les calendriers et gère les ressources de manière efficace.</p>
                </div>
                <div class="solution-card">
                    <h3>📦 Inventory AI</h3>
                    <p>Système intelligent de gestion des stocks avec commandes prédictives et capacités de suivi en temps réel.</p>
                </div>
            </div>
        """, unsafe_allow_html=True)

        st.divider()
        st.markdown("<h2 style='text-align: center;'>Notre mission</h2>", unsafe_allow_html=True)
        st.markdown("<h3 style='text-align: center; font-weight: normal;'>Révolutionner l'industrie de la construction</h3>", unsafe_allow_html=True)
        st.markdown("<p style='text-align: center; color: var(--text-color-light);'>Notre objectif est de fournir des outils intelligents et précis pour optimiser vos projets de construction</p>", unsafe_allow_html=True)
        st.markdown(" ")
        col1, col2, col3 = st.columns(3)
        with col1:
            st.markdown("""
            <div class="info-card" style="--delay: 1">
                <h4>⚡ Innovation IA</h4>
                <p>Utilisation de l'Intelligence Artificielle pour fournir des estimations et des recommandations pertinentes.</p>
            </div>
            """, unsafe_allow_html=True)
        with col2:
            st.markdown("""
            <div class="info-card" style="--delay: 2">
                <h4>📄 Expertise Construction</h4>
                <p>Une équipe passionnée avec plus de 20 ans d'expérience dans le secteur de la construction au Québec.</p>
            </div>
            """, unsafe_allow_html=True)
        with col3:
            st.markdown("""
            <div class="info-card" style="--delay: 3">
                <h4>🛡️ Conformité Réglementaire</h4>
                <p>Conformité stricte aux normes et règles de la construction au Québec.</p>
            </div>
            """, unsafe_allow_html=True)
        st.markdown(" ")

        # --- Section Fonctionnalités Détaillées ---
        st.divider()
        st.markdown("<p style='text-align: center; text-transform: uppercase; color: var(--text-color-light);'>Fonctionnalités Détaillées</p>", unsafe_allow_html=True)
        st.markdown("<h2 style='text-align: center;'>La plateforme intelligente pour la construction au Québec</h2>", unsafe_allow_html=True)
        st.markdown("<p style='text-align: center; color: var(--text-color-light);'>Gagnez du temps et réduisez vos coûts grâce à notre IA conçue pour la construction au Québec. Une plateforme complète pour estimer et optimiser vos projets.</p>", unsafe_allow_html=True)
        st.markdown(" ")
        fcol1, fcol2, fcol3 = st.columns(3)
        with fcol1:
            st.markdown("""
            <div class="info-card" style="--delay: 1">
                <h4>🧑‍🤝‍🧑 Espaces de travail collaboratif</h4>
                <p>Collaborez efficacement avec vos équipes, partagez et gérez vos devis en un seul endroit.</p>
            </div>
            """, unsafe_allow_html=True)
        with fcol2:
            st.markdown("""
            <div class="info-card" style="--delay: 2">
                <h4>💡 AI Estimations</h4>
                <p>Obtenez des estimations de coûts en quelques secondes sur la base des données actuelles du marché.</p>
            </div>
            """, unsafe_allow_html=True)
        with fcol3:
            st.markdown("""
            <div class="info-card" style="--delay: 3">
                <h4>💬 Assistant de construction</h4>
                <p>Un assistant IA spécialisé dans la réponse à vos questions techniques et réglementaires en temps réel.</p>
            </div>
            """, unsafe_allow_html=True)
        st.markdown(" ")
        fcol4, fcol5, fcol6 = st.columns(3)
        with fcol4:
            st.markdown("""
            <div class="info-card" style="--delay: 4">
                <h4>✅ Conformité RBQ</h4>
                <p>Assurez la conformité de vos projets aux normes québécoises grâce à notre vérification automatique.</p>
            </div>
            """, unsafe_allow_html=True)
        with fcol5:
            st.markdown("""
            <div class="info-card" style="--delay: 5">
                <h4>📖 Documentation technique</h4>
                <p>Base de connaissances complète sur les normes et règlements de construction du Québec.</p>
            </div>
            """, unsafe_allow_html=True)
        with fcol6:
            st.markdown("""
            <div class="info-card" style="--delay: 6">
                <h4>💰 Analyse financière</h4>
                <p>Outils d'analyse et d'optimisation des coûts basés sur les données actuelles du marché québécois.</p>
            </div>
            """, unsafe_allow_html=True)
        st.markdown(" ")
        fcol7, fcol8, fcol9 = st.columns(3)
        with fcol7:
            st.markdown("""
            <div class="info-card" style="--delay: 7">
                <h4>⏱️ Mises à jour quotidiennes</h4>
                <p>Mises à jour quotidiennes pour mieux estimer vos projets, vos équipes et les changements réglementaires.</p>
            </div>
            """, unsafe_allow_html=True)
        with fcol8:
            st.markdown("""
            <div class="info-card" style="--delay: 8">
                <h4>📄 Exportation facile</h4>
                <p>Exportez vos devis au format PDF en un seul clic.</p>
            </div>
            """, unsafe_allow_html=True)
        with fcol9:
            st.markdown("""
            <div class="info-card" style="--delay: 9">
                <h4>📈 Analyse</h4>
                <p>Analysez vos devis et plans tout au long du processus de construction (fichiers Excel et PDF).</p>
            </div>
            """, unsafe_allow_html=True)

        # --- SECTION Conformité et réglementation ---
        st.divider()
        st.markdown("<h2 style='text-align: center;'>Conformité et réglementation</h2>", unsafe_allow_html=True)
        st.markdown("<p style='text-align: center; color: var(--text-color-light);'>Constructo AI se conforme aux principales organisations du secteur de la construction au Québec</p>", unsafe_allow_html=True)
        st.markdown(" ")

        # Créer 3 lignes de 2 colonnes pour les 6 logos/textes
        reg_col1, reg_col2 = st.columns(2, gap="medium")
        with reg_col1:
            with st.container():
                st.markdown("""
                <div class="info-card" style="--delay: 1">
                    <p style='text-align: center; font-weight: 500;'>🏢 Régie du bâtiment du Québec (RBQ)</p>
                </div>
                """, unsafe_allow_html=True)
        with reg_col2:
            with st.container():
                st.markdown("""
                <div class="info-card" style="--delay: 2">
                    <p style='text-align: center; font-weight: 500;'>🏢 APCHQ</p>
                </div>
                """, unsafe_allow_html=True)

        st.markdown(" ") # Espace vertical

        reg_col3, reg_col4 = st.columns(2, gap="medium")
        with reg_col3:
            with st.container():
                st.markdown("""
                <div class="info-card" style="--delay: 3">
                    <p style='text-align: center; font-weight: 500;'>🏢 ACQ</p>
                </div>
                """, unsafe_allow_html=True)
        with reg_col4:
            with st.container():
                st.markdown("""
                <div class="info-card" style="--delay: 4">
                    <p style='text-align: center; font-weight: 500;'>📄 Commission de la construction du Québec</p>
                </div>
                """, unsafe_allow_html=True)

        st.markdown(" ") # Espace vertical

        reg_col5, reg_col6 = st.columns(2, gap="medium")
        with reg_col5:
            with st.container():
                st.markdown("""
                <div class="info-card" style="--delay: 5">
                    <p style='text-align: center; font-weight: 500;'>🎖️ Corporation des maîtres électriciens du Québec</p>
                </div>
                """, unsafe_allow_html=True)
        with reg_col6:
            with st.container():
                st.markdown("""
                <div class="info-card" style="--delay: 6">
                    <p style='text-align: center; font-weight: 500;'>🎖️ Corporation des maîtres mécaniciens en tuyauterie du Québec</p>
                </div>
                """, unsafe_allow_html=True)
        # --- FIN SECTION Conformité ---

        # >>>>> FIN DU CONTENU STATIQUE CENTRÉ

    # --- Formulaire de Connexion (reste centré comme avant, sous le contenu statique) ---
    st.divider()
    st.markdown("<h2 style='text-align: center;'>Connexion</h2>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center;'>Veuillez entrer le mot de passe pour accéder à l'application.</p>", unsafe_allow_html=True)

    # =====================================================
    # CORRECTION : Utiliser la même logique que app_old.py
    # =====================================================
    
    # Essayer d'abord les variables d'environnement (Render)
    correct_password = os.environ.get("APP_PASSWORD")
    if not correct_password:
        # Fallback vers les secrets Streamlit
        try:
            correct_password = st.secrets.get("APP_PASSWORD")
        except Exception: # StreamlitAPIException or AttributeError if secrets not set
            pass
    
    if not correct_password:
        st.error("Erreur de configuration: Mot de passe non défini. Veuillez définir la variable d'environnement 'APP_PASSWORD'.")
        st.info("Pour configurer dans Render, allez dans Dashboard > Votre app > Environment > Environment Variables")
        return False

    _, login_col, _ = st.columns([1, 1.5, 1])
    with login_col:
        password_attempt = st.text_input(
            "Mot de passe", type="password", key="password_input_login",
            label_visibility="collapsed", placeholder="Entrez votre mot de passe"
        )
        login_button = st.button("Se connecter", key="login_button", use_container_width=True)

    if login_button:
        if password_attempt == correct_password:
            st.session_state.logged_in = True
            st.rerun()
        else:
            st.error("Mot de passe incorrect.")

    return False # Non connecté


# --- Fonction de Génération HTML ---
def generate_html_report(messages, profile_name, conversation_id=None, client_name=""):
    """Génère un rapport HTML autonome à partir de l'historique."""
    custom_css = load_css_content("style.css")
    now = datetime.now().strftime("%d/%m/%Y à %H:%M:%S")
    conv_id_display = f" (ID: {conversation_id})" if conversation_id else ""
    client_display = f"<p><strong>Client :</strong> {html.escape(client_name)}</p>" if client_name else ""
    messages_html = ""
    md_converter = markdown.Markdown(extensions=['tables', 'fenced_code'])

    # Ajouter les styles supplémentaires pour l'export
    custom_css += """
    body {
        font-family: 'Inter', sans-serif;
        line-height: 1.6;
        color: #333;
        background-color: #f9fafb;
        padding: 2rem;
        max-width: 1200px;
        margin: 0 auto;
    }
    .report-header {
        background: linear-gradient(135deg, #3B82F6 0%, #1F2937 100%);
        padding: 2rem;
        border-radius: 12px;
        margin-bottom: 2rem;
        box-shadow: 0 4px 12px rgba(31, 41, 55, 0.25);
        text-align: center;
        color: white;
        border: 1px solid #374151;
    }
    .report-header h1 {
        margin: 0;
        color: white;
        font-size: 2.2rem;
        font-weight: 600;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.3);
    }
    .report-info {
        background: linear-gradient(135deg, #DBEAFE 0%, #FFFFFF 100%);
        border-radius: 12px;
        padding: 1.5rem;
        margin-bottom: 2rem;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.05);
        border-left: 5px solid #3B82F6;
    }
    .conversation-history {
        padding-top: 1.5rem;
    }
    .stChatMessage {
        margin-bottom: 1.5rem;
        padding: 1rem 1.2rem;
        border-radius: 0.5rem;
        box-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        animation: fadeIn 0.5s ease-out;
        position: relative;
        max-width: 85%;
    }
    .stChatMessage.user-bubble {
        background: linear-gradient(to right, #f0f7ff, #e6f3ff);
        border-left: 4px solid #60A5FA;
        margin-left: auto;
        margin-right: 0;
    }
    .stChatMessage.user-bubble::after {
        content: "";
        position: absolute;
        top: 15px;
        right: -10px;
        border-width: 10px 0 10px 10px;
        border-style: solid;
        border-color: transparent transparent transparent #e6f3ff;
    }
    .stChatMessage.assistant-bubble {
        background: linear-gradient(to right, #f7f9fc, #ffffff);
        border-left: 4px solid #3B82F6;
        margin-left: 0;
        margin-right: auto;
    }
    .stChatMessage.assistant-bubble::after {
        content: "";
        position: absolute;
        top: 15px;
        left: -10px;
        border-width: 10px 10px 10px 0;
        border-style: solid;
        border-color: transparent #f7f9fc transparent transparent;
    }
    .stChatMessage.search-bubble {
        background: linear-gradient(to right, #f0fdf4, #e6f7ec);
        border-left: 4px solid #22c55e;
        margin-right: 4rem;
        color: #14532D;
    }
    .stChatMessage.search-bubble .msg-content p,
    .stChatMessage.search-bubble .msg-content ul,
    .stChatMessage.search-bubble .msg-content ol {
        color: #14532D;
    }
    .stChatMessage.other-bubble {
        background: linear-gradient(to right, #DBEAFE 0%, #FFFFFF 100%);
        border-left: 4px solid #60A5FA;
    }
    .msg-content strong {
        font-weight: 600;
    }
    .msg-content table {
        font-size: 0.9em;
        width: 100%;
        border-collapse: collapse;
        margin: 1em 0;
        box-shadow: 0 1px 2px 0 rgb(0 0 0 / 0.05);
        border-radius: 0.375rem;
        overflow: hidden;
    }
    .msg-content th, .msg-content td {
        border: 1px solid #E5E7EB;
        padding: 0.6em 0.9em;
        text-align: left;
    }
    .msg-content th {
        background-color: #F3F4F6;
        font-weight: 500;
        color: #374151;
    }
    .msg-content tr:nth-child(even) {
        background-color: #F9FAFB;
    }
    .msg-content tr:hover {
        background-color: #DBEAFE;
    }
    .msg-content pre {
        background-color: #1F2937;
        color: #F9FAFB;
        padding: 1em;
        border-radius: 0.5rem;
        overflow-x: auto;
        border: 1px solid #4B5563;
        margin: 1em 0;
        font-size: 0.85rem;
        line-height: 1.5;
    }
    .msg-content pre code {
        background-color: transparent;
        color: inherit;
        padding: 0;
        margin: 0;
        font-size: inherit;
        border-radius: 0;
        font-family: "monospace", monospace;
        display: block;
        white-space: pre;
        line-height: 1.5;
    }
    .msg-content code {
        background-color: #E5E7EB;
        padding: 0.2em 0.4em;
        margin: 0 0.1em;
        font-size: 85%;
        border-radius: 0.375rem;
        font-family: "monospace", monospace;
        color: #374151;
    }
    section[data-testid=stSidebar],
    div[data-testid=stChatInput],
    .stButton,
    div[data-testid="stToolbar"],
    div[data-testid="stDecoration"] {
        display: none !important;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    /* Responsive design */
    @media (max-width: 768px) {
        body {
            padding: 1rem;
        }
        .report-header {
            padding: 1.5rem;
        }
        .report-header h1 {
            font-size: 1.8rem;
        }
        .stChatMessage {
            max-width: 95%;
            padding: 0.8rem 1rem;
        }
        .stChatMessage.user-bubble,
        .stChatMessage.assistant-bubble {
            margin-left: 0;
            margin-right: 0;
        }
        .stChatMessage.user-bubble::after,
        .stChatMessage.assistant-bubble::after {
            display: none;
        }
    }
    """

    for msg in messages:
        role = msg.get("role", "unknown")
        content = msg.get("content", "*Message vide*")

        if role == "system": 
            continue

        try:
            md_converter.reset()
            content_str = str(content) if not isinstance(content, str) else content
            content_html = md_converter.convert(content_str)
        except Exception as e:
            print(f"Erreur conversion Markdown: {e}")
            content_html = f"<p>{html.escape(str(content)).replace(chr(10), '<br/>')}</p>"

        # Déterminer le style de bulle et le label
        if role == "user":
            bubble_class = "user-bubble"
            role_label = "Utilisateur"
        elif role == "assistant":
            bubble_class = "assistant-bubble"
            role_label = f"Expert ({html.escape(profile_name)})"
        elif role == "search_result":
            bubble_class = "search-bubble"
            role_label = "Résultat Recherche Web"
        else:
            bubble_class = "other-bubble"
            role_label = html.escape(role.capitalize())

        messages_html += f'''
        <div class="stChatMessage {bubble_class}">
            <strong>{role_label} :</strong>
            <div class="msg-content">{content_html}</div>
        </div>
        '''

    html_output = f"""<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapport Constructo AI - {html.escape(profile_name)}{conv_id_display}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>{custom_css}</style>
</head>
<body>
    <div class="report-header">
        <h1>🏗️ Rapport Constructo AI</h1>
    </div>
    <div class="report-info">
        <p><strong>Expert :</strong> {html.escape(profile_name)}</p>
        {client_display}
        <p><strong>Date :</strong> {now}</p>
        <p><strong>ID Conversation :</strong> {html.escape(str(conversation_id)) if conversation_id else 'N/A'}</p>
    </div>
    <div class="conversation-history">
        {messages_html}
    </div>
</body>
</html>"""
    
    return html_output
   
# --- [DEBUT DE LA SECTION FUSIONNÉE] Fonction pour exporter un message individuel (de la Version 02) ---
def generate_single_message_html(message_content, message_role, profile_name, message_index=0, timestamp=None):
    """Génère HTML pour un message individuel avec style professionnel amélioré."""
    
    if not timestamp:
        timestamp = datetime.now().strftime("%d/%m/%Y à %H:%M:%S")
    
    base_css = load_css_content("style.css")
    
    if message_role == "user":
        role_display = "Utilisateur"
        bubble_class = "user-bubble"
        avatar_icon = "👤"
        header_color = "#60A5FA"
        gradient_colors = "#f0f7ff, #e6f3ff"
    elif message_role == "search_result":
        role_display = "Résultat Recherche Web"
        bubble_class = "search-bubble"
        avatar_icon = "🔎"
        header_color = "#22c55e"
        gradient_colors = "#f0fdf4, #e6f7ec"
    else:
        role_display = f"Expert ({profile_name})"
        bubble_class = "assistant-bubble"
        avatar_icon = "🏗️"
        header_color = "#3B82F6"
        gradient_colors = "#f7f9fc, #ffffff"
    
    # Conversion markdown avec gestion d'erreurs robuste
    try:
        md_converter = markdown.Markdown(extensions=['tables', 'fenced_code', 'codehilite'])
        md_converter.reset()
        content_html = md_converter.convert(str(message_content))
    except Exception as e:
        print(f"Erreur conversion Markdown: {e}")
        # Fallback sécurisé
        escaped_content = html.escape(str(message_content))
        content_html = f"<p>{escaped_content.replace(chr(10), '<br/>')}</p>"
    
    # CSS spécialisé avec tous les styles du rapport + styles spécifiques au message individuel
    specialized_css = f"""
    {base_css}
    
    body {{
        max-width: 1000px;
        margin: 20px auto;
        padding: 20px;
        background-color: #f9fafb;
        font-family: 'Inter', sans-serif;
        line-height: 1.6;
        color: #333;
    }}
    
    .single-message-container {{
        background: white;
        border-radius: 16px;
        box-shadow: 0 8px 24px rgba(0, 0, 0, 0.12);
        padding: 0;
        overflow: hidden;
        border: 1px solid #e5e7eb;
        animation: fadeIn 0.8s ease-out;
    }}
    
    .message-header {{
        background: linear-gradient(135deg, {header_color}15 0%, {header_color}08 100%);
        padding: 25px 30px;
        border-bottom: 1px solid #e5e7eb;
        border-left: 5px solid {header_color};
        position: relative;
        overflow: hidden;
    }}
    
    .message-header::before {{
        content: "";
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent 0%, rgba(255, 255, 255, 0.3) 50%, transparent 100%);
        animation: header-shine 3s infinite;
        z-index: 1;
    }}
    
    .message-header h1 {{
        margin: 0;
        color: {header_color};
        font-size: 1.9rem;
        display: flex;
        align-items: center;
        gap: 12px;
        font-weight: 700;
        position: relative;
        z-index: 2;
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
    }}
    
    .message-meta {{
        margin-top: 15px;
        font-size: 0.9rem;
        color: #6b7280;
        display: flex;
        gap: 25px;
        flex-wrap: wrap;
        position: relative;
        z-index: 2;
    }}
    
    .meta-item {{
        display: flex;
        align-items: center;
        gap: 6px;
        background: rgba(255, 255, 255, 0.7);
        padding: 4px 8px;
        border-radius: 6px;
        font-weight: 500;
    }}
    
    .message-content {{ 
        padding: 30px;
        line-height: 1.7;
        background: linear-gradient(to right, {gradient_colors});
        border-left: 4px solid {header_color};
        position: relative;
    }}
    
    /* Styles pour le contenu - identiques au rapport */
    .message-content h1, .message-content h2, .message-content h3 {{
        color: #1f2937;
        font-weight: 700;
        margin-top: 1.5em;
        margin-bottom: 0.8em;
    }}
    
    .message-content h1 {{
        font-size: 1.8rem;
        border-bottom: 3px solid {header_color};
        padding-bottom: 8px;
    }}
    
    .message-content h2 {{
        font-size: 1.4rem;
        color: {header_color};
    }}
    
    .message-content h3 {{
        font-size: 1.2rem;
        color: #374151;
    }}
    
    .message-content table {{
        width: 100%;
        border-collapse: collapse;
        margin: 1.5em 0;
        font-size: 0.9rem;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        border-radius: 8px;
        overflow: hidden;
        background: white;
    }}
    
    .message-content th, .message-content td {{
        border: 1px solid #e5e7eb;
        padding: 12px 15px;
        text-align: left;
    }}
    
    .message-content th {{
        background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
        font-weight: 600;
        color: #374151;
        border-bottom: 2px solid #d1d5db;
        position: relative;
    }}
    
    .message-content tr:nth-child(even) {{
        background-color: #f9fafb;
    }}
    
    .message-content tr:hover {{
        background: linear-gradient(to right, #dbeafe, #f0f7ff);
        transform: translateX(2px);
        transition: all 0.3s ease;
    }}
    
    .message-content strong {{
        font-weight: 700;
        color: #1f2937;
    }}
    
    .message-content code {{
        background: linear-gradient(135deg, #e5e7eb 0%, #f3f4f6 100%);
        padding: 3px 6px;
        margin: 0 2px;
        font-size: 0.9em;
        border-radius: 4px;
        font-family: 'Monaco', 'Menlo', monospace;
        color: #374151;
        border: 1px solid #d1d5db;
    }}
    
    .message-content pre {{
        background: linear-gradient(135deg, #1f2937 0%, #111827 100%);
        color: #f9fafb;
        padding: 20px;
        border-radius: 8px;
        overflow-x: auto;
        border: 1px solid #4b5563;
        margin: 1.5em 0;
        font-size: 0.85rem;
        line-height: 1.6;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }}
    
    .message-content pre code {{
        background: transparent;
        color: inherit;
        padding: 0;
        margin: 0;
        font-size: inherit;
        border: none;
        border-radius: 0;
    }}
    
    .message-content hr {{
        border: none;
        height: 2px;
        background: linear-gradient(90deg, transparent 0%, {header_color} 50%, transparent 100%);
        margin: 2em 0;
    }}
    
    .message-content ol, .message-content ul {{
        padding-left: 1.5em;
        margin: 1em 0;
    }}
    
    .message-content li {{
        margin-bottom: 0.5em;
        line-height: 1.6;
    }}
    
    .export-footer {{
        text-align: center;
        padding: 25px;
        border-top: 1px solid #e5e7eb;
        background: linear-gradient(135deg, #f9fafb 0%, #ffffff 100%);
        font-size: 0.85rem;
        color: #6b7280;
    }}
    
    .export-footer .logo {{
        color: {header_color};
        font-weight: 700;
        font-size: 1.1rem;
        margin-bottom: 8px;
    }}
    
    /* Animations */
    @keyframes fadeIn {{
        from {{ opacity: 0; transform: translateY(20px); }}
        to {{ opacity: 1; transform: translateY(0); }}
    }}
    
    @keyframes header-shine {{
        0%, 50% {{ left: -100%; }}
        100% {{ left: 100%; }}
    }}
    
    /* Responsive design amélioré */
    @media (max-width: 768px) {{
        body {{ padding: 15px; }}
        .single-message-container {{ border-radius: 12px; }}
        .message-header {{ padding: 20px; }}
        .message-header h1 {{ font-size: 1.6rem; }}
        .message-content {{ padding: 20px; }}
        .message-meta {{ gap: 15px; }}
        .meta-item {{ font-size: 0.8rem; }}
        .message-content table {{ font-size: 0.8rem; }}
        .message-content th, .message-content td {{ padding: 8px 10px; }}
    }}
    
    @media (max-width: 480px) {{
        body {{ padding: 10px; }}
        .message-header {{ padding: 15px; }}
        .message-header h1 {{ font-size: 1.4rem; }}
        .message-content {{ padding: 15px; }}
        .message-meta {{ flex-direction: column; gap: 8px; }}
    }}
    """
    
    html_content = f"""<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message Constructo AI - {role_display}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>{specialized_css}</style>
</head>
<body>
    <div class="single-message-container">
        <div class="message-header">
            <h1>{avatar_icon} {html.escape(role_display)}</h1>
            <div class="message-meta">
                <div class="meta-item">
                    <span>📅</span>
                    <span>Exporté le {timestamp}</span>
                </div>
                <div class="meta-item">
                    <span>#️⃣</span>
                    <span>Message #{message_index + 1}</span>
                </div>
                <div class="meta-item">
                    <span>📏</span>
                    <span>{len(str(message_content)):,} caractères</span>
                </div>
                <div class="meta-item">
                    <span>🏷️</span>
                    <span>Type: {message_role.title()}</span>
                </div>
            </div>
        </div>
        <div class="message-content">
            {content_html}
        </div>
        <div class="export-footer">
            <div class="logo">🏗️ Constructo AI 3.0</div>
            <p><strong>Assistant IA Spécialisé en Construction au Québec</strong></p>
            <p>Développé par Sylvain Leduc - <a href="mailto:info@constructoai.ca" style="color: {header_color};">info@constructoai.ca</a></p>
            <p><small>Document généré automatiquement • Tous droits réservés</small></p>
        </div>
    </div>
</body>
</html>"""
    
    return html_content
# --- [FIN DE LA SECTION FUSIONNÉE] ---

# --- Helper Functions (Application Logic) ---
def start_new_consultation():
    """Réinitialise l'état pour une nouvelle conversation."""
    st.session_state.messages = []
    st.session_state.current_conversation_id = None
    st.session_state.processed_messages = set()
    
    # Réinitialiser aussi l'état des autres modules
    st.session_state.show_project_manager = False
    st.session_state.show_knowledge_base = False  # NOUVEAU
    st.session_state.show_inventory_manager = False # NOUVEAU
    
    profile_name = "par défaut"
    if 'expert_advisor' in st.session_state:
        profile = st.session_state.expert_advisor.get_current_profile()
        profile_name = profile.get('name', 'par défaut') if profile else "par défaut"
    
    # Message d'accueil mis à jour
    st.session_state.messages.append({
        "role": "assistant",
        "content": f"Bonjour! Je suis votre expert {profile_name}. Comment puis-je vous aider aujourd'hui?\n\n"
                   f"💡 **Modules disponibles**:\n"
                   f"• **Gestionnaire de Projet** : Gérez vos projets de construction\n"
                   f"• **Base de Connaissances** : Créez vos propres experts IA personnalisés\n"
                   f"• **Inventaire IA** : Gestion intelligente de vos stocks de matériaux\n\n"
                   f"**Commandes rapides :**\n"
                   f"• `/search` + question → Recherche web\n"
                   f"• `/projet dashboard` → Gestion de projets\n"
                   f"• `/kb dashboard` → Base de connaissances\n"
                   f"• `/inventaire dashboard` → Inventaire IA"
    })
    
    # Nettoyer les variables d'état
    for key in ['html_download_data', 'single_message_download', 'show_copy_content', 'files_to_analyze']:
        if key in st.session_state:
            del st.session_state[key]
    
    st.rerun()

def load_selected_conversation(conv_id):
    """Charge une conversation depuis la base de données."""
    if st.session_state.conversation_manager:
        messages = st.session_state.conversation_manager.load_conversation(conv_id)
        if messages is not None:
            st.session_state.messages = messages
            st.session_state.current_conversation_id = conv_id
            st.session_state.processed_messages = set()
            if 'html_download_data' in st.session_state: del st.session_state.html_download_data
            if 'single_message_download' in st.session_state: del st.session_state.single_message_download
            if 'show_copy_content' in st.session_state: del st.session_state.show_copy_content
            if "files_to_analyze" in st.session_state: del st.session_state.files_to_analyze
            st.success(f"Consultation {conv_id} chargée.")
            st.rerun()
        else:
            st.error(f"Erreur lors du chargement de la conversation {conv_id}.")
    else:
        st.error("Gestionnaire de conversations indisponible.")

def delete_selected_conversation(conv_id):
    """Supprime une conversation de la base de données."""
    if st.session_state.conversation_manager:
        print(f"Tentative suppression conv {conv_id}")
        success = st.session_state.conversation_manager.delete_conversation(conv_id)
        if success:
            st.success(f"Consultation {conv_id} supprimée.")
            if st.session_state.current_conversation_id == conv_id:
                st.session_state.show_project_manager = False  # Revenir au chat principal
                st.session_state.show_knowledge_base = False   # NOUVEAU
                st.session_state.show_inventory_manager = False # NOUVEAU
                start_new_consultation() # Rerun inclus
            else:
                if 'html_download_data' in st.session_state: del st.session_state.html_download_data
                if 'single_message_download' in st.session_state: del st.session_state.single_message_download
                if 'show_copy_content' in st.session_state: del st.session_state.show_copy_content
                st.rerun() # Juste pour rafraîchir la liste
        else:
            st.error(f"Impossible de supprimer conv {conv_id}.")
    else:
        st.error("Gestionnaire de conversations indisponible.")

def save_current_conversation():
    """Sauvegarde la conversation actuelle (messages) dans la DB."""
    should_save = True
    if st.session_state.conversation_manager and st.session_state.messages:
        is_initial_greeting_only = (
            len(st.session_state.messages) == 1 and
            st.session_state.messages[0].get("role") == "assistant" and
            st.session_state.messages[0].get("content", "").startswith("Bonjour!") and
            st.session_state.current_conversation_id is None
        )
        if is_initial_greeting_only: should_save = False

        if should_save:
            try:
                new_id = st.session_state.conversation_manager.save_conversation(
                    st.session_state.current_conversation_id,
                    st.session_state.messages
                )
                if new_id is not None and st.session_state.current_conversation_id is None:
                    st.session_state.current_conversation_id = new_id
            except Exception as e:
                st.warning(f"Erreur sauvegarde auto: {e}")
                st.exception(e)

# --- Fonction Export Sidebar Section ---
def create_export_sidebar_section():
    """Section d'export complète pour la sidebar."""
    
    st.markdown('<div class="sidebar-subheader">📥 EXPORT</div>', unsafe_allow_html=True)
    
    # Export conversation complète (conserver l'existant)
    client_name_export = st.text_input("Nom client (optionnel)", key="client_name_export", placeholder="Pour rapport HTML")
    
    st.markdown("""
    <style>
    div.stButton > button:has(span:contains("Rapport HTML")) {
        background: linear-gradient(90deg, #93c5fd 0%, #60a5fa 100%) !important;
        color: white !important; font-weight: 600 !important; border: none !important;
    }
    div.stButton > button:has(span:contains("Rapport HTML"))::before { content: "📄 " !important; }
    div.stButton > button:has(span:contains("Rapport HTML")):hover {
        background: linear-gradient(90deg, #60a5fa 0%, #3b82f6 100%) !important;
        transform: translateY(-2px) !important; box-shadow: 0 4px 8px rgba(59, 130, 246, 0.2) !important;
    }
    div.stButton > button:has(span:contains("Télécharger HTML")) {
        background: linear-gradient(90deg, #bbf7d0 0%, #86efac 100%) !important;
        color: #166534 !important; font-weight: 600 !important; border: none !important;
    }
    div.stButton > button:has(span:contains("Télécharger HTML"))::before { content: "⬇️ " !important; }
    div.stButton > button:has(span:contains("Télécharger HTML")):hover {
        background: linear-gradient(90deg, #86efac 0%, #4ade80 100%) !important;
        transform: translateY(-2px) !important; box-shadow: 0 4px 8px rgba(22, 101, 52, 0.2) !important;
    }
    </style>
    """, unsafe_allow_html=True)
    
    if st.button("Rapport HTML", key="gen_html_btn", use_container_width=True, help="Générer rapport HTML"):
        st.session_state.html_download_data = None
        can_generate = True
        if not st.session_state.messages or (len(st.session_state.messages) == 1 and st.session_state.messages[0].get("role") == "assistant" and st.session_state.messages[0].get("content", "").startswith("Bonjour!")):
            can_generate = False
        if not can_generate:
            st.warning("Conversation vide ou initiale.")
        else:
            with st.spinner("Génération HTML..."):
                try:
                    profile_name = "Expert"
                    current_profile = st.session_state.expert_advisor.get_current_profile() if 'expert_advisor' in st.session_state else None
                    if current_profile: profile_name = current_profile.get('name', 'Expert')
                    conv_id = st.session_state.current_conversation_id
                    html_string = generate_html_report(st.session_state.messages, profile_name, conv_id, client_name_export)
                    if html_string:
                        id_part = f"Conv{conv_id}" if conv_id else datetime.now().strftime('%Y%m%d_%H%M')
                        filename = f"Rapport_Constructo_AI_{id_part}.html"
                        st.session_state.html_download_data = {"data": html_string, "filename": filename}
                        st.success("Rapport prêt.")
                    else:
                        st.error("Échec génération HTML.")
                except Exception as e:
                    st.error(f"Erreur génération HTML: {e}")
                    st.exception(e)
        st.rerun()
        
    if st.session_state.get('html_download_data'):
        download_info = st.session_state.html_download_data
        st.download_button(
            label="⬇️ Télécharger HTML",
            data=download_info["data"].encode("utf-8"),
            file_name=download_info["filename"],
            mime="text/html",
            key="dl_html",
            use_container_width=True,
            on_click=lambda: st.session_state.update(html_download_data=None)
        )
    
    # === NOUVELLE SECTION : EXPORT MESSAGES INDIVIDUELS ===
    st.markdown("---")
    st.markdown('<div class="sidebar-subheader">📤 MESSAGES INDIVIDUELS</div>', unsafe_allow_html=True)
    
    if not st.session_state.messages:
        st.caption("Aucun message à exporter.")
        return
    
    # Filtrer les messages exportables
    exportable_messages = []
    for i, msg in enumerate(st.session_state.messages):
        if msg.get("role") in ["assistant", "search_result"] and msg.get("content", "").strip():
            role_display = "🏗️ Expert" if msg["role"] == "assistant" else "🔎 Recherche"
            content_preview = str(msg["content"])[:40] + "..." if len(str(msg["content"])) > 40 else str(msg["content"])
            exportable_messages.append({
                "index": i,
                "display": f"{role_display}: {content_preview}",
                "role": msg["role"],
                "content": msg["content"]
            })
    
    if not exportable_messages:
        st.caption("Aucun message expert à exporter.")
        return
    
    # Sélecteur de message
    selected_msg = st.selectbox(
        "Message à exporter:",
        options=exportable_messages,
        format_func=lambda x: x["display"],
        key="export_message_selector",
        label_visibility="collapsed"
    )
    
    if selected_msg:
        # Aperçu condensé
        with st.expander("👀 Aperçu", expanded=False):
            content_preview = str(selected_msg['content'])
            if len(content_preview) > 150:
                st.markdown(content_preview[:150] + "...")
                st.caption(f"Total: {len(content_preview)} caractères")
            else:
                st.markdown(content_preview)
        
        # Boutons d'export
        if st.button("📄 Exporter en HTML", key="export_single_html", use_container_width=True):
            try:
                profile = st.session_state.expert_advisor.get_current_profile()
                profile_name = profile.get('name', 'Expert') if profile else 'Expert'
                
                html_content = generate_single_message_html(
                    selected_msg['content'], 
                    selected_msg['role'], 
                    profile_name, 
                    selected_msg['index']
                )
                
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = f"Message_ConstructoAI_{selected_msg['role']}_{selected_msg['index']}_{timestamp}.html"
                
                # Stocker pour téléchargement
                st.session_state.single_message_download = {
                    "data": html_content,
                    "filename": filename
                }
                
                st.success("✅ Fichier prêt pour téléchargement")
                st.rerun()
                
            except Exception as e:
                st.error(f"Erreur lors de l'export: {e}")
        
        # Bouton de téléchargement si prêt
        if st.session_state.get('single_message_download'):
            download_data = st.session_state.single_message_download
            st.download_button(
                label="⬇️ Télécharger HTML",
                data=download_data["data"].encode('utf-8'),
                file_name=download_data["filename"],
                mime="text/html",
                key="download_single_message",
                use_container_width=True,
                on_click=lambda: st.session_state.pop('single_message_download', None)
            )
        
        # Option copie texte
        if st.button("📋 Afficher pour Copie", key="show_for_copy", use_container_width=True):
            st.session_state.show_copy_content = selected_msg['content']
            st.rerun()
        
        # Affichage pour copie si demandé
        if st.session_state.get('show_copy_content'):
            st.text_area(
                "Contenu à copier:",
                value=st.session_state.show_copy_content,
                height=150,
                key="copy_content_area"
            )
            if st.button("❌ Fermer", key="close_copy"):
                st.session_state.pop('show_copy_content', None)
                st.rerun()


# --- Exécution Principale ---

# >>>>> AFFICHAGE CONDITIONNEL : LOGIN ou APP
if not display_login_or_app():
    st.stop() # Arrête l'exécution si display_login_or_app retourne False (non connecté)

# --- SI CONNECTÉ, LE SCRIPT CONTINUE ICI ---

# --- Configuration de la Page Principale ---
st.set_page_config(
    page_title="Constructo AI 3.0",
    page_icon="🏗️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- Charger Police Google Font & CSS pour l'App ---
st.markdown("""
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        /* Styles inline spécifiques à l'UI Streamlit (peuvent être dans style.css) */
        .sidebar-subheader {
            margin-top: 1.5rem; margin-bottom: 0.5rem; font-size: 0.875rem;
            font-weight: 500; color: var(--text-color-light);
            text-transform: uppercase; letter-spacing: 0.05em;
        }
        /* Styles pour l'historique dans la sidebar */
        div[data-testid="stHorizontalBlock"] > div:nth-child(1) button[kind="secondary"] {
            text-align: left; justify-content: flex-start !important;
            overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
            font-size: 0.9rem; padding: 0.4rem 0.6rem;
            border: 1px solid transparent; background-color: transparent;
            color: var(--text-color); transition: background-color 0.2s ease, border-color 0.2s ease;
        }
        div[data-testid="stHorizontalBlock"] > div:nth-child(1) button[kind="secondary"]:hover {
            background-color: var(--border-color-light); border-color: var(--border-color);
        }
        div[data-testid="stHorizontalBlock"] > div:nth-child(2) button[kind="secondary"] {
            background: none; border: none; color: var(--text-color-light); cursor: pointer;
            padding: 0.4rem 0.3rem; font-size: 0.9rem; line-height: 1;
        }
        div[data-testid="stHorizontalBlock"] > div:nth-child(2) button[kind="secondary"]:hover {
            color: #EF4444; background-color: rgba(239, 68, 68, 0.1);
        }

        /* Styles pour la base de connaissances */
        .kb-card {
            background: linear-gradient(135deg, #f0f7ff 0%, #e6f3ff 100%);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
            border-left: 4px solid #3B82F6;
            transition: all 0.3s ease;
        }

        .kb-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.15);
        }

        .kb-profile-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border-left: 3px solid #10B981;
        }

        .kb-document-card {
            background: #f8fafc;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 8px;
            border-left: 3px solid #6366F1;
        }

        .kb-tag {
            display: inline-block;
            background: #DBEAFE;
            color: #1E40AF;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            margin-right: 5px;
            margin-bottom: 3px;
        }

        .kb-stats-container {
            background: linear-gradient(135deg, #f0fdf4 0%, #ffffff 100%);
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #bbf7d0;
        }

        /* Boutons spéciaux base de connaissances */
        div.stButton > button:has(span:contains("Ouvrir Base Connaissances")) {
            background: linear-gradient(90deg, #a78bfa 0%, #8b5cf6 100%) !important;
            color: white !important;
            font-weight: 600 !important;
        }

        div.stButton > button:has(span:contains("Ouvrir Base Connaissances"))::before {
            content: "🧠 " !important;
        }

        div.stButton > button:has(span:contains("Ouvrir Base Connaissances")):hover {
            background: linear-gradient(90deg, #8b5cf6 0%, #7c3aed 100%) !important;
            transform: translateY(-2px) !important;
            box-shadow: 0 4px 8px rgba(139, 92, 246, 0.3) !important;
        }

        div.stButton > button:has(span:contains("Créer le Profil Expert")) {
            background: linear-gradient(90deg, #10b981 0%, #059669 100%) !important;
            color: white !important;
            font-weight: 600 !important;
        }

        div.stButton > button:has(span:contains("Utiliser ce Profil")) {
            background: linear-gradient(90deg, #3b82f6 0%, #2563eb 100%) !important;
            color: white !important;
            font-weight: 600 !important;
        }
        
        /* Styles pour l'inventaire */
        .inventory-card {
            background: linear-gradient(135deg, #f0f9ff 0%, #e6f3ff 100%);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 8px rgba(59, 130, 246, 0.1);
            border-left: 4px solid #3B82F6;
            transition: all 0.3s ease;
        }

        .inventory-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(59, 130, 246, 0.15);
        }

        .inventory-item-card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            border-left: 3px solid #10B981;
        }

        .inventory-alert-card {
            background: #fef2f2;
            border-radius: 8px;
            padding: 12px;
            margin-bottom: 8px;
            border-left: 3px solid #EF4444;
        }

        .inventory-stats-container {
            background: linear-gradient(135deg, #f0fdf4 0%, #ffffff 100%);
            border-radius: 12px;
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid #bbf7d0;
        }

        /* Boutons spéciaux inventaire */
        div.stButton > button:has(span:contains("Ouvrir Inventaire")) {
            background: linear-gradient(90deg, #d1fae5 0%, #a7f3d0 100%) !important;
            color: #065f46 !important;
            font-weight: 600 !important;
        }

        div.stButton > button:has(span:contains("Ouvrir Inventaire"))::before {
            content: "📦 " !important;
        }

        div.stButton > button:has(span:contains("Ouvrir Inventaire")):hover {
            background: linear-gradient(90deg, #a7f3d0 0%, #6ee7b7 100%) !important;
            transform: translateY(-2px) !important;
            box-shadow: 0 4px 8px rgba(6, 95, 70, 0.2) !important;
        }
    </style>
""", unsafe_allow_html=True)
local_css("style.css") # Recharger pour s'assurer que les styles de l'app sont appliqués

# --- Détection de l'appareil mobile ---
is_mobile = is_mobile_device()
adapt_layout_for_mobile(is_mobile)

# --- Load API Keys ---
load_dotenv() # Pour le dev local si .env existe

# =====================================================
# CORRECTION : Logique de fallback pour l'API key
# =====================================================
ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")
if not ANTHROPIC_API_KEY:
    try:
        ANTHROPIC_API_KEY = st.secrets.get("ANTHROPIC_API_KEY")
    except Exception:
        pass

# CORRECTION : Logique pour APP_PASSWORD 
APP_PASSWORD = os.environ.get("APP_PASSWORD")
if not APP_PASSWORD:
    try:
        APP_PASSWORD = st.secrets.get("APP_PASSWORD")
    except Exception:
        pass


# --- Initialize Logic Classes & Conversation Manager ---
if 'profile_manager' not in st.session_state:
    try:
        profile_dir_path = "profiles"
        if not os.path.exists(profile_dir_path):
            os.makedirs(profile_dir_path, exist_ok=True); print(f"Dossier '{profile_dir_path}' créé.")
            default_profile_path = os.path.join(profile_dir_path, "default_expert.txt")
            if not os.path.exists(default_profile_path):
                with open(default_profile_path, "w", encoding="utf-8") as f: f.write("Expert par Défaut\nJe suis un expert IA généraliste."); print("Profil par défaut créé.")
        st.session_state.profile_manager = ExpertProfileManager(profile_dir=profile_dir_path)
        print("ProfileManager initialisé.")
    except Exception as e: st.error(f"Erreur critique: Init ProfileManager: {e}"); st.stop()

if 'expert_advisor' not in st.session_state:
    if not ANTHROPIC_API_KEY: st.error("Erreur critique: ANTHROPIC_API_KEY non configurée."); st.stop()
    try:
        st.session_state.expert_advisor = ExpertAdvisor(api_key=ANTHROPIC_API_KEY)
        st.session_state.expert_advisor.profile_manager = st.session_state.profile_manager
        print("ExpertAdvisor initialisé.")
        available_profiles = st.session_state.profile_manager.get_profile_names()
        if available_profiles:
            initial_profile_name = available_profiles[0]
            st.session_state.selected_profile_name = initial_profile_name
            st.session_state.expert_advisor.set_current_profile_by_name(initial_profile_name)
            print(f"Profil initial chargé: {initial_profile_name}")
        else:
            st.warning("Aucun profil expert trouvé. Utilisation profil par défaut.")
            default_profile = st.session_state.expert_advisor.get_current_profile()
            st.session_state.selected_profile_name = default_profile.get("name", "Expert (Défaut)")
    except Exception as e: st.error(f"Erreur critique: Init ExpertAdvisor: {e}"); st.exception(e); st.stop()

if 'conversation_manager' not in st.session_state:
    try:
        db_file_path = "conversations.db"
        st.session_state.conversation_manager = ConversationManager(db_path=db_file_path)
        print(f"ConversationManager initialisé avec DB: {os.path.abspath(db_file_path)}")
    except Exception as e: st.error(f"Erreur: Init ConversationManager: {e}"); st.exception(e); st.session_state.conversation_manager = None; st.warning("Historique désactivé.")

# Initialisation du gestionnaire de projet
if 'project_manager' not in st.session_state:
    try:
        project_db_path = "projects.db"
        st.session_state.project_manager = ProjectManager(db_path=project_db_path)
        print(f"ProjectManager initialisé avec DB: {os.path.abspath(project_db_path)}")
    except Exception as e:
        st.error(f"Erreur: Init ProjectManager: {e}")
        st.exception(e)
        st.session_state.project_manager = None
        st.warning("Gestionnaire de projet désactivé.")

if 'project_ui' not in st.session_state and st.session_state.get('project_manager'):
    try:
        st.session_state.project_ui = ProjectUI(st.session_state.project_manager)
        print("ProjectUI initialisé.")
    except Exception as e:
        st.error(f"Erreur: Init ProjectUI: {e}")
        st.session_state.project_ui = None

# Initialisation du gestionnaire d'inventaire
if 'inventory_manager' not in st.session_state:
    try:
        inventory_db_path = "inventory.db"
        st.session_state.inventory_manager = InventoryManager(db_path=inventory_db_path)
        print(f"InventoryManager initialisé avec DB: {os.path.abspath(inventory_db_path)}")
    except Exception as e:
        st.error(f"Erreur: Init InventoryManager: {e}")
        st.exception(e)
        st.session_state.inventory_manager = None
        st.warning("Gestionnaire d'inventaire désactivé.")

if 'inventory_ui' not in st.session_state and st.session_state.get('inventory_manager'):
    try:
        st.session_state.inventory_ui = InventoryUI(st.session_state.inventory_manager)
        print("InventoryUI initialisé.")
    except Exception as e:
        st.error(f"Erreur: Init InventoryUI: {e}")
        st.session_state.inventory_ui = None

# NOUVEAU : Initialisation Base de Données Centralisée
if 'db_integration' not in st.session_state:
    try:
        st.session_state.db_integration = init_database_for_app()
        print("DatabaseManager centralisé initialisé.")
        
        # NOUVEAU: Créer les tables pour la base de connaissances
        if st.session_state.db_integration and st.session_state.db_integration.db:
            st.session_state.db_integration.db._create_knowledge_tables()
        
        # Mettre en cache les profils experts au démarrage
        if 'profile_manager' in st.session_state:
            st.session_state.db_integration.cache_expert_profiles(
                st.session_state.profile_manager
            )
        
    except Exception as e:
        st.error(f"Erreur init DatabaseManager: {e}")
        st.session_state.db_integration = None
        st.warning("Base de données centralisée désactivée.")

# NOUVEAU : Initialisation du module base de connaissances
if 'knowledge_base_ui' not in st.session_state and st.session_state.get('db_integration'):
    try:
        st.session_state.knowledge_base_ui = KnowledgeBaseUI(
            st.session_state.db_integration.db, 
            st.session_state.expert_advisor
        )
        print("KnowledgeBaseUI initialisé.")
    except Exception as e:
        st.error(f"Erreur: Init KnowledgeBaseUI: {e}")
        st.session_state.knowledge_base_ui = None

# Initialisation variables état session (après login check)
if "messages" not in st.session_state: st.session_state.messages = []
if "current_conversation_id" not in st.session_state: st.session_state.current_conversation_id = None
if "processed_messages" not in st.session_state: st.session_state.processed_messages = set()
if 'single_message_download' not in st.session_state: st.session_state.single_message_download = None
if 'show_copy_content' not in st.session_state: st.session_state.show_copy_content = None
if 'show_project_manager' not in st.session_state: st.session_state.show_project_manager = False
if 'show_knowledge_base' not in st.session_state: st.session_state.show_knowledge_base = False  # NOUVEAU
if 'show_inventory_manager' not in st.session_state: st.session_state.show_inventory_manager = False # NOUVEAU

# --- Sidebar UI (App Principale) ---
with st.sidebar:
    try:
        logo_path = os.path.join(os.path.dirname(__file__), "assets", "logo.png")
        if os.path.exists(logo_path):
            # Style professionnel sans fond coloré et logo plus grand
            st.markdown(
                f"""
                <div style="display: flex; justify-content: center; align-items: center; 
                            width: 100%; margin-bottom: 2rem; padding: 1rem 0;">
                    <div style="transition: all 0.3s ease-in-out; cursor: pointer;" 
                            onmouseover="this.style.transform='scale(1.05)'; this.style.filter='drop-shadow(0 8px 16px rgba(0, 0, 0, 0.1))';"
                            onmouseout="this.style.transform='scale(1)'; this.style.filter='drop-shadow(0 2px 4px rgba(0, 0, 0, 0.05))';">
                        <img src="data:image/png;base64,{get_image_base64(logo_path)}" 
                            style="width: 210px; height: auto; filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.05));">
                    </div>
                </div>
                """,
                unsafe_allow_html=True
            )
        else:
            st.warning("Logo 'assets/logo.png' non trouvé.")
    except Exception as e:
        st.error(f"Erreur logo: {e}")
        
    # Améliorez le bouton "Nouvelle Consultation"
    st.markdown("""
    <style>
    div.stButton > button:has(span:contains("Nouvelle Consultation")) {
        background: linear-gradient(90deg, #60A5FA 0%, #3B82F6 100%) !important;
        color: white !important;
        font-weight: 600 !important;
        padding: 10px 15px !important;
        position: relative !important;
    }
    div.stButton > button:has(span:contains("Nouvelle Consultation"))::before {
        content: "✨ " !important;
    }
    div.stButton > button:has(span:contains("Nouvelle Consultation")):hover {
        background: linear-gradient(90deg, #3B82F6 0%, #2563EB 100%) !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 6px 12px rgba(59, 130, 246, 0.2) !important;
    }
    </style>
    """, unsafe_allow_html=True)

    if st.button("Nouvelle Consultation", key="new_consult_button_top", use_container_width=True):
        save_current_conversation()
        start_new_consultation()
    st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)

    # --- Profil Expert ---
    st.markdown('<div class="sidebar-subheader">👤 PROFIL EXPERT</div>', unsafe_allow_html=True)
    if 'expert_advisor' in st.session_state and st.session_state.expert_advisor.profile_manager:
        profile_names = st.session_state.expert_advisor.profile_manager.get_profile_names()
        if profile_names:
            try:
                selected_profile_name_ref = st.session_state.get("selected_profile_name", profile_names[0])
                current_index = profile_names.index(selected_profile_name_ref) if selected_profile_name_ref in profile_names else 0
            except ValueError:
                current_index = 0
            selected_profile = st.selectbox("Profil:", profile_names, index=current_index, key="profile_select", label_visibility="collapsed")
            if selected_profile != st.session_state.get("selected_profile_name"):
                print(f"Changement profil: '{st.session_state.get('selected_profile_name')}' -> '{selected_profile}'")
                save_current_conversation()
                
                # NOUVEAU : Tracker l'utilisation du profil précédent
                if st.session_state.get("selected_profile_name") and 'db_integration' in st.session_state:
                    track_expert_usage(st.session_state.get("selected_profile_name"), success=True)
                
                with st.spinner(f"Changement vers {selected_profile}..."):
                    success = st.session_state.expert_advisor.set_current_profile_by_name(selected_profile)
                    if success:
                        st.session_state.selected_profile_name = selected_profile
                        
                        # NOUVEAU : Logger le changement de profil
                        if 'db_integration' in st.session_state:
                            track_user_action(
                                action_type="profile_changed",
                                description=f"Changement vers profil {selected_profile}",
                                old_profile=st.session_state.get("selected_profile_name"),
                                new_profile=selected_profile
                            )
                        
                        st.success(f"Profil changé. Nouvelle consultation.")
                        start_new_consultation() # Rerun inclus
                    else:
                        st.error(f"Impossible de charger profil '{selected_profile}'.")
        else:
            st.warning("Aucun profil expert trouvé.")
    else:
        st.error("Module Expert non initialisé.")

    # --- Analyse Fichiers ---
    st.markdown('<div class="sidebar-subheader">📄 ANALYSE FICHIERS</div>', unsafe_allow_html=True)
    uploaded_files_sidebar = [] # Initialisation par défaut
    if 'expert_advisor' in st.session_state:
        supported_types = st.session_state.expert_advisor.get_supported_filetypes_flat()
        uploaded_files_sidebar = st.file_uploader(
            "Téléverser fichiers:",
            type=supported_types if supported_types else None,
            accept_multiple_files=True,
            key="file_uploader_sidebar",
            label_visibility="collapsed"
        )

        # Déterminer si le bouton doit être désactivé
        is_disabled = not bool(uploaded_files_sidebar)

        # Style pour le bouton d'analyse
        st.markdown("""
        <style>
        div.stButton > button:has(span:contains("Analyser")) {
            background: linear-gradient(90deg, #c5e1a5 0%, #aed581 100%) !important;
            color: #33691e !important;
            border: none !important;
            animation: pulse 2s infinite;
        }
        div.stButton > button:has(span:contains("Analyser"))::before {
            content: "🔍 " !important;
        }
        div.stButton > button:has(span:contains("Analyser")):hover {
            background: linear-gradient(90deg, #aed581 0%, #9ccc65 100%) !important;
            transform: translateY(-2px) !important;
            box-shadow: 0 4px 8px rgba(51, 105, 30, 0.2) !important;
        }
        </style>
        """, unsafe_allow_html=True)

        # Afficher le bouton, en utilisant l'état désactivé
        if st.button("🔍 Analyser Fichiers", key="analyze_button", use_container_width=True, disabled=is_disabled):
            # Cette partie ne s'exécute que si le bouton est cliqué ET n'était PAS désactivé
            if not is_disabled:
                num_files = len(uploaded_files_sidebar)
                file_names_str = ', '.join([f.name for f in uploaded_files_sidebar])
                user_analysis_prompt = f"J'ai téléversé {num_files} fichier(s) ({file_names_str}) pour analyse. Peux-tu les examiner ?"
                action_id = f"analyze_{datetime.now().isoformat()}"
                # Stocker les fichiers à analyser DANS l'état de session pour les récupérer après le rerun
                st.session_state.files_to_analyze = uploaded_files_sidebar
                st.session_state.messages.append({"role": "user", "content": user_analysis_prompt, "id": action_id})
                save_current_conversation()
                st.rerun()

    # --- Gestionnaire de Projet ---
    if st.session_state.get('project_manager') and st.session_state.get('project_ui'):
        st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-subheader">🏗️ PROJETS</div>', unsafe_allow_html=True)
        
        # Statistiques rapides
        try:
            summary = st.session_state.project_manager.get_dashboard_summary()
            if summary and summary.get('projects', {}).get('total_projects', 0) > 0:
                total_projects = summary['projects']['total_projects']
                active_projects = summary['projects']['active_projects']
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Total", total_projects)
                with col2:
                    st.metric("Actifs", active_projects)
                
                # Bouton d'accès rapide au gestionnaire
                if st.button("📊 Ouvrir Gestionnaire", key="open_project_manager", use_container_width=True):
                    st.session_state.show_project_manager = True
                    st.rerun()
                
                # Projets récents (liste courte)
                recent_projects = summary.get('recent_projects', [])[:3]  # Limiter à 3
                if recent_projects:
                    st.caption("Projets récents:")
                    for project in recent_projects:
                        status_icon = {
                            'En cours': '🟢',
                            'Terminé': '✅', 
                            'En planification': '🟡'
                        }.get(project['status'], '⚫')
                        
                        if st.button(f"{status_icon} {project['name'][:20]}...", 
                                   key=f"sidebar_project_{project['id']}", 
                                   use_container_width=True,
                                   help=f"Statut: {project['status']}"):
                            st.session_state.current_project_id = project['id']
                            st.session_state.project_view_mode = 'project_detail'
                            st.session_state.show_project_manager = True
                            st.rerun()
            else:
                st.info("Aucun projet créé")
                if st.button("➕ Premier Projet", key="create_first_project", use_container_width=True):
                    st.session_state.project_view_mode = 'new_project'
                    st.session_state.show_project_manager = True
                    st.rerun()
                    
        except Exception as e:
            st.error(f"Erreur sidebar projets: {e}")
    else:
        # Si le gestionnaire de projet n'est pas disponible
        st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-subheader">🏗️ PROJETS</div>', unsafe_allow_html=True)
        st.warning("Module projet indisponible")
        
    # --- INVENTAIRE (NOUVELLE SECTION) ---
    if st.session_state.get('inventory_manager') and st.session_state.get('inventory_ui'):
        st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-subheader">📦 INVENTAIRE</div>', unsafe_allow_html=True)
        
        # Statistiques rapides
        try:
            summary = st.session_state.inventory_manager.get_dashboard_summary()
            if summary and summary.get('total_items', 0) > 0:
                total_items = summary['total_items']
                low_stock_items = summary['low_stock_items']
                total_value = summary['total_value']
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Articles", total_items)
                with col2:
                    st.metric("Stock Faible", low_stock_items, delta_color="inverse" if low_stock_items > 0 else "normal")
                
                # Valeur totale
                st.caption(f"💰 Valeur: {total_value:,.0f} $")
                
                # Bouton d'accès rapide au gestionnaire
                if st.button("📦 Ouvrir Inventaire", key="open_inventory_manager", use_container_width=True):
                    st.session_state.show_inventory_manager = True
                    st.rerun()
                
                # Alertes de stock faible
                if low_stock_items > 0:
                    st.warning(f"⚠️ {low_stock_items} article(s) en stock faible")
                    
                    # Articles en stock faible (limité à 3)
                    low_stock_details = summary.get('low_stock_details', [])[:3]
                    if low_stock_details:
                        st.caption("Articles critiques:")
                        for item in low_stock_details:
                            if st.button(f"{item['icon']} {item['name'][:15]}...", 
                                       key=f"sidebar_inventory_{item['name']}", 
                                       use_container_width=True,
                                       help=f"Stock: {item['current_stock']}/{item['minimum_stock']} {item['unit']}"):
                                st.session_state.inventory_view_mode = 'items'
                                st.session_state.show_inventory_manager = True
                                st.rerun()
            else:
                st.info("Inventaire vide")
                if st.button("➕ Premier Article", key="create_first_inventory_item", use_container_width=True):
                    st.session_state.inventory_view_mode = 'add_item'
                    st.session_state.show_inventory_manager = True
                    st.rerun()
                    
        except Exception as e:
            st.error(f"Erreur sidebar inventaire: {e}")
    else:
        # Si le gestionnaire d'inventaire n'est pas disponible
        st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-subheader">📦 INVENTAIRE</div>', unsafe_allow_html=True)
        st.warning("Module inventaire indisponible")


    # --- NOUVEAU: Base de Connaissances ---
    if st.session_state.get('knowledge_base_ui'):
        st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-subheader">🧠 BASE CONNAISSANCES</div>', unsafe_allow_html=True)
        
        # Statistiques rapides
        try:
            if 'db_integration' in st.session_state and st.session_state.db_integration:
                user_id = st.session_state.get('user_id', 1)
                custom_profiles = st.session_state.db_integration.db.get_user_custom_profiles(user_id)
                
                if custom_profiles:
                    total_custom = len([p for p in custom_profiles if not p.get('is_shared')])
                    shared_profiles = len([p for p in custom_profiles if p.get('is_shared')])
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Mes Profils", total_custom)
                    with col2:
                        st.metric("Partagés", shared_profiles)
                    
                    # Bouton d'accès rapide
                    if st.button("🧠 Ouvrir Base Connaissances", key="open_knowledge_base", use_container_width=True):
                        st.session_state.show_knowledge_base = True
                        st.rerun()
                    
                    # Profils récents (liste courte)
                    recent_profiles = sorted(custom_profiles, key=lambda x: x['updated_at'], reverse=True)[:3]
                    if recent_profiles:
                        st.caption("Profils récents:")
                        for profile in recent_profiles:
                            if st.button(f"👤 {profile['display_name'][:15]}...", 
                                       key=f"sidebar_profile_{profile['id']}", 
                                       use_container_width=True,
                                       help=f"Utiliser: {profile['display_name']}"):
                                # Charger ce profil directement
                                st.session_state.knowledge_base_ui.load_custom_profile_as_expert(profile)
                else:
                    st.info("Aucun profil personnalisé")
                    if st.button("➕ Premier Profil", key="create_first_kb_profile", use_container_width=True):
                        st.session_state.kb_view_mode = 'create_profile'
                        st.session_state.show_knowledge_base = True
                        st.rerun()
                        
        except Exception as e:
            st.error(f"Erreur sidebar base connaissances: {e}")
    else:
        # Si le module n'est pas disponible
        st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-subheader">🧠 BASE CONNAISSANCES</div>', unsafe_allow_html=True)
        st.warning("Module indisponible")

    # --- Aide Recherche Web (Nouvelle section) ---
    st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
    st.markdown('<div class="sidebar-subheader">🔎 RECHERCHE WEB</div>', unsafe_allow_html=True)
    with st.expander("Comment utiliser la recherche web"):
        st.markdown("""
        Pour effectuer une recherche web via Claude:

        1. Tapez `/search` suivi de votre question ou requête
        2. Exemple: `/search normes électriques Québec`
        3. Pour rechercher des informations sur un site spécifique:
            `/search règlement construction site:rbq.gouv.qc.ca`
        4. Attendez quelques secondes pour les résultats

        **Remarque:** Pour obtenir les meilleurs résultats, formulez des questions précises et utilisez des mots-clés pertinents.
        """)
                              
    # --- Manuel d'Utilisation (Nouvelle section) ---
    st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
    st.markdown('<div class="sidebar-subheader">📖 MANUEL & AIDE</div>', unsafe_allow_html=True)
    
    # Style pour le bouton du manuel
    st.markdown("""
    <style>
    .manual-button {
        background: linear-gradient(145deg, rgba(255, 255, 255, 0.4) 0%, #3B82F6 20%, #2563EB 80%, rgba(0, 0, 0, 0.2) 100%);
        color: white !important;
        border: none;
        border-radius: 8px;
        padding: 12px 16px;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 4px 8px rgba(59, 130, 246, 0.25), inset 0 1px 0 rgba(255, 255, 255, 0.3), inset 0 -1px 0 rgba(0, 0, 0, 0.1);
        width: 100%;
        text-align: center;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        position: relative;
        overflow: hidden;
        text-decoration: none !important;
        font-size: 14px;
        cursor: pointer;
    }
    
    .manual-button::before {
        content: "";
        position: absolute;
        top: 0; left: -100%;
        width: 100%; height: 100%;
        background: linear-gradient(90deg, transparent 0%, rgba(255, 255, 255, 0.4) 50%, transparent 100%);
        transition: left 0.6s ease;
        z-index: 1;
    }
    
    .manual-button:hover::before {
        left: 100%;
    }
    
    .manual-button:hover {
        background: linear-gradient(145deg, rgba(255, 255, 255, 0.5) 0%, #60A5FA 20%, #2563EB 80%, rgba(0, 0, 0, 0.3) 100%);
        transform: translateY(-3px);
        box-shadow: 0 8px 16px rgba(59, 130, 246, 0.35), inset 0 2px 0 rgba(255, 255, 255, 0.4), inset 0 -2px 0 rgba(0, 0, 0, 0.15), 0 0 20px rgba(59, 130, 246, 0.2);
        text-decoration: none !important;
        color: white !important;
    }
    
    .manual-button:visited {
        color: white !important;
        text-decoration: none !important;
    }
    
    .manual-button:link {
        color: white !important;
        text-decoration: none !important;
    }
    
    .manual-button-content {
        position: relative;
        z-index: 2;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        color: white !important;
    }
    </style>
    """, unsafe_allow_html=True)
    
    # Lien direct vers le manuel
    manual_url = "https://constructoai.github.io/Manuel_Constructo_AI_3.0/"
    
    st.markdown(f"""
    <div style="
        background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        border-radius: 8px;
        padding: 12px;
        border-left: 3px solid #0891b2;
        font-size: 0.9rem;
        color: #164e63;
        text-align: center;
    ">
        📖 <strong>Manuel d'Utilisation :</strong><br>
        <a href="{manual_url}" target="_blank" style="color: #0891b2; font-weight: bold; text-decoration: none;">
        Lien
        </a>
    </div>
    """, unsafe_allow_html=True)
    
    # Informations complémentaires
    with st.expander("💡 Aide Rapide"):
        st.markdown("""
        **🚀 Pour commencer :**
        1. Sélectionnez un expert dans la liste
        2. Posez votre question de construction
        3. Utilisez `/search` pour rechercher sur le web
        4. Explorez les modules Projet et Base de Connaissances
        
        **📞 Support :**
        - Email : support@constructoai.ca
        - Manuel complet : Cliquez le bouton ci-dessus
        """)
    
    st.markdown(f"""
    <div style="
        background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
        border-radius: 8px;
        padding: 12px;
        margin-top: 8px;
        border-left: 3px solid #0891b2;
        font-size: 0.85rem;
        color: #164e63;
    ">
        <strong>💡 Astuce :</strong> Le manuel s'ouvre dans un nouvel onglet et contient des guides détaillés avec captures d'écran.
    </div>
    """, unsafe_allow_html=True)

    # --- Historique ---
    if st.session_state.get('conversation_manager'):
        st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
        st.markdown('<div class="sidebar-subheader">🕒 HISTORIQUE</div>', unsafe_allow_html=True)
        try:
            conversations = st.session_state.conversation_manager.list_conversations(limit=100)
            if not conversations: st.caption("Aucune consultation sauvegardée.")
            else:
                # Style pour les boutons d'historique
                st.markdown("""
                <style>
                div[data-testid="stHorizontalBlock"] > div:nth-child(1) button[kind="secondary"] {
                    text-align: left;
                    justify-content: flex-start !important;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    font-size: 0.9rem;
                    padding: 0.4rem 0.6rem;
                    border: 1px solid transparent;
                    background-color: transparent;
                    color: var(--text-color);
                    transition: all 0.3s;
                    border-radius: 6px;
                }
                div[data-testid="stHorizontalBlock"] > div:nth-child(1) button[kind="secondary"]:hover {
                    background-color: #f0f7ff;
                    border-color: #dbeafe;
                    transform: translateX(3px);
                }
                div[data-testid="stHorizontalBlock"] > div:nth-child(2) button[kind="secondary"] {
                    background: none;
                    border: none;
                    color: var(--text-color-light);
                    cursor: pointer;
                    padding: 0.4rem 0.3rem;
                    font-size: 0.9rem;
                    line-height: 1;
                    transition: all 0.2s;
                    border-radius: 6px;
                }
                div[data-testid="stHorizontalBlock"] > div:nth-child(2) button[kind="secondary"]:hover {
                    color: #EF4444;
                    background-color: rgba(239, 68, 68, 0.1);
                    transform: scale(1.1);
                }
                </style>
                """, unsafe_allow_html=True)
                
                with st.container(height=300):
                    for conv in conversations:
                        col1, col2 = st.columns([0.85, 0.15])
                        with col1:
                            if st.button(conv['name'], key=f"load_conv_{conv['id']}", use_container_width=True, type="secondary", help=f"Charger '{conv['name']}' (màj: {conv['last_updated_at']})"):
                                save_current_conversation(); load_selected_conversation(conv['id'])
                        with col2:
                            if st.button("🗑️", key=f"delete_conv_{conv['id']}", help=f"Supprimer '{conv['name']}'", use_container_width=True, type="secondary"):
                                delete_selected_conversation(conv['id'])
        except Exception as e: st.error(f"Erreur historique: {e}"); st.exception(e)
    else: st.caption("Module historique inactif.")

    # --- Export ---
    st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
    create_export_sidebar_section()

    # NOUVEAU : Analytics et Statistiques
    st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
    st.markdown('<div class="sidebar-subheader">📊 ANALYTICS</div>', unsafe_allow_html=True)

    if 'db_integration' in st.session_state and st.session_state.db_integration:
        
        # Bouton pour afficher les statistiques
        if st.button("📈 Voir Statistiques", use_container_width=True):
            analytics = get_performance_metrics()
            
            if analytics:
                with st.expander("📊 Statistiques d'Utilisation", expanded=True):
                    db_stats = analytics.get("database_stats", {})
                    
                    # Métriques principales
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Conversations", db_stats.get("conversations_count", 0))
                        st.metric("Projets", db_stats.get("projects_count", 0))
                    with col2:
                        st.metric("Messages", db_stats.get("messages_count", 0))
                        st.metric("Documents", db_stats.get("documents_count", 0))
                    
                    # Taille de la base de données
                    db_size = db_stats.get("database_size_mb", 0)
                    st.caption(f"💾 Taille DB: {db_size:.1f} MB")
                    
                    # Experts les plus utilisés
                    st.markdown("#### 🏆 Experts Populaires")
                    top_experts = analytics.get("top_experts", [])
                    for i, expert in enumerate(top_experts[:5], 1):
                        usage = expert.get('usage_count', 0)
                        success_rate = expert.get('success_rate', 0) * 100
                        st.caption(f"{i}. **{expert['name']}** - {usage} utilisations ({success_rate:.0f}% succès)")
        
        # Maintenance de la base de données
        if st.button("🔧 Optimiser Base de Données", use_container_width=True):
            with st.spinner("Optimisation en cours..."):
                try:
                    st.session_state.db_integration.cleanup_and_optimize()
                    st.success("✅ Base de données optimisée!")
                    
                    # Logger l'optimisation
                    track_user_action(
                        action_type="database_optimized",
                        description="Optimisation manuelle de la base de données"
                    )
                except Exception as e:
                    st.error(f"Erreur lors de l'optimisation: {e}")
        
        # Affichage de l'activité récente (optionnel)
        with st.expander("🕒 Activité Récente"):
            analytics = get_performance_metrics()
            recent_activity = analytics.get("recent_activity", [])
            
            if recent_activity:
                for activity in recent_activity[:5]:
                    action_time = activity['created_at'][:16].replace('T', ' ')
                    st.caption(f"⏰ {action_time} - {activity['description']}")
            else:
                st.caption("Aucune activité récente")

    else:
        st.caption("Analytics non disponibles")

    # --- Bouton Déconnexion ---
    st.markdown('<hr style="margin: 1rem 0; border-top: 1px solid var(--border-color);">', unsafe_allow_html=True)
    
    # Style pour le bouton de déconnexion
    st.markdown("""
    <style>
    div.stButton > button:has(span:contains("Déconnexion")) {
        background: linear-gradient(90deg, #fee2e2 0%, #fecaca 100%) !important;
        color: #b91c1c !important;
        border: none !important;
        font-weight: 500 !important;
        transition: all 0.3s !important;
    }
    div.stButton > button:has(span:contains("Déconnexion"))::before {
        content: "🚪 " !important;
    }
    div.stButton > button:has(span:contains("Déconnexion")):hover {
        background: linear-gradient(90deg, #fecaca 0%, #fca5a5 100%) !important;
        transform: translateY(-2px) !important;
        box-shadow: 0 4px 8px rgba(220, 38, 38, 0.15) !important;
    }
    </style>
    """, unsafe_allow_html=True)
    
    if st.button("Déconnexion", key="logout_button", use_container_width=True):
        st.session_state.logged_in = False
        keys_to_clear = [
            "messages", "current_conversation_id", "processed_messages", 
            "html_download_data", "single_message_download", "show_copy_content", 
            "selected_profile_name", "files_to_analyze", "show_project_manager", 
            "show_knowledge_base", "show_inventory_manager"
        ]
        for key in keys_to_clear:
            if key in st.session_state: del st.session_state[key]
        # Aussi nettoyer les objets potentiellement lourds ou liés aux clés API
        if 'expert_advisor' in st.session_state: del st.session_state['expert_advisor']
        if 'profile_manager' in st.session_state: del st.session_state['profile_manager']
        if 'conversation_manager' in st.session_state: del st.session_state['conversation_manager']
        if 'project_manager' in st.session_state: del st.session_state['project_manager']
        if 'project_ui' in st.session_state: del st.session_state['project_ui']
        if 'inventory_manager' in st.session_state: del st.session_state['inventory_manager']
        if 'inventory_ui' in st.session_state: del st.session_state['inventory_ui']
        if 'db_integration' in st.session_state: del st.session_state['db_integration']
        if 'knowledge_base_ui' in st.session_state: del st.session_state['knowledge_base_ui']
        st.rerun()

# --- Main Chat Area (App Principale) ---

# Inventaire (Mode plein écran)
if st.session_state.get('show_inventory_manager', False):
    if st.session_state.get('inventory_ui'):
        # Bouton de retour au chat
        col1, col2 = st.columns([6, 2])
        with col2:
            if st.button("💬 Retour au Chat", use_container_width=True):
                st.session_state.show_inventory_manager = False
                st.rerun()
        
        with col1:
            st.markdown("---")
        
        # Afficher l'interface de gestion d'inventaire
        try:
            st.session_state.inventory_ui.render_inventory_section()
        except Exception as e:
            st.error(f"Erreur lors de l'affichage du gestionnaire d'inventaire: {e}")
            st.exception(e)
            if st.button("🔄 Réinitialiser le Gestionnaire d'Inventaire"):
                if 'inventory_manager' in st.session_state:
                    del st.session_state.inventory_manager
                if 'inventory_ui' in st.session_state:
                    del st.session_state.inventory_ui
                st.session_state.show_inventory_manager = False
                st.rerun()
        
        # Arrêter l'exécution pour ne pas afficher le chat
        st.stop()

# Base de Connaissances (Mode plein écran) - NOUVEAU
if st.session_state.get('show_knowledge_base', False):
    if st.session_state.get('knowledge_base_ui'):
        # Bouton de retour au chat
        col1, col2 = st.columns([6, 2])
        with col2:
            if st.button("💬 Retour au Chat", use_container_width=True):
                st.session_state.show_knowledge_base = False
                st.rerun()
        
        with col1:
            st.markdown("---")
        
        # Afficher l'interface de base de connaissances
        try:
            st.session_state.knowledge_base_ui.render_knowledge_base_section()
        except Exception as e:
            st.error(f"Erreur lors de l'affichage de la base de connaissances: {e}")
            st.exception(e)
            if st.button("🔄 Réinitialiser la Base de Connaissances"):
                if 'knowledge_base_ui' in st.session_state:
                    del st.session_state.knowledge_base_ui
                st.session_state.show_knowledge_base = False
                st.rerun()
        
        # Arrêter l'exécution pour ne pas afficher le chat
        st.stop()

# Gestionnaire de Projet (Mode plein écran)
if st.session_state.get('show_project_manager', False):
    if st.session_state.get('project_ui'):
        # Bouton de retour au chat
        col1, col2 = st.columns([6, 2])
        with col2:
            if st.button("💬 Retour au Chat", use_container_width=True):
                st.session_state.show_project_manager = False
                st.rerun()
        
        with col1:
            st.markdown("---")
        
        # Afficher l'interface de gestion de projet
        try:
            st.session_state.project_ui.render_project_section()
        except Exception as e:
            st.error(f"Erreur lors de l'affichage du gestionnaire de projet: {e}")
            st.exception(e)
            if st.button("🔄 Réinitialiser le Gestionnaire de Projet"):
                if 'project_manager' in st.session_state:
                    del st.session_state.project_manager
                if 'project_ui' in st.session_state:
                    del st.session_state.project_ui
                st.session_state.show_project_manager = False
                st.rerun()
        
        # Arrêter l'exécution pour ne pas afficher le chat
        st.stop()

main_container = st.container()
with main_container:
    # Titre dynamique avec style amélioré et navigation
    if 'expert_advisor' in st.session_state:
        current_profile = st.session_state.expert_advisor.get_current_profile()
        profile_name = "Assistant Constructo AI"
        profile_name = current_profile.get('name', profile_name) if current_profile else profile_name
        
        # Détecter si c'est un profil personnalisé
        is_custom_profile = current_profile and current_profile.get('id', '').startswith('custom_')
        profile_indicator = "🧠 Profil Personnalisé" if is_custom_profile else "👤 Profil Expert"
        
        st.markdown(f"""
        <div class="main-header">
            <h1>🏗️ Assistant: {profile_name}</h1>
            <p>{profile_indicator} • Votre expert en construction au Québec</p>
        </div>
        """, unsafe_allow_html=True)
        
        if current_profile and current_profile.get('id') == 'default_expert': 
            st.info("*Profil expert par défaut actif. Créez vos propres profils IA personnalisés dans la Base de Connaissances !*")
    else: 
        st.markdown("""
        <div class="main-header">
            <h1>🏗️ Assistant Constructo AI</h1>
            <p>Erreur: Module expert non initialisé</p>
        </div>
        """, unsafe_allow_html=True)
        st.error("Erreur: Module expert non initialisé.")

    # Affichage du chat
    if not st.session_state.messages and 'expert_advisor' in st.session_state:
        profile = st.session_state.expert_advisor.get_current_profile()
        prof_name = profile.get('name', 'par défaut') if profile else "par défaut"
        st.session_state.messages.append({
            "role": "assistant",
            "content": f"Bonjour! Je suis votre expert {prof_name}. Comment puis-je vous aider aujourd'hui?\n\n"
                       f"💡 **Modules disponibles**:\n"
                       f"• **Gestionnaire de Projet** : Gérez vos projets de construction\n"
                       f"• **Base de Connaissances** : Créez vos propres experts IA personnalisés\n"
                       f"• **Inventaire IA** : Gestion intelligente de vos stocks de matériaux\n\n"
                       f"**Commandes rapides :**\n"
                       f"• `/search` + question → Recherche web\n"
                       f"• `/projet dashboard` → Gestion de projets\n"
                       f"• `/kb dashboard` → Base de connaissances\n"
                       f"• `/inventaire dashboard` → Inventaire IA"
        })

    # Style amélioré pour les bulles de chat
    st.markdown("""
    <style>
    /* Style amélioré pour les bulles de chat */
    div[data-testid="stChatMessage"]:has(div[data-testid^="chatAvatarIcon-user"]) {
        background: linear-gradient(to right, #f0f7ff, #e6f3ff);
        border-left: 4px solid #60A5FA;
        margin-left: auto;
        margin-right: 0;
        width: 85%;
        position: relative;
        animation: fadeIn 0.5s ease-out;
    }

    div[data-testid="stChatMessage"]:has(div[data-testid^="chatAvatarIcon-user"])::after {
        content: "";
        position: absolute;
        top: 20px;
        right: -10px;
        border-width: 10px 0 10px 10px;
        border-style: solid;
        border-color: transparent transparent transparent #e6f3ff;
    }

    div[data-testid="stChatMessage"]:has(div[data-testid^="chatAvatarIcon-assistant"]) {
        background: linear-gradient(to right, #f7f9fc, #ffffff);
        border-left: 4px solid #3B82F6;
        margin-left: 0;
        margin-right: auto;
        width: 85%;
        position: relative;
        animation: fadeIn 0.5s ease-out;
    }

    div[data-testid="stChatMessage"]:has(div[data-testid^="chatAvatarIcon-assistant"])::after {
        content: "";
        position: absolute;
        top: 20px;
        left: -10px;
        border-width: 10px 10px 10px 0;
        border-style: solid;
        border-color: transparent #f7f9fc transparent transparent;
    }

    div[data-testid="stChatMessage"]:has(div[data-testid^="chatAvatarIcon-search_result"]) {
        background: linear-gradient(to right, #f0fdf4, #e6f7ec);
        border-left: 4px solid #22c55e;
        animation: fadeIn 0.5s ease-out;
    }

    .chat-avatar {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 36px;
        height: 36px;
        border-radius: 50%;
        font-size: 18px;
        margin-right: 10px;
    }

    .avatar-user {
        background-color: #dbeafe;
        color: #2563eb;
    }

    .avatar-assistant {
        background-color: #3B82F6;
        color: white;
    }

    .avatar-search {
        background-color: #dcfce7;
        color: #16a34a;
    }
    </style>
    """, unsafe_allow_html=True)

    # Boucle d'affichage des messages
    for message in st.session_state.messages:
        role = message.get("role", "unknown")
        content = message.get("content", "*Message vide*")
        if role == "system": continue
        
        # Configuration des avatars améliorés
        if role == "user":
            avatar = "👤"
            avatar_class = "avatar-user"
        elif role == "assistant":
            avatar = "🏗️"
            avatar_class = "avatar-assistant"
        elif role == "search_result":
            avatar = "🔎"
            avatar_class = "avatar-search"
        else:
            avatar = "🤖"
            avatar_class = ""
        
        with st.chat_message(role, avatar=avatar):
            display_content = str(content) if not isinstance(content, str) else content
            st.markdown(display_content, unsafe_allow_html=False)

# --- Chat Input ---
# Style pour le chat input
st.markdown("""
<style>
div[data-testid="stChatInput"] {
    background-color: var(--secondary-background-color);
    border-top: 1px solid var(--border-color);
    padding: 0.5rem 1rem;
    box-shadow: 0 -2px 5px rgba(0,0,0,0.03);
    border-radius: 12px 12px 0 0;
    margin-top: 20px;
}

div[data-testid="stChatInput"] textarea {
    border-radius: 12px;
    border: 1px solid var(--border-color);
    background-color: var(--background-color);
    padding: 0.8rem 1rem;
    font-family: var(--font-family) !important;
    transition: all 0.3s;
    resize: none;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

div[data-testid="stChatInput"] textarea:focus {
    border-color: var(--primary-color);
    box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.3);
    transform: translateY(-1px);
}

div[data-testid="stChatInput"] button {
    background-color: var(--primary-color) !important;
    border-radius: 12px !important;
    fill: white !important;
    padding: 0.7rem !important;
    box-shadow: var(--box-shadow-sm);
    transition: all 0.3s;
    border: none !important;
}

div[data-testid="stChatInput"] button:hover {
    background-color: var(--primary-color-darker) !important;
    transform: translateY(-2px);
    box-shadow: 0 3px 6px rgba(59, 130, 246, 0.2);
}

div[data-testid="stChatInput"] button:disabled {
    background-color: #9CA3AF !important;
    transform: none;
    box-shadow: none;
}
</style>
""", unsafe_allow_html=True)

prompt = st.chat_input("Posez votre question ou tapez /search [recherche web], /projet [gestion], /kb [base connaissances]...")

# --- Traitement du nouveau prompt ---
if prompt:
    user_msg = {"role": "user", "content": prompt, "id": datetime.now().isoformat()}
    st.session_state.messages.append(user_msg)
    save_current_conversation()
    if 'html_download_data' in st.session_state: del st.session_state.html_download_data
    if 'single_message_download' in st.session_state: del st.session_state.single_message_download
    if 'show_copy_content' in st.session_state: del st.session_state.show_copy_content
    st.rerun()

# --- LOGIQUE DE RÉPONSE / RECHERCHE / ANALYSE ---
action_to_process = None
if st.session_state.messages and 'expert_advisor' in st.session_state:
    last_message = st.session_state.messages[-1]
    msg_id = last_message.get("id", last_message.get("content")) # Use ID if available, else content hash (less reliable)
    if msg_id not in st.session_state.processed_messages: action_to_process = last_message

if action_to_process and action_to_process.get("role") == "user":
    msg_id = action_to_process.get("id", action_to_process.get("content"))
    st.session_state.processed_messages.add(msg_id)
    user_content = action_to_process.get("content", "")

    # Amélioration de la détection de commande search
    is_search_command = False
    search_query = ""

    if user_content.strip().lower().startswith("/search "):
        is_search_command = True
        search_query = user_content[len("/search "):].strip()
    elif user_content.strip().lower() == "/search":
        is_search_command = True
        search_query = ""  # Requête vide, à gérer

    # Vérifier les commandes de projet
    is_project_command = False
    if user_content.strip().lower().startswith("/projet"):
        is_project_command = True
        command_parts = user_content.strip().split(" ", 1)
        if len(command_parts) > 1:
            subcommand = command_parts[1].lower()
            
            if subcommand == "dashboard" or subcommand == "tableau":
                st.session_state.project_view_mode = 'dashboard'
                st.session_state.show_project_manager = True
                st.rerun()
            elif subcommand == "nouveau" or subcommand == "créer":
                st.session_state.project_view_mode = 'new_project'
                st.session_state.show_project_manager = True
                st.rerun()
            elif subcommand == "liste":
                st.session_state.project_view_mode = 'projects'
                st.session_state.show_project_manager = True
                st.rerun()
            else:
                response_msg = """
                🏗️ **Commandes Gestionnaire de Projet disponibles:**
                
                - `/projet dashboard` - Ouvrir le tableau de bord
                - `/projet nouveau` - Créer un nouveau projet  
                - `/projet liste` - Voir tous les projets
                
                Vous pouvez aussi accéder au gestionnaire complet via la barre latérale !
                """
                
                with st.chat_message("assistant", avatar="🏗️"):
                    st.markdown(response_msg)
                
                st.session_state.messages.append({"role": "assistant", "content": response_msg})
                save_current_conversation()
                st.rerun()
        else:
            # Commande /projet seule - afficher l'aide
            help_msg = """
            🏗️ **Gestionnaire de Projet Constructo AI**
            
            Utilisez ces commandes pour accéder rapidement au gestionnaire de projet:
            
            - `/projet dashboard` - Tableau de bord des projets
            - `/projet nouveau` - Créer un nouveau projet
            - `/projet liste` - Liste de tous les projets
            
            **Ou cliquez sur "📊 Ouvrir Gestionnaire" dans la barre latérale !**
            """
            
            with st.chat_message("assistant", avatar="🏗️"):
                st.markdown(help_msg)
            
            st.session_state.messages.append({"role": "assistant", "content": help_msg})
            save_current_conversation()
            st.rerun()

    # NOUVEAU: Vérifier les commandes de base de connaissances
    is_kb_command = False
    if user_content.strip().lower().startswith("/kb") or user_content.strip().lower().startswith("/profil"):
        is_kb_command = True
        command_parts = user_content.strip().split(" ", 1)
        
        if len(command_parts) > 1:
            subcommand = command_parts[1].lower()
            
            if subcommand == "dashboard" or subcommand == "tableau":
                st.session_state.kb_view_mode = 'dashboard'
                st.session_state.show_knowledge_base = True
                st.rerun()
            elif subcommand == "nouveau" or subcommand == "créer":
                st.session_state.kb_view_mode = 'create_profile'
                st.session_state.show_knowledge_base = True
                st.rerun()
            elif subcommand == "mes" or subcommand == "liste":
                st.session_state.kb_view_mode = 'profiles'
                st.session_state.show_knowledge_base = True
                st.rerun()
            else:
                response_msg = """
                🧠 **Commandes Base de Connaissances disponibles:**
                
                - `/kb dashboard` - Ouvrir le tableau de bord
                - `/kb nouveau` - Créer un nouveau profil expert
                - `/kb mes` - Voir mes profils personnalisés
                
                Vous pouvez aussi accéder à la base de connaissances via la barre latérale !
                """
                
                with st.chat_message("assistant", avatar="🧠"):
                    st.markdown(response_msg)
                
                st.session_state.messages.append({"role": "assistant", "content": response_msg})
                save_current_conversation()
                st.rerun()
        else:
            # Commande /kb seule - afficher l'aide
            help_msg = """
            🧠 **Base de Connaissances Personnalisée**
            
            Créez vos propres experts IA avec vos documents et expertise !
            
            - `/kb dashboard` - Tableau de bord de vos profils
            - `/kb nouveau` - Créer un nouveau profil expert
            - `/kb mes` - Liste de vos profils personnalisés
            
            **Ou cliquez sur "🧠 Ouvrir Base Connaissances" dans la barre latérale !**
            """
            
            with st.chat_message("assistant", avatar="🧠"):
                st.markdown(help_msg)
            
            st.session_state.messages.append({"role": "assistant", "content": help_msg})
            save_current_conversation()
            st.rerun()

    # NOUVEAU: Vérifier les commandes d'inventaire
    is_inventory_command = False
    if user_content.strip().lower().startswith("/inventaire") or user_content.strip().lower().startswith("/stock"):
        is_inventory_command = True
        command_parts = user_content.strip().split(" ", 1)
        
        if len(command_parts) > 1:
            subcommand = command_parts[1].lower()
            
            if subcommand == "dashboard" or subcommand == "tableau":
                st.session_state.inventory_view_mode = 'dashboard'
                st.session_state.show_inventory_manager = True
                st.rerun()
            elif subcommand == "articles" or subcommand == "liste":
                st.session_state.inventory_view_mode = 'items'
                st.session_state.show_inventory_manager = True
                st.rerun()
            elif subcommand == "nouveau" or subcommand == "ajouter":
                st.session_state.inventory_view_mode = 'add_item'
                st.session_state.show_inventory_manager = True
                st.rerun()
            elif subcommand == "mouvements" or subcommand == "historique":
                st.session_state.inventory_view_mode = 'stock_movements'
                st.session_state.show_inventory_manager = True
                st.rerun()
            elif subcommand == "fournisseurs":
                st.session_state.inventory_view_mode = 'suppliers'
                st.session_state.show_inventory_manager = True
                st.rerun()
            elif subcommand == "predictions" or subcommand == "ia":
                st.session_state.inventory_view_mode = 'ai_predictions'
                st.session_state.show_inventory_manager = True
                st.rerun()
            elif subcommand == "suggestions" or subcommand == "recommandations":
                st.session_state.inventory_view_mode = 'reorder_suggestions'
                st.session_state.show_inventory_manager = True
                st.rerun()
            else:
                response_msg = """
                📦 **Commandes Gestionnaire d'Inventaire disponibles:**
                
                - `/inventaire dashboard` - Ouvrir le tableau de bord
                - `/inventaire articles` - Voir tous les articles
                - `/inventaire nouveau` - Ajouter un nouvel article
                - `/inventaire mouvements` - Voir l'historique des mouvements
                - `/inventaire fournisseurs` - Gérer les fournisseurs
                - `/inventaire predictions` - Prédictions IA de consommation
                - `/inventaire suggestions` - Suggestions de réapprovisionnement IA
                
                Vous pouvez aussi accéder au gestionnaire complet via la barre latérale !
                """
                
                with st.chat_message("assistant", avatar="📦"):
                    st.markdown(response_msg)
                
                st.session_state.messages.append({"role": "assistant", "content": response_msg})
                save_current_conversation()
                st.rerun()
        else:
            # Commande /inventaire seule - afficher l'aide
            help_msg = """
            📦 **Gestionnaire d'Inventaire IA - Constructo AI**
            
            Gérez vos stocks de matériaux de construction avec intelligence artificielle !
            
            **Commandes disponibles :**
            - `/inventaire dashboard` - Tableau de bord des stocks
            - `/inventaire articles` - Liste de tous les articles
            - `/inventaire nouveau` - Ajouter un nouvel article
            - `/inventaire mouvements` - Historique des mouvements de stock
            - `/inventaire fournisseurs` - Gestion des fournisseurs
            - `/inventaire predictions` - Prédictions IA de consommation
            - `/inventaire suggestions` - Recommandations IA de réapprovisionnement
            
            **Ou cliquez sur "📦 Ouvrir Inventaire" dans la barre latérale !**
            
            **Fonctionnalités IA :**
            🤖 Prédictions de consommation basées sur l'historique
            💡 Suggestions intelligentes de réapprovisionnement
            🚨 Alertes automatiques de stock faible
            📊 Analyses de tendances et optimisation des coûts
            """
            
            with st.chat_message("assistant", avatar="📦"):
                st.markdown(help_msg)
            
            st.session_state.messages.append({"role": "assistant", "content": help_msg})
            save_current_conversation()
            st.rerun()

    # Récupérer les fichiers potentiellement à analyser DEPUIS l'état de session
    # 'files_to_analyze' est défini LORSQUE le bouton 'Analyser Fichiers' est cliqué
    files_for_analysis = st.session_state.get("files_to_analyze", [])
    # Vérifier si l'ID du message correspond à une action d'analyse ET s'il y a des fichiers stockés
    is_analysis_request = action_to_process.get("id", "").startswith("analyze_") and files_for_analysis

    if is_analysis_request:
        # --- Logique Analyse Fichiers ---
        with st.chat_message("assistant", avatar="🏗️"):
            with st.spinner("Analyse des documents..."):
                try:
                    # NOUVEAU : Sauvegarder les métadonnées des documents
                    document_ids = []
                    if 'db_integration' in st.session_state and st.session_state.db_integration:
                        for uploaded_file in files_for_analysis:
                            try:
                                doc_id = st.session_state.db_integration.save_document_upload(
                                    filename=uploaded_file.name,
                                    file_content=uploaded_file.getvalue(),
                                    conversation_id=st.session_state.get('current_conversation_id')
                                )
                                if doc_id:
                                    document_ids.append((uploaded_file.name, doc_id))
                            except Exception as e:
                                print(f"Erreur sauvegarde document {uploaded_file.name}: {e}")

                    # Utiliser les fichiers stockés dans st.session_state.files_to_analyze
                    history_context = [m for m in st.session_state.messages[:-1] if m.get("role") != "system"]

                    # Appel à la fonction d'analyse
                    analysis_response, analysis_details = st.session_state.expert_advisor.analyze_documents(files_for_analysis, history_context)

                    # NOUVEAU : Sauvegarder les résultats d'analyse
                    if 'db_integration' in st.session_state and document_ids:
                        for filename, doc_id in document_ids:
                            try:
                                st.session_state.db_integration.update_document_analysis_result(
                                    doc_id=doc_id,
                                    analysis_summary=analysis_response[:1000]  # Limite pour la DB
                                )
                            except Exception as e:
                                print(f"Erreur sauvegarde analyse {filename}: {e}")

                    # Logger l'analyse
                    if 'db_integration' in st.session_state:
                        track_user_action(
                            action_type="documents_analyzed",
                            description=f"Analyse de {len(files_for_analysis)} document(s)",
                            document_count=len(files_for_analysis),
                            analysis_length=len(analysis_response)
                        )

                    # Utiliser la nouvelle fonction d'affichage d'analyse
                    display_analysis_result(analysis_response, analysis_details)
                    
                    st.session_state.messages.append({"role": "assistant", "content": analysis_response})
                    st.success("Analyse terminée.")

                    # Nettoyer l'état après traitement pour éviter une nouvelle analyse au prochain rerun
                    if "files_to_analyze" in st.session_state:
                        del st.session_state.files_to_analyze

                except Exception as e:
                    error_msg = f"Erreur durant l'analyse des fichiers: {e}"
                    st.error(error_msg)
                    st.exception(e)
                    st.session_state.messages.append({"role": "assistant", "content": f"Désolé, une erreur s'est produite lors de l'analyse: {type(e).__name__}"})
                    # Nettoyer l'état même en cas d'erreur
                    if "files_to_analyze" in st.session_state:
                        del st.session_state.files_to_analyze

        save_current_conversation()
        st.rerun() # Rerun après l'analyse (succès ou échec)

    elif is_search_command:
        # --- Logique Recherche Web avec Cache ---
        query = search_query.strip()
        if not query:
            error_msg = "Commande `/search` vide. Veuillez fournir un terme de recherche."
            with st.chat_message("assistant", avatar="⚠️"):
                st.warning(error_msg)
            st.session_state.messages.append({"role": "assistant", "content": error_msg})
            save_current_conversation()
            st.rerun()
        else:
            # Ajouter un message d'attente
            with st.chat_message("assistant", avatar="🔎"):
                with st.spinner(f"Recherche web pour: '{query}'"):
                    try:
                        # NOUVEAU : Vérifier le cache d'abord
                        cached_result = None
                        if 'db_integration' in st.session_state and st.session_state.db_integration:
                            cached_result = st.session_state.db_integration.get_cached_search(query)

                        if cached_result:
                            # Utiliser le résultat en cache
                            st.info("✅ Résultat récupéré du cache (plus rapide)")
                            search_result = cached_result
                            
                            # Logger l'utilisation du cache
                            if 'db_integration' in st.session_state:
                                track_user_action(
                                    action_type="search_cache_hit",
                                    description=f"Cache utilisé pour: {query[:50]}...",
                                    query=query
                                )
                        else:
                            # Nouvelle recherche
                            search_result = st.session_state.expert_advisor.perform_web_search(query)
                            
                            # Mettre en cache le résultat
                            if 'db_integration' in st.session_state and st.session_state.db_integration:
                                current_profile = st.session_state.expert_advisor.get_current_profile()
                                profile_name = current_profile.get('name', '') if current_profile else ''
                                
                                st.session_state.db_integration.cache_search_result(
                                    query=query,
                                    results=search_result,
                                    expert_profile=profile_name
                                )
                            
                            # Logger la nouvelle recherche
                            if 'db_integration' in st.session_state:
                                track_user_action(
                                    action_type="web_search_performed",
                                    description=f"Recherche web: {query[:50]}...",
                                    query=query,
                                    result_length=len(search_result)
                                )
                        
                        # Style amélioré pour les résultats de recherche
                        st.markdown("""
                        <div class="search-result-container" style="animation: fadeIn 0.6s ease-out;">
                            <div style="display: flex; align-items: center; margin-bottom: 10px; color: #16a34a; font-weight: 600;">
                                <span style="margin-right: 8px; font-size: 1.2em;">🔎</span>
                                <span>Résultats de recherche</span>
                            </div>
                        """, unsafe_allow_html=True)
                        
                        st.markdown(search_result)
                        
                        st.markdown("</div>", unsafe_allow_html=True)

                        # Ajouter le résultat aux messages
                        st.session_state.messages.append({
                            "role": "assistant", # Ou "search_result" si vous voulez un style distinct
                            "content": search_result,
                            "id": f"search_result_{datetime.now().isoformat()}"
                        })
                        save_current_conversation()
                        st.rerun() # Rerun après avoir ajouté le résultat

                    except Exception as e:
                        error_msg = f"Erreur lors de la recherche web: {str(e)}"
                        st.error(error_msg)
                        st.session_state.messages.append({
                            "role": "assistant",
                            "content": f"Désolé, une erreur s'est produite lors de la recherche web: {type(e).__name__}",
                            "id": f"search_error_{datetime.now().isoformat()}"
                        })
                        save_current_conversation()
                        st.rerun() # Rerun même après erreur

    elif not is_project_command and not is_kb_command and not is_inventory_command: # Traiter comme chat normal (seulement si ce n'est pas une commande)
        # --- Logique Réponse Claude ---
        with st.chat_message("assistant", avatar="🏗️"):
            placeholder = st.empty()
            with st.spinner("L'expert réfléchit..."):
                try:
                    # Préparer l'historique pour l'API Claude
                    # Exclure le dernier message utilisateur de l'historique passé à Claude
                    history_for_claude = [
                        msg for msg in st.session_state.messages[:-1]
                        if msg.get("role") in ["user", "assistant", "search_result"] # Filtrer les rôles valides
                    ]

                    response_content = st.session_state.expert_advisor.obtenir_reponse(user_content, history_for_claude)
                    
                    # Affichage amélioré de la réponse
                    placeholder.markdown("""
                    <div class="assistant-response" style="animation: fadeIn 0.6s ease-out;">
                    """, unsafe_allow_html=True)
                    
                    placeholder.markdown(response_content, unsafe_allow_html=False)
                    
                    placeholder.markdown("</div>", unsafe_allow_html=True)
                    
                    st.session_state.messages.append({"role": "assistant", "content": response_content})
                    save_current_conversation()
                    st.rerun() # Rerun après la réponse de Claude

                except Exception as e:
                    error_msg = f"Erreur lors de l'obtention de la réponse de Claude: {e}"
                    print(error_msg)
                    st.exception(e)
                    placeholder.error(f"Désolé, une erreur technique s'est produite avec l'IA ({type(e).__name__}).")
                    st.session_state.messages.append({"role": "assistant", "content": f"Erreur technique avec l'IA ({type(e).__name__})."})
                    save_current_conversation()
                    st.rerun() # Rerun même après erreur

# --- Footer --- 
st.markdown("""
<div class="footer-container">
    <div class="copyright">© 2025 Constructo AI - Développé par Sylvain Leduc</div>
</div>
""", unsafe_allow_html=True)
