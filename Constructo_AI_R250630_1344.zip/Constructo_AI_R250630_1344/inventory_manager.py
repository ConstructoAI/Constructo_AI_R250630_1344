# inventory_manager.py
import sqlite3
import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
import uuid

class InventoryManager:
    """Gestionnaire d'inventaire pour matériaux de construction avec IA prédictive."""
    
    def __init__(self, db_path="inventory.db"):
        self.db_path = db_path
        self.init_database()
    
    def init_database(self):
        """Initialise la base de données d'inventaire."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Table des catégories de matériaux
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS categories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                description TEXT,
                icon TEXT DEFAULT '📦',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Table des articles/matériaux
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS items (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                description TEXT,
                category_id INTEGER,
                unit TEXT NOT NULL,
                current_stock REAL DEFAULT 0,
                minimum_stock REAL DEFAULT 0,
                maximum_stock REAL DEFAULT 0,
                unit_cost REAL DEFAULT 0,
                supplier_id INTEGER,
                location TEXT,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (category_id) REFERENCES categories (id),
                FOREIGN KEY (supplier_id) REFERENCES suppliers (id)
            )
        ''')
        
        # Table des fournisseurs
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS suppliers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                contact_person TEXT,
                phone TEXT,
                email TEXT,
                address TEXT,
                city TEXT DEFAULT 'Québec',
                postal_code TEXT,
                rating REAL DEFAULT 0,
                delivery_time_days INTEGER DEFAULT 7,
                is_active BOOLEAN DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Table des mouvements de stock
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS stock_movements (
                id TEXT PRIMARY KEY,
                item_id TEXT NOT NULL,
                movement_type TEXT NOT NULL, -- 'IN', 'OUT', 'ADJUSTMENT', 'TRANSFER'
                quantity REAL NOT NULL,
                unit_cost REAL DEFAULT 0,
                total_cost REAL DEFAULT 0,
                reference_type TEXT, -- 'PROJECT', 'PURCHASE', 'MANUAL', 'ADJUSTMENT'
                reference_id TEXT,
                notes TEXT,
                created_by TEXT DEFAULT 'system',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (item_id) REFERENCES items (id)
            )
        ''')
        
        # Table des commandes
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS purchase_orders (
                id TEXT PRIMARY KEY,
                supplier_id INTEGER NOT NULL,
                order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                expected_delivery DATE,
                status TEXT DEFAULT 'PENDING', -- 'PENDING', 'ORDERED', 'DELIVERED', 'CANCELLED'
                total_amount REAL DEFAULT 0,
                notes TEXT,
                created_by TEXT DEFAULT 'system',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (supplier_id) REFERENCES suppliers (id)
            )
        ''')
        
        # Table des lignes de commande
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS purchase_order_items (
                id TEXT PRIMARY KEY,
                order_id TEXT NOT NULL,
                item_id TEXT NOT NULL,
                quantity REAL NOT NULL,
                unit_cost REAL NOT NULL,
                total_cost REAL NOT NULL,
                FOREIGN KEY (order_id) REFERENCES purchase_orders (id),
                FOREIGN KEY (item_id) REFERENCES items (id)
            )
        ''')
        
        # Table des prédictions IA
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ai_predictions (
                id TEXT PRIMARY KEY,
                item_id TEXT NOT NULL,
                prediction_type TEXT NOT NULL, -- 'CONSUMPTION', 'REORDER', 'DEMAND'
                prediction_date DATE NOT NULL,
                predicted_quantity REAL NOT NULL,
                confidence_score REAL DEFAULT 0,
                factors JSON, -- Facteurs considérés pour la prédiction
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (item_id) REFERENCES items (id)
            )
        ''')
        
        conn.commit()
        conn.close()
        
        # Insérer des données de base si nécessaire
        self._insert_default_data()
    
    def _insert_default_data(self):
        """Insère les données de base (catégories, quelques matériaux exemple)."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Catégories par défaut
        default_categories = [
            ('Béton et Ciment', 'Matériaux de base en béton', '🧱'),
            ('Acier et Métaux', 'Structures métalliques et armatures', '🔩'),
            ('Bois et Charpente', 'Matériaux en bois et charpente', '🪵'),
            ('Isolation', 'Matériaux d\'isolation thermique', '🛡️'),
            ('Électricité', 'Matériel électrique', '⚡'),
            ('Plomberie', 'Matériel de plomberie', '🚿'),
            ('Finitions', 'Matériaux de finition', '🎨'),
            ('Outils et Équipements', 'Outils et équipements de chantier', '🔨')
        ]
        
        for name, desc, icon in default_categories:
            cursor.execute('''
                INSERT OR IGNORE INTO categories (name, description, icon)
                VALUES (?, ?, ?)
            ''', (name, desc, icon))
        
        # Fournisseurs exemple du Québec
        default_suppliers = [
            ('Béton Provincial', 'Marie Tremblay', '418-123-4567', 'marie@betonprovincial.qc.ca', 
             '123 Rue Industrielle', 'Québec', 'G1A 1A1', 4.5, 3),
            ('Acier Québec Inc.', 'Jean Dubois', '514-987-6543', 'jean@acierquebec.ca',
             '456 Bd. Métallurgie', 'Montréal', 'H1A 2B2', 4.2, 5),
            ('Bois du Nord', 'Sophie Lavoie', '819-555-0123', 'sophie@boisnord.qc.ca',
             '789 Route Forestière', 'Gatineau', 'J8A 3C3', 4.7, 7)
        ]
        
        for name, contact, phone, email, address, city, postal, rating, delivery in default_suppliers:
            cursor.execute('''
                INSERT OR IGNORE INTO suppliers 
                (name, contact_person, phone, email, address, city, postal_code, rating, delivery_time_days)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (name, contact, phone, email, address, city, postal, rating, delivery))
        
        conn.commit()
        conn.close()
    
    def add_category(self, name: str, description: str = "", icon: str = "📦") -> bool:
        """Ajoute une nouvelle catégorie."""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO categories (name, description, icon)
                VALUES (?, ?, ?)
            ''', (name, description, icon))
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            return False
    
    def add_item(self, name: str, category_id: int, unit: str, description: str = "",
                 minimum_stock: float = 0, maximum_stock: float = 0, 
                 unit_cost: float = 0, supplier_id: int = None, location: str = "") -> str:
        """Ajoute un nouvel article à l'inventaire."""
        item_id = str(uuid.uuid4())
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO items 
            (id, name, description, category_id, unit, minimum_stock, maximum_stock, 
             unit_cost, supplier_id, location)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (item_id, name, description, category_id, unit, minimum_stock, 
              maximum_stock, unit_cost, supplier_id, location))
        
        conn.commit()
        conn.close()
        return item_id
    
    def add_supplier(self, name: str, contact_person: str = "", phone: str = "",
                     email: str = "", address: str = "", city: str = "Québec",
                     postal_code: str = "", rating: float = 0, delivery_time_days: int = 7) -> int:
        """Ajoute un nouveau fournisseur."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO suppliers 
            (name, contact_person, phone, email, address, city, postal_code, rating, delivery_time_days)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (name, contact_person, phone, email, address, city, postal_code, rating, delivery_time_days))
        
        supplier_id = cursor.lastrowid
        conn.commit()
        conn.close()
        return supplier_id
    
    def update_stock(self, item_id: str, movement_type: str, quantity: float,
                     unit_cost: float = 0, reference_type: str = "MANUAL",
                     reference_id: str = None, notes: str = "", created_by: str = "system") -> bool:
        """Met à jour le stock d'un article."""
        try:
            movement_id = str(uuid.uuid4())
            total_cost = quantity * unit_cost
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Enregistrer le mouvement
            cursor.execute('''
                INSERT INTO stock_movements 
                (id, item_id, movement_type, quantity, unit_cost, total_cost, 
                 reference_type, reference_id, notes, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (movement_id, item_id, movement_type, quantity, unit_cost, total_cost,
                  reference_type, reference_id, notes, created_by))
            
            # Mettre à jour le stock actuel
            if movement_type in ['IN', 'ADJUSTMENT']:
                cursor.execute('''
                    UPDATE items SET current_stock = current_stock + ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (quantity, item_id))
            elif movement_type in ['OUT']:
                cursor.execute('''
                    UPDATE items SET current_stock = current_stock - ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = ?
                ''', (quantity, item_id))
            
            conn.commit()
            conn.close()
            return True
        except Exception as e:
            print(f"Erreur mise à jour stock: {e}")
            return False
    
    def get_categories(self) -> List[Dict]:
        """Récupère toutes les catégories."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM categories ORDER BY name')
        categories = []
        for row in cursor.fetchall():
            categories.append({
                'id': row[0], 'name': row[1], 'description': row[2],
                'icon': row[3], 'created_at': row[4]
            })
        
        conn.close()
        return categories
    
    def get_items(self, category_id: int = None, low_stock_only: bool = False) -> List[Dict]:
        """Récupère les articles de l'inventaire."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query = '''
            SELECT i.*, c.name as category_name, c.icon as category_icon,
                   s.name as supplier_name
            FROM items i
            LEFT JOIN categories c ON i.category_id = c.id
            LEFT JOIN suppliers s ON i.supplier_id = s.id
            WHERE i.is_active = 1
        '''
        params = []
        
        if category_id:
            query += ' AND i.category_id = ?'
            params.append(category_id)
        
        if low_stock_only:
            query += ' AND i.current_stock <= i.minimum_stock'
        
        query += ' ORDER BY i.name'
        
        cursor.execute(query, params)
        items = []
        for row in cursor.fetchall():
            items.append({
                'id': row[0], 'name': row[1], 'description': row[2],
                'category_id': row[3], 'unit': row[4], 'current_stock': row[5],
                'minimum_stock': row[6], 'maximum_stock': row[7], 'unit_cost': row[8],
                'supplier_id': row[9], 'location': row[10], 'is_active': row[11],
                'created_at': row[12], 'updated_at': row[13],
                'category_name': row[14], 'category_icon': row[15], 'supplier_name': row[16]
            })
        
        conn.close()
        return items
    
    def get_suppliers(self, active_only: bool = True) -> List[Dict]:
        """Récupère la liste des fournisseurs."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query = 'SELECT * FROM suppliers'
        if active_only:
            query += ' WHERE is_active = 1'
        query += ' ORDER BY name'
        
        cursor.execute(query)
        suppliers = []
        for row in cursor.fetchall():
            suppliers.append({
                'id': row[0], 'name': row[1], 'contact_person': row[2],
                'phone': row[3], 'email': row[4], 'address': row[5],
                'city': row[6], 'postal_code': row[7], 'rating': row[8],
                'delivery_time_days': row[9], 'is_active': row[10], 'created_at': row[11]
            })
        
        conn.close()
        return suppliers
    
    def get_stock_movements(self, item_id: str = None, limit: int = 50) -> List[Dict]:
        """Récupère l'historique des mouvements de stock."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        query = '''
            SELECT sm.*, i.name as item_name, i.unit
            FROM stock_movements sm
            JOIN items i ON sm.item_id = i.id
        '''
        params = []
        
        if item_id:
            query += ' WHERE sm.item_id = ?'
            params.append(item_id)
        
        query += ' ORDER BY sm.created_at DESC LIMIT ?'
        params.append(limit)
        
        cursor.execute(query, params)
        movements = []
        for row in cursor.fetchall():
            movements.append({
                'id': row[0], 'item_id': row[1], 'movement_type': row[2],
                'quantity': row[3], 'unit_cost': row[4], 'total_cost': row[5],
                'reference_type': row[6], 'reference_id': row[7], 'notes': row[8],
                'created_by': row[9], 'created_at': row[10],
                'item_name': row[11], 'unit': row[12]
            })
        
        conn.close()
        return movements
    
    def get_dashboard_summary(self) -> Dict:
        """Génère un résumé pour le tableau de bord."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Statistiques générales
        cursor.execute('SELECT COUNT(*) FROM items WHERE is_active = 1')
        total_items = cursor.fetchone()[0]
        
        cursor.execute('SELECT COUNT(*) FROM items WHERE current_stock <= minimum_stock AND is_active = 1')
        low_stock_items = cursor.fetchone()[0]
        
        cursor.execute('SELECT SUM(current_stock * unit_cost) FROM items WHERE is_active = 1')
        total_value = cursor.fetchone()[0] or 0
        
        cursor.execute('SELECT COUNT(*) FROM suppliers WHERE is_active = 1')
        total_suppliers = cursor.fetchone()[0]
        
        # Mouvements récents
        cursor.execute('''
            SELECT COUNT(*) FROM stock_movements 
            WHERE created_at >= date('now', '-7 days')
        ''')
        recent_movements = cursor.fetchone()[0]
        
        # Top 5 des articles à faible stock
        cursor.execute('''
            SELECT i.name, i.current_stock, i.minimum_stock, i.unit, c.icon
            FROM items i
            JOIN categories c ON i.category_id = c.id
            WHERE i.current_stock <= i.minimum_stock AND i.is_active = 1
            ORDER BY (i.current_stock / NULLIF(i.minimum_stock, 0)) ASC
            LIMIT 5
        ''')
        low_stock_details = []
        for row in cursor.fetchall():
            low_stock_details.append({
                'name': row[0], 'current_stock': row[1], 'minimum_stock': row[2],
                'unit': row[3], 'icon': row[4]
            })
        
        conn.close()
        
        return {
            'total_items': total_items,
            'low_stock_items': low_stock_items,
            'total_value': total_value,
            'total_suppliers': total_suppliers,
            'recent_movements': recent_movements,
            'low_stock_details': low_stock_details
        }
    
    def create_purchase_order(self, supplier_id: int, items_list: List[Dict], 
                             expected_delivery: str = None, notes: str = "") -> str:
        """Crée une commande d'achat."""
        order_id = str(uuid.uuid4())
        total_amount = sum(item['quantity'] * item['unit_cost'] for item in items_list)
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Créer la commande
        cursor.execute('''
            INSERT INTO purchase_orders 
            (id, supplier_id, expected_delivery, total_amount, notes)
            VALUES (?, ?, ?, ?, ?)
        ''', (order_id, supplier_id, expected_delivery, total_amount, notes))
        
        # Ajouter les lignes de commande
        for item in items_list:
            item_order_id = str(uuid.uuid4())
            cursor.execute('''
                INSERT INTO purchase_order_items 
                (id, order_id, item_id, quantity, unit_cost, total_cost)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (item_order_id, order_id, item['item_id'], item['quantity'], 
                  item['unit_cost'], item['quantity'] * item['unit_cost']))
        
        conn.commit()
        conn.close()
        return order_id
    
    def predict_consumption(self, item_id: str, days_ahead: int = 30) -> Dict:
        """Prédiction IA simple de la consommation future."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Analyser l'historique des 90 derniers jours
        cursor.execute('''
            SELECT quantity, created_at FROM stock_movements 
            WHERE item_id = ? AND movement_type = 'OUT' 
            AND created_at >= date('now', '-90 days')
            ORDER BY created_at DESC
        ''', (item_id,))
        
        movements = cursor.fetchall()
        conn.close()
        
        if not movements:
            return {
                'predicted_consumption': 0,
                'confidence': 0,
                'reorder_suggestion': False,
                'factors': ['Aucun historique disponible']
            }
        
        # Calcul de la consommation moyenne
        total_consumption = sum(float(m[0]) for m in movements)
        days_with_data = len(set(m[1][:10] for m in movements))  # Jours uniques
        
        if days_with_data == 0:
            daily_avg = 0
        else:
            daily_avg = total_consumption / days_with_data
        
        predicted_consumption = daily_avg * days_ahead
        
        # Facteurs de confiance
        confidence = min(days_with_data / 30, 1.0)  # Plus de données = plus de confiance
        
        # Suggestion de réapprovisionnement
        current_item = self.get_items()
        current_stock = next((item['current_stock'] for item in current_item if item['id'] == item_id), 0)
        reorder_suggestion = predicted_consumption > current_stock * 0.8
        
        factors = [
            f"Basé sur {len(movements)} mouvements",
            f"Consommation moyenne: {daily_avg:.2f}/jour",
            f"Stock actuel: {current_stock}"
        ]
        
        return {
            'predicted_consumption': round(predicted_consumption, 2),
            'confidence': round(confidence, 2),
            'reorder_suggestion': reorder_suggestion,
            'factors': factors
        }
    
    def get_intelligent_reorder_suggestions(self) -> List[Dict]:
        """Génère des suggestions de réapprovisionnement intelligentes."""
        items = self.get_items()
        suggestions = []
        
        for item in items:
            if item['current_stock'] <= item['minimum_stock']:
                prediction = self.predict_consumption(item['id'])
                
                # Calculer la quantité suggérée
                safety_stock = item['minimum_stock']
                predicted_need = prediction['predicted_consumption']
                suggested_quantity = max(
                    item['maximum_stock'] - item['current_stock'],
                    predicted_need + safety_stock - item['current_stock']
                )
                
                if suggested_quantity > 0:
                    suggestions.append({
                        'item': item,
                        'suggested_quantity': round(suggested_quantity, 2),
                        'prediction': prediction,
                        'urgency': 'HIGH' if item['current_stock'] <= 0 else 'MEDIUM' if item['current_stock'] <= item['minimum_stock'] * 0.5 else 'LOW'
                    })
        
        # Trier par urgence et stock ratio
        urgency_order = {'HIGH': 3, 'MEDIUM': 2, 'LOW': 1}
        suggestions.sort(key=lambda x: (urgency_order[x['urgency']], -x['item']['current_stock']), reverse=True)
        
        return suggestions
    
    def search_items(self, search_term: str) -> List[Dict]:
        """Recherche d'articles par nom ou description."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT i.*, c.name as category_name, c.icon as category_icon,
                   s.name as supplier_name
            FROM items i
            LEFT JOIN categories c ON i.category_id = c.id
            LEFT JOIN suppliers s ON i.supplier_id = s.id
            WHERE i.is_active = 1 
            AND (i.name LIKE ? OR i.description LIKE ?)
            ORDER BY i.name
        ''', (f'%{search_term}%', f'%{search_term}%'))
        
        items = []
        for row in cursor.fetchall():
            items.append({
                'id': row[0], 'name': row[1], 'description': row[2],
                'category_id': row[3], 'unit': row[4], 'current_stock': row[5],
                'minimum_stock': row[6], 'maximum_stock': row[7], 'unit_cost': row[8],
                'supplier_id': row[9], 'location': row[10], 'is_active': row[11],
                'created_at': row[12], 'updated_at': row[13],
                'category_name': row[14], 'category_icon': row[15], 'supplier_name': row[16]
            })
        
        conn.close()
        return items
