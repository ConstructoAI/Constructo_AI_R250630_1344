# database_manager.py
import sqlite3
import json
import hashlib
import re
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Any
import os

class DatabaseManager:
    """Gestionnaire centralisé pour toutes les bases de données SQLite de Constructo AI."""
    
    def __init__(self, db_path="constructo_ai.db"):
        self.db_path = db_path
        
        # Assurer que le dossier pour la DB existe
        db_dir = os.path.dirname(db_path)
        if db_dir and not os.path.exists(db_dir):
            os.makedirs(db_dir, exist_ok=True)
            print(f"Création du dossier pour la base de données: {db_dir}")
        
        print(f"Initialisation DatabaseManager avec db: {self.db_path}")
        try:
            self._create_all_tables()
            self._init_default_data()
            print("DatabaseManager initialisé avec succès.")
        except Exception as e:
            print(f"Erreur lors de l'initialisation: {e}")
            raise
    
    def _connect(self):
        """Établit une connexion à la base de données avec optimisations."""
        try:
            conn = sqlite3.connect(self.db_path, isolation_level=None)
            conn.row_factory = sqlite3.Row
            
            # Optimisations SQLite
            conn.execute("PRAGMA foreign_keys = ON")
            conn.execute("PRAGMA journal_mode = WAL")
            conn.execute("PRAGMA synchronous = NORMAL")
            conn.execute("PRAGMA cache_size = 10000")
            conn.execute("PRAGMA temp_store = MEMORY")
            
            return conn
        except sqlite3.Error as e:
            print(f"Erreur de connexion à la base de données ({self.db_path}): {e}")
            raise
    
    def _create_knowledge_tables(self):
        """Méthode de rétrocompatibilité - les tables sont maintenant créées dans _create_all_tables."""
        print("Note: _create_knowledge_tables est obsolète. Toutes les tables sont créées dans _create_all_tables.")
        pass
    
    def _create_all_tables(self):
        """Crée toutes les tables nécessaires pour l'application."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # ===============================
                # TABLE UTILISATEURS
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT UNIQUE NOT NULL,
                        email TEXT UNIQUE,
                        password_hash TEXT,
                        full_name TEXT,
                        company TEXT,
                        phone TEXT,
                        role TEXT DEFAULT 'user',
                        subscription_type TEXT DEFAULT 'free',
                        subscription_expires TEXT,
                        created_at TEXT NOT NULL,
                        last_login TEXT,
                        is_active BOOLEAN DEFAULT 1,
                        metadata TEXT DEFAULT '{}'
                    )
                """)
                
                # ===============================
                # TABLE SESSIONS
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS user_sessions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        session_token TEXT UNIQUE NOT NULL,
                        created_at TEXT NOT NULL,
                        expires_at TEXT NOT NULL,
                        last_activity TEXT,
                        ip_address TEXT,
                        user_agent TEXT,
                        is_active BOOLEAN DEFAULT 1,
                        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
                    )
                """)
                
                # ===============================
                # TABLE PROFILS EXPERTS (Cache)
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS expert_profiles (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        profile_id TEXT UNIQUE NOT NULL,
                        name TEXT NOT NULL,
                        specialty TEXT,
                        description TEXT,
                        content TEXT NOT NULL,
                        file_path TEXT,
                        file_hash TEXT,
                        version INTEGER DEFAULT 1,
                        is_active BOOLEAN DEFAULT 1,
                        usage_count INTEGER DEFAULT 0,
                        success_rate REAL DEFAULT 0.0,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        metadata TEXT DEFAULT '{}'
                    )
                """)
                
                # ===============================
                # TABLE PROFILS PERSONNALISÉS
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS custom_profiles (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        profile_name TEXT NOT NULL,
                        display_name TEXT NOT NULL,
                        specialty TEXT,
                        description TEXT,
                        profile_content TEXT NOT NULL,
                        is_public BOOLEAN DEFAULT 0,
                        is_active BOOLEAN DEFAULT 1,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        usage_count INTEGER DEFAULT 0,
                        rating REAL DEFAULT 0.0,
                        tags TEXT DEFAULT '[]',
                        category TEXT DEFAULT 'custom',
                        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
                        UNIQUE(user_id, profile_name)
                    )
                """)
                
                # ===============================
                # TABLE CONVERSATIONS (Améliorée)
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS conversations (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        title TEXT NOT NULL,
                        expert_profile_id TEXT,
                        custom_profile_id INTEGER,
                        conversation_type TEXT DEFAULT 'chat',
                        status TEXT DEFAULT 'active',
                        message_count INTEGER DEFAULT 0,
                        total_tokens INTEGER DEFAULT 0,
                        created_at TEXT NOT NULL,
                        last_updated_at TEXT NOT NULL,
                        ended_at TEXT,
                        rating INTEGER,
                        feedback TEXT,
                        metadata TEXT DEFAULT '{}',
                        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
                        FOREIGN KEY (expert_profile_id) REFERENCES expert_profiles (profile_id),
                        FOREIGN KEY (custom_profile_id) REFERENCES custom_profiles (id)
                    )
                """)
                
                # ===============================
                # TABLE MESSAGES (Améliorée)
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS messages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        conversation_id INTEGER NOT NULL,
                        role TEXT NOT NULL,
                        content TEXT NOT NULL,
                        content_hash TEXT,
                        expert_profile_used TEXT,
                        custom_profile_used INTEGER,
                        token_count INTEGER DEFAULT 0,
                        response_time REAL,
                        confidence_score REAL,
                        created_at TEXT NOT NULL,
                        metadata TEXT DEFAULT '{}',
                        FOREIGN KEY (conversation_id) REFERENCES conversations (id) ON DELETE CASCADE,
                        FOREIGN KEY (custom_profile_used) REFERENCES custom_profiles (id)
                    )
                """)
                
                # ===============================
                # TABLE PROJETS (Intégrée)
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS projects (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        name TEXT NOT NULL,
                        client_name TEXT,
                        client_contact TEXT,
                        project_type TEXT,
                        address TEXT,
                        city TEXT,
                        postal_code TEXT,
                        description TEXT,
                        budget_initial REAL DEFAULT 0,
                        budget_current REAL DEFAULT 0,
                        start_date TEXT,
                        end_date_planned TEXT,
                        end_date_actual TEXT,
                        status TEXT DEFAULT 'En planification',
                        priority TEXT DEFAULT 'Moyenne',
                        progress_percentage REAL DEFAULT 0,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        metadata TEXT DEFAULT '{}',
                        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
                    )
                """)
                
                # ===============================
                # TABLE TÂCHES PROJET
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS project_tasks (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_id INTEGER NOT NULL,
                        name TEXT NOT NULL,
                        description TEXT,
                        status TEXT DEFAULT 'À faire',
                        priority TEXT DEFAULT 'Moyenne',
                        assigned_to TEXT,
                        estimated_hours REAL DEFAULT 0,
                        actual_hours REAL DEFAULT 0,
                        estimated_cost REAL DEFAULT 0,
                        actual_cost REAL DEFAULT 0,
                        start_date TEXT,
                        end_date_planned TEXT,
                        end_date_actual TEXT,
                        dependencies TEXT DEFAULT '[]',
                        progress_percentage REAL DEFAULT 0,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        metadata TEXT DEFAULT '{}',
                        FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE
                    )
                """)
                
                # ===============================
                # TABLE DOCUMENTS
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS documents (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        project_id INTEGER,
                        conversation_id INTEGER,
                        filename TEXT NOT NULL,
                        original_filename TEXT,
                        file_path TEXT,
                        file_size INTEGER,
                        file_type TEXT,
                        mime_type TEXT,
                        file_hash TEXT UNIQUE,
                        analysis_status TEXT DEFAULT 'pending',
                        analysis_summary TEXT,
                        analysis_metadata TEXT DEFAULT '{}',
                        upload_source TEXT DEFAULT 'web',
                        is_processed BOOLEAN DEFAULT 0,
                        created_at TEXT NOT NULL,
                        processed_at TEXT,
                        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
                        FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE,
                        FOREIGN KEY (conversation_id) REFERENCES conversations (id) ON DELETE CASCADE
                    )
                """)
                
                # ===============================
                # TABLE DOCUMENTS BASE CONNAISSANCES
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS knowledge_documents (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER NOT NULL,
                        custom_profile_id INTEGER,
                        document_name TEXT NOT NULL,
                        file_path TEXT,
                        file_type TEXT,
                        file_size INTEGER,
                        content_extracted TEXT,
                        content_summary TEXT,
                        keywords TEXT DEFAULT '[]',
                        upload_date TEXT NOT NULL,
                        last_used TEXT,
                        is_processed BOOLEAN DEFAULT 0,
                        processing_status TEXT DEFAULT 'pending',
                        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
                        FOREIGN KEY (custom_profile_id) REFERENCES custom_profiles (id) ON DELETE CASCADE
                    )
                """)
                
                # ===============================
                # TABLE SNIPPETS DE CONNAISSANCES
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS knowledge_snippets (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        custom_profile_id INTEGER NOT NULL,
                        title TEXT NOT NULL,
                        content TEXT NOT NULL,
                        category TEXT,
                        tags TEXT DEFAULT '[]',
                        source_document_id INTEGER,
                        created_at TEXT NOT NULL,
                        updated_at TEXT NOT NULL,
                        FOREIGN KEY (custom_profile_id) REFERENCES custom_profiles (id) ON DELETE CASCADE,
                        FOREIGN KEY (source_document_id) REFERENCES knowledge_documents (id) ON DELETE SET NULL
                    )
                """)
                
                # ===============================
                # TABLE PARTAGE PROFILS
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS profile_sharing (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        custom_profile_id INTEGER NOT NULL,
                        shared_by_user_id INTEGER NOT NULL,
                        shared_with_user_id INTEGER,
                        organization TEXT,
                        permission_level TEXT DEFAULT 'read',
                        shared_at TEXT NOT NULL,
                        expires_at TEXT,
                        is_active BOOLEAN DEFAULT 1,
                        FOREIGN KEY (custom_profile_id) REFERENCES custom_profiles (id) ON DELETE CASCADE,
                        FOREIGN KEY (shared_by_user_id) REFERENCES users (id) ON DELETE CASCADE,
                        FOREIGN KEY (shared_with_user_id) REFERENCES users (id) ON DELETE CASCADE
                    )
                """)
                
                # ===============================
                # TABLE RECHERCHES WEB (Cache)
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS web_searches (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        query TEXT NOT NULL,
                        query_hash TEXT UNIQUE NOT NULL,
                        expert_profile_id TEXT,
                        results TEXT NOT NULL,
                        result_count INTEGER DEFAULT 0,
                        search_engine TEXT DEFAULT 'brave',
                        response_time REAL,
                        cache_expires_at TEXT,
                        usage_count INTEGER DEFAULT 1,
                        created_at TEXT NOT NULL,
                        last_used_at TEXT NOT NULL,
                        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
                    )
                """)
                
                # ===============================
                # TABLE LOGS ACTIVITÉ
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS activity_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        user_id INTEGER,
                        session_id INTEGER,
                        action_type TEXT NOT NULL,
                        resource_type TEXT,
                        resource_id INTEGER,
                        description TEXT,
                        ip_address TEXT,
                        user_agent TEXT,
                        success BOOLEAN DEFAULT 1,
                        error_message TEXT,
                        execution_time REAL,
                        metadata TEXT DEFAULT '{}',
                        created_at TEXT NOT NULL,
                        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
                        FOREIGN KEY (session_id) REFERENCES user_sessions (id) ON DELETE SET NULL
                    )
                """)
                
                # ===============================
                # TABLE STATISTIQUES UTILISATION
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS usage_statistics (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        date TEXT NOT NULL,
                        metric_type TEXT NOT NULL,
                        metric_name TEXT NOT NULL,
                        value REAL NOT NULL,
                        user_id INTEGER,
                        expert_profile_id TEXT,
                        additional_data TEXT DEFAULT '{}',
                        created_at TEXT NOT NULL,
                        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
                    )
                """)
                
                # ===============================
                # TABLE NOTES PROJET
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS project_notes (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        project_id INTEGER NOT NULL,
                        task_id INTEGER,
                        user_id INTEGER,
                        note_type TEXT DEFAULT 'general',
                        title TEXT,
                        content TEXT NOT NULL,
                        author TEXT,
                        is_important BOOLEAN DEFAULT 0,
                        tags TEXT DEFAULT '[]',
                        created_at TEXT NOT NULL,
                        updated_at TEXT,
                        FOREIGN KEY (project_id) REFERENCES projects (id) ON DELETE CASCADE,
                        FOREIGN KEY (task_id) REFERENCES project_tasks (id) ON DELETE CASCADE,
                        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
                    )
                """)
                
                # ===============================
                # TABLE VERSION SCHÉMA
                # ===============================
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS schema_version (
                        version INTEGER PRIMARY KEY,
                        applied_at TEXT NOT NULL,
                        description TEXT
                    )
                """)
                
                # ===============================
                # CRÉATION DES INDEX
                # ===============================
                
                # Index pour performances
                indexes = [
                    "CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id)",
                    "CREATE INDEX IF NOT EXISTS idx_conversations_updated ON conversations(last_updated_at)",
                    "CREATE INDEX IF NOT EXISTS idx_messages_conversation ON messages(conversation_id)",
                    "CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at)",
                    "CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id)",
                    "CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status)",
                    "CREATE INDEX IF NOT EXISTS idx_tasks_project ON project_tasks(project_id)",
                    "CREATE INDEX IF NOT EXISTS idx_tasks_status ON project_tasks(status)",
                    "CREATE INDEX IF NOT EXISTS idx_documents_user ON documents(user_id)",
                    "CREATE INDEX IF NOT EXISTS idx_documents_project ON documents(project_id)",
                    "CREATE INDEX IF NOT EXISTS idx_searches_hash ON web_searches(query_hash)",
                    "CREATE INDEX IF NOT EXISTS idx_searches_user ON web_searches(user_id)",
                    "CREATE INDEX IF NOT EXISTS idx_logs_user ON activity_logs(user_id)",
                    "CREATE INDEX IF NOT EXISTS idx_logs_created ON activity_logs(created_at)",
                    "CREATE INDEX IF NOT EXISTS idx_stats_date ON usage_statistics(date)",
                    "CREATE INDEX IF NOT EXISTS idx_stats_type ON usage_statistics(metric_type)",
                    "CREATE INDEX IF NOT EXISTS idx_sessions_user ON user_sessions(user_id)",
                    "CREATE INDEX IF NOT EXISTS idx_sessions_token ON user_sessions(session_token)",
                    "CREATE INDEX IF NOT EXISTS idx_profiles_active ON expert_profiles(is_active)",
                    # Index pour base de connaissances
                    "CREATE INDEX IF NOT EXISTS idx_custom_profiles_user ON custom_profiles(user_id)",
                    "CREATE INDEX IF NOT EXISTS idx_custom_profiles_active ON custom_profiles(is_active)",
                    "CREATE INDEX IF NOT EXISTS idx_knowledge_docs_profile ON knowledge_documents(custom_profile_id)",
                    "CREATE INDEX IF NOT EXISTS idx_knowledge_docs_processed ON knowledge_documents(is_processed)",
                    "CREATE INDEX IF NOT EXISTS idx_snippets_profile ON knowledge_snippets(custom_profile_id)",
                    "CREATE INDEX IF NOT EXISTS idx_sharing_profile ON profile_sharing(custom_profile_id)"
                ]
                
                for index_sql in indexes:
                    cursor.execute(index_sql)
                
                # Marquer la version du schéma
                cursor.execute("""
                    INSERT OR REPLACE INTO schema_version (version, applied_at, description)
                    VALUES (1, ?, 'Version initiale complète avec base de connaissances')
                """, (datetime.now().isoformat(),))
                
                print("Toutes les tables et index ont été créés avec succès.")
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la création des tables: {e}")
            raise
    
    def _init_default_data(self):
        """Initialise les données par défaut."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Vérifier s'il y a déjà des données
                cursor.execute("SELECT COUNT(*) FROM users")
                user_count = cursor.fetchone()[0]
                
                if user_count == 0:
                    # Créer un utilisateur par défaut
                    now = datetime.now().isoformat()
                    cursor.execute("""
                        INSERT INTO users (username, email, full_name, role, created_at)
                        VALUES (?, ?, ?, ?, ?)
                    """, ("admin", "admin@constructoai.ca", "Administrateur", "admin", now))
                    
                    print("Utilisateur administrateur par défaut créé.")
                
        except sqlite3.Error as e:
            print(f"Erreur lors de l'initialisation des données par défaut: {e}")
    
    # ===============================
    # MÉTHODES GESTION UTILISATEURS
    # ===============================
    
    def create_user(self, username: str, email: str = None, full_name: str = None, 
                   company: str = None, role: str = "user") -> int:
        """Crée un nouvel utilisateur avec validation."""
        # Validation des entrées
        if not username or len(username.strip()) < 3:
            raise ValueError("Le nom d'utilisateur doit contenir au moins 3 caractères")
        
        if email and not re.match(r'^[^@]+@[^@]+\.[^@]+$', email):
            raise ValueError("Format email invalide")
        
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                cursor.execute("""
                    INSERT INTO users (username, email, full_name, company, role, created_at)
                    VALUES (?, ?, ?, ?, ?, ?)
                """, (username.strip(), email, full_name, company, role, now))
                
                user_id = cursor.lastrowid
                
                # Log de création
                self.log_activity(user_id, "user_created", "user", user_id, 
                                f"Utilisateur {username} créé")
                
                return user_id
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la création de l'utilisateur: {e}")
            raise
    
    def get_user(self, user_id: int = None, username: str = None) -> Optional[Dict]:
        """Récupère un utilisateur par ID ou nom d'utilisateur."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                if user_id:
                    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
                elif username:
                    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
                else:
                    return None
                
                row = cursor.fetchone()
                return dict(row) if row else None
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération de l'utilisateur: {e}")
            return None
    
    def update_user_last_login(self, user_id: int):
        """Met à jour la dernière connexion d'un utilisateur."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                cursor.execute("""
                    UPDATE users SET last_login = ? WHERE id = ?
                """, (now, user_id))
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la mise à jour du last_login: {e}")
    
    # ===============================
    # MÉTHODES GESTION PROFILS EXPERTS
    # ===============================
    
    def cache_expert_profile(self, profile_id: str, name: str, content: str, 
                           file_path: str = None, specialty: str = None) -> bool:
        """Met en cache un profil expert."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                # Calculer le hash du contenu
                content_hash = hashlib.md5(content.encode()).hexdigest()
                
                # Vérifier si le profil existe déjà
                cursor.execute("SELECT id FROM expert_profiles WHERE profile_id = ?", (profile_id,))
                existing = cursor.fetchone()
                
                if existing:
                    # Mettre à jour
                    cursor.execute("""
                        UPDATE expert_profiles 
                        SET name = ?, content = ?, file_hash = ?, specialty = ?, 
                            updated_at = ?, version = version + 1
                        WHERE profile_id = ?
                    """, (name, content, content_hash, specialty, now, profile_id))
                else:
                    # Créer nouveau
                    cursor.execute("""
                        INSERT INTO expert_profiles 
                        (profile_id, name, content, file_path, file_hash, specialty, created_at, updated_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (profile_id, name, content, file_path, content_hash, specialty, now, now))
                
                return True
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la mise en cache du profil expert: {e}")
            return False
    
    def get_expert_profiles_stats(self) -> List[Dict]:
        """Récupère les statistiques des profils experts."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT profile_id, name, specialty, usage_count, success_rate, 
                           created_at, updated_at, is_active
                    FROM expert_profiles 
                    ORDER BY usage_count DESC, name ASC
                """)
                
                return [dict(row) for row in cursor.fetchall()]
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération des stats profils: {e}")
            return []
    
    def increment_profile_usage(self, profile_id: str, success: bool = True):
        """Incrémente l'utilisation d'un profil et met à jour le taux de succès."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Récupérer les stats actuelles
                cursor.execute("""
                    SELECT usage_count, success_rate FROM expert_profiles 
                    WHERE profile_id = ?
                """, (profile_id,))
                
                row = cursor.fetchone()
                if row:
                    current_usage = row[0]
                    current_success_rate = row[1]
                    
                    new_usage = current_usage + 1
                    
                    # Calcul du nouveau taux de succès
                    if success:
                        new_success_rate = ((current_success_rate * current_usage) + 1) / new_usage
                    else:
                        new_success_rate = (current_success_rate * current_usage) / new_usage
                    
                    cursor.execute("""
                        UPDATE expert_profiles 
                        SET usage_count = ?, success_rate = ? 
                        WHERE profile_id = ?
                    """, (new_usage, new_success_rate, profile_id))
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la mise à jour usage profil: {e}")
    
    # ===============================
    # MÉTHODES GESTION PROFILS PERSONNALISÉS
    # ===============================
    
    def create_custom_profile(self, user_id: int, profile_data: dict) -> int:
        """Crée un nouveau profil personnalisé."""
        # Validation des données requises
        required_fields = ['profile_name', 'display_name', 'profile_content']
        for field in required_fields:
            if field not in profile_data or not profile_data[field].strip():
                raise ValueError(f"Le champ {field} est requis")
        
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                cursor.execute("""
                    INSERT INTO custom_profiles 
                    (user_id, profile_name, display_name, specialty, description, 
                     profile_content, is_public, category, tags, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    user_id,
                    profile_data['profile_name'].strip(),
                    profile_data['display_name'].strip(),
                    profile_data.get('specialty', ''),
                    profile_data.get('description', ''),
                    profile_data['profile_content'].strip(),
                    profile_data.get('is_public', False),
                    profile_data.get('category', 'custom'),
                    json.dumps(profile_data.get('tags', [])),
                    now, now
                ))
                
                profile_id = cursor.lastrowid
                
                # Log de création
                self.log_activity(
                    user_id=user_id,
                    action_type="custom_profile_created",
                    resource_type="custom_profile",
                    resource_id=profile_id,
                    description=f"Profil personnalisé '{profile_data['display_name']}' créé"
                )
                
                return profile_id
                
        except sqlite3.Error as e:
            print(f"Erreur création profil personnalisé: {e}")
            raise
    
    def get_user_custom_profiles(self, user_id: int, include_shared: bool = True) -> List[Dict]:
        """Récupère les profils personnalisés d'un utilisateur."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Profils propres à l'utilisateur
                cursor.execute("""
                    SELECT *, 0 as is_shared FROM custom_profiles 
                    WHERE user_id = ? AND is_active = 1
                    ORDER BY updated_at DESC
                """, (user_id,))
                
                profiles = [dict(row) for row in cursor.fetchall()]
                
                # Profils partagés avec l'utilisateur
                if include_shared:
                    cursor.execute("""
                        SELECT cp.*, ps.permission_level, ps.shared_by_user_id,
                               u.username as shared_by_username, 1 as is_shared
                        FROM custom_profiles cp
                        JOIN profile_sharing ps ON cp.id = ps.custom_profile_id
                        LEFT JOIN users u ON ps.shared_by_user_id = u.id
                        WHERE ps.shared_with_user_id = ? 
                        AND ps.is_active = 1 
                        AND cp.is_active = 1
                        ORDER BY ps.shared_at DESC
                    """, (user_id,))
                    
                    shared_profiles = [dict(row) for row in cursor.fetchall()]
                    profiles.extend(shared_profiles)
                
                return profiles
                
        except sqlite3.Error as e:
            print(f"Erreur récupération profils personnalisés: {e}")
            return []
    
    def get_custom_profile(self, profile_id: int, user_id: int = None) -> Optional[Dict]:
        """Récupère un profil personnalisé spécifique."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Vérifier si l'utilisateur a accès au profil
                if user_id:
                    cursor.execute("""
                        SELECT cp.* FROM custom_profiles cp
                        LEFT JOIN profile_sharing ps ON cp.id = ps.custom_profile_id
                        WHERE cp.id = ? AND (
                            cp.user_id = ? OR 
                            cp.is_public = 1 OR
                            (ps.shared_with_user_id = ? AND ps.is_active = 1)
                        )
                        LIMIT 1
                    """, (profile_id, user_id, user_id))
                else:
                    cursor.execute("""
                        SELECT * FROM custom_profiles 
                        WHERE id = ? AND (is_public = 1 OR user_id IS NOT NULL)
                    """, (profile_id,))
                
                row = cursor.fetchone()
                return dict(row) if row else None
                
        except sqlite3.Error as e:
            print(f"Erreur récupération profil personnalisé: {e}")
            return None
    
    def update_custom_profile(self, profile_id: int, user_id: int, updates: dict) -> bool:
        """Met à jour un profil personnalisé."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Vérifier les permissions
                cursor.execute("""
                    SELECT user_id FROM custom_profiles WHERE id = ?
                """, (profile_id,))
                
                result = cursor.fetchone()
                if not result or result['user_id'] != user_id:
                    return False  # Pas d'autorisation
                
                # Construire la requête de mise à jour
                set_clauses = []
                values = []
                
                allowed_fields = [
                    'profile_name', 'display_name', 'specialty', 'description', 
                    'profile_content', 'is_public', 'category'
                ]
                
                for key, value in updates.items():
                    if key in allowed_fields and value is not None:
                        set_clauses.append(f"{key} = ?")
                        values.append(value.strip() if isinstance(value, str) else value)
                    elif key == 'tags':
                        set_clauses.append("tags = ?")
                        values.append(json.dumps(value))
                
                if not set_clauses:
                    return False
                
                set_clauses.append("updated_at = ?")
                values.append(datetime.now().isoformat())
                values.append(profile_id)
                
                query = f"UPDATE custom_profiles SET {', '.join(set_clauses)} WHERE id = ?"
                cursor.execute(query, values)
                
                # Log de modification
                self.log_activity(
                    user_id=user_id,
                    action_type="custom_profile_updated",
                    resource_type="custom_profile",
                    resource_id=profile_id,
                    description=f"Profil personnalisé mis à jour"
                )
                
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            print(f"Erreur mise à jour profil personnalisé: {e}")
            return False
    
    def delete_custom_profile(self, profile_id: int, user_id: int) -> bool:
        """Supprime un profil personnalisé."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Vérifier les permissions
                cursor.execute("""
                    SELECT user_id, display_name FROM custom_profiles WHERE id = ?
                """, (profile_id,))
                
                result = cursor.fetchone()
                if not result or result['user_id'] != user_id:
                    return False
                
                # Supprimer (cascade supprimera les documents et snippets associés)
                cursor.execute("DELETE FROM custom_profiles WHERE id = ?", (profile_id,))
                
                # Log de suppression
                self.log_activity(
                    user_id=user_id,
                    action_type="custom_profile_deleted",
                    resource_type="custom_profile",
                    resource_id=profile_id,
                    description=f"Profil personnalisé '{result['display_name']}' supprimé"
                )
                
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            print(f"Erreur suppression profil personnalisé: {e}")
            return False
    
    def increment_custom_profile_usage(self, profile_id: int):
        """Incrémente l'utilisation d'un profil personnalisé."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    UPDATE custom_profiles 
                    SET usage_count = usage_count + 1 
                    WHERE id = ?
                """, (profile_id,))
                
        except sqlite3.Error as e:
            print(f"Erreur incrémentation usage profil personnalisé: {e}")
    
    # ===============================
    # MÉTHODES GESTION DOCUMENTS CONNAISSANCES
    # ===============================
    
    def add_knowledge_document(self, user_id: int, custom_profile_id: int, 
                              document_data: dict) -> int:
        """Ajoute un document à la base de connaissances."""
        if not document_data.get('document_name'):
            raise ValueError("Le nom du document est requis")
        
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                cursor.execute("""
                    INSERT INTO knowledge_documents 
                    (user_id, custom_profile_id, document_name, file_path, file_type,
                     file_size, content_extracted, content_summary, keywords, upload_date)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    user_id, custom_profile_id,
                    document_data['document_name'].strip(),
                    document_data.get('file_path', ''),
                    document_data.get('file_type', ''),
                    document_data.get('file_size', 0),
                    document_data.get('content_extracted', ''),
                    document_data.get('content_summary', ''),
                    json.dumps(document_data.get('keywords', [])),
                    now
                ))
                
                doc_id = cursor.lastrowid
                
                # Log d'ajout
                self.log_activity(
                    user_id=user_id,
                    action_type="knowledge_document_added",
                    resource_type="knowledge_document",
                    resource_id=doc_id,
                    description=f"Document '{document_data['document_name']}' ajouté à la base de connaissances"
                )
                
                return doc_id
                
        except sqlite3.Error as e:
            print(f"Erreur ajout document base connaissances: {e}")
            raise
    
    def get_profile_documents(self, custom_profile_id: int) -> List[Dict]:
        """Récupère les documents d'un profil personnalisé."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT * FROM knowledge_documents 
                    WHERE custom_profile_id = ?
                    ORDER BY upload_date DESC
                """, (custom_profile_id,))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except sqlite3.Error as e:
            print(f"Erreur récupération documents profil: {e}")
            return []
    
    def update_document_processing(self, doc_id: int, content_extracted: str, 
                                 content_summary: str, keywords: List[str]) -> bool:
        """Met à jour le contenu traité d'un document."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    UPDATE knowledge_documents 
                    SET content_extracted = ?, content_summary = ?, keywords = ?,
                        is_processed = 1, processing_status = 'completed'
                    WHERE id = ?
                """, (content_extracted, content_summary, json.dumps(keywords), doc_id))
                
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            print(f"Erreur mise à jour traitement document: {e}")
            return False
    
    def delete_knowledge_document(self, doc_id: int, user_id: int) -> bool:
        """Supprime un document de la base de connaissances."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Vérifier les permissions
                cursor.execute("""
                    SELECT kd.user_id, kd.document_name, cp.user_id as profile_owner
                    FROM knowledge_documents kd
                    JOIN custom_profiles cp ON kd.custom_profile_id = cp.id
                    WHERE kd.id = ?
                """, (doc_id,))
                
                result = cursor.fetchone()
                if not result or (result['user_id'] != user_id and result['profile_owner'] != user_id):
                    return False
                
                cursor.execute("DELETE FROM knowledge_documents WHERE id = ?", (doc_id,))
                
                # Log de suppression
                self.log_activity(
                    user_id=user_id,
                    action_type="knowledge_document_deleted",
                    resource_type="knowledge_document",
                    resource_id=doc_id,
                    description=f"Document '{result['document_name']}' supprimé"
                )
                
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            print(f"Erreur suppression document: {e}")
            return False
    
    # ===============================
    # MÉTHODES GESTION SNIPPETS
    # ===============================
    
    def add_knowledge_snippet(self, custom_profile_id: int, snippet_data: dict, user_id: int = None) -> int:
        """Ajoute un snippet de connaissance."""
        if not snippet_data.get('title') or not snippet_data.get('content'):
            raise ValueError("Le titre et le contenu sont requis")
        
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                cursor.execute("""
                    INSERT INTO knowledge_snippets 
                    (custom_profile_id, title, content, category, tags, 
                     source_document_id, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    custom_profile_id,
                    snippet_data['title'].strip(),
                    snippet_data['content'].strip(),
                    snippet_data.get('category', ''),
                    json.dumps(snippet_data.get('tags', [])),
                    snippet_data.get('source_document_id'),
                    now, now
                ))
                
                snippet_id = cursor.lastrowid
                
                # Log d'ajout
                if user_id:
                    self.log_activity(
                        user_id=user_id,
                        action_type="knowledge_snippet_added",
                        resource_type="knowledge_snippet",
                        resource_id=snippet_id,
                        description=f"Snippet '{snippet_data['title']}' ajouté"
                    )
                
                return snippet_id
                
        except sqlite3.Error as e:
            print(f"Erreur ajout snippet: {e}")
            raise
    
    def get_profile_snippets(self, custom_profile_id: int) -> List[Dict]:
        """Récupère les snippets d'un profil."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT ks.*, kd.document_name as source_document_name
                    FROM knowledge_snippets ks
                    LEFT JOIN knowledge_documents kd ON ks.source_document_id = kd.id
                    WHERE ks.custom_profile_id = ?
                    ORDER BY ks.created_at DESC
                """, (custom_profile_id,))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except sqlite3.Error as e:
            print(f"Erreur récupération snippets: {e}")
            return []
    
    def update_knowledge_snippet(self, snippet_id: int, updates: dict, user_id: int = None) -> bool:
        """Met à jour un snippet de connaissance."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Construire la requête de mise à jour
                set_clauses = []
                values = []
                
                allowed_fields = ['title', 'content', 'category']
                
                for key, value in updates.items():
                    if key in allowed_fields and value is not None:
                        set_clauses.append(f"{key} = ?")
                        values.append(value.strip() if isinstance(value, str) else value)
                    elif key == 'tags':
                        set_clauses.append("tags = ?")
                        values.append(json.dumps(value))
                
                if not set_clauses:
                    return False
                
                set_clauses.append("updated_at = ?")
                values.append(datetime.now().isoformat())
                values.append(snippet_id)
                
                query = f"UPDATE knowledge_snippets SET {', '.join(set_clauses)} WHERE id = ?"
                cursor.execute(query, values)
                
                # Log de modification
                if user_id:
                    self.log_activity(
                        user_id=user_id,
                        action_type="knowledge_snippet_updated",
                        resource_type="knowledge_snippet",
                        resource_id=snippet_id,
                        description=f"Snippet mis à jour"
                    )
                
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            print(f"Erreur mise à jour snippet: {e}")
            return False
    
    def delete_knowledge_snippet(self, snippet_id: int, user_id: int = None) -> bool:
        """Supprime un snippet de connaissance."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Récupérer le titre pour le log
                cursor.execute("SELECT title FROM knowledge_snippets WHERE id = ?", (snippet_id,))
                result = cursor.fetchone()
                
                if not result:
                    return False
                
                cursor.execute("DELETE FROM knowledge_snippets WHERE id = ?", (snippet_id,))
                
                # Log de suppression
                if user_id:
                    self.log_activity(
                        user_id=user_id,
                        action_type="knowledge_snippet_deleted",
                        resource_type="knowledge_snippet",
                        resource_id=snippet_id,
                        description=f"Snippet '{result['title']}' supprimé"
                    )
                
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            print(f"Erreur suppression snippet: {e}")
            return False
    
    # ===============================
    # MÉTHODES GESTION PARTAGE PROFILS
    # ===============================
    
    def share_custom_profile(self, custom_profile_id: int, shared_by_user_id: int,
                           shared_with_user_id: int = None, organization: str = None,
                           permission_level: str = "read", expires_hours: int = None) -> int:
        """Partage un profil personnalisé avec un utilisateur ou une organisation."""
        if not shared_with_user_id and not organization:
            raise ValueError("Il faut spécifier soit un utilisateur soit une organisation")
        
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now()
                
                expires_at = None
                if expires_hours:
                    expires_at = (now + timedelta(hours=expires_hours)).isoformat()
                
                cursor.execute("""
                    INSERT INTO profile_sharing 
                    (custom_profile_id, shared_by_user_id, shared_with_user_id, 
                     organization, permission_level, shared_at, expires_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (custom_profile_id, shared_by_user_id, shared_with_user_id,
                      organization, permission_level, now.isoformat(), expires_at))
                
                share_id = cursor.lastrowid
                
                # Log de partage
                target = f"utilisateur {shared_with_user_id}" if shared_with_user_id else f"organisation {organization}"
                self.log_activity(
                    user_id=shared_by_user_id,
                    action_type="profile_shared",
                    resource_type="custom_profile",
                    resource_id=custom_profile_id,
                    description=f"Profil partagé avec {target}"
                )
                
                return share_id
                
        except sqlite3.Error as e:
            print(f"Erreur partage profil: {e}")
            raise
    
    def get_profile_shares(self, custom_profile_id: int) -> List[Dict]:
        """Récupère les partages d'un profil."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT ps.*, u1.username as shared_by_username, 
                           u2.username as shared_with_username
                    FROM profile_sharing ps
                    LEFT JOIN users u1 ON ps.shared_by_user_id = u1.id
                    LEFT JOIN users u2 ON ps.shared_with_user_id = u2.id
                    WHERE ps.custom_profile_id = ? AND ps.is_active = 1
                    ORDER BY ps.shared_at DESC
                """, (custom_profile_id,))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except sqlite3.Error as e:
            print(f"Erreur récupération partages: {e}")
            return []
    
    def revoke_profile_share(self, share_id: int, user_id: int) -> bool:
        """Révoque un partage de profil."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Vérifier les permissions
                cursor.execute("""
                    SELECT shared_by_user_id FROM profile_sharing WHERE id = ?
                """, (share_id,))
                
                result = cursor.fetchone()
                if not result or result['shared_by_user_id'] != user_id:
                    return False
                
                cursor.execute("""
                    UPDATE profile_sharing SET is_active = 0 WHERE id = ?
                """, (share_id,))
                
                # Log de révocation
                self.log_activity(
                    user_id=user_id,
                    action_type="profile_share_revoked",
                    resource_type="profile_sharing",
                    resource_id=share_id,
                    description=f"Partage de profil révoqué"
                )
                
                return cursor.rowcount > 0
                
        except sqlite3.Error as e:
            print(f"Erreur révocation partage: {e}")
            return False
    
    # ===============================
    # MÉTHODES GESTION RECHERCHE WEB CACHE
    # ===============================
    
    def cache_web_search(self, query: str, results: str, user_id: int = None, 
                        expert_profile_id: str = None, cache_hours: int = 24) -> bool:
        """Met en cache les résultats d'une recherche web."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now()
                expires_at = now + timedelta(hours=cache_hours)
                
                query_hash = hashlib.md5(query.lower().encode()).hexdigest()
                
                # Vérifier si la recherche existe déjà
                cursor.execute("""
                    SELECT id, usage_count FROM web_searches WHERE query_hash = ?
                """, (query_hash,))
                
                existing = cursor.fetchone()
                
                if existing:
                    # Mettre à jour l'utilisation et la date
                    cursor.execute("""
                        UPDATE web_searches 
                        SET usage_count = usage_count + 1, last_used_at = ?,
                            cache_expires_at = ?
                        WHERE query_hash = ?
                    """, (now.isoformat(), expires_at.isoformat(), query_hash))
                else:
                    # Créer nouvelle entrée
                    cursor.execute("""
                        INSERT INTO web_searches 
                        (user_id, query, query_hash, expert_profile_id, results, 
                         cache_expires_at, created_at, last_used_at)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """, (user_id, query, query_hash, expert_profile_id, results,
                          expires_at.isoformat(), now.isoformat(), now.isoformat()))
                
                return True
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la mise en cache de la recherche: {e}")
            return False
    
    def get_cached_search(self, query: str) -> Optional[str]:
        """Récupère les résultats en cache d'une recherche si elle est encore valide."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                query_hash = hashlib.md5(query.lower().encode()).hexdigest()
                
                cursor.execute("""
                    SELECT results FROM web_searches 
                    WHERE query_hash = ? AND cache_expires_at > ?
                """, (query_hash, now))
                
                row = cursor.fetchone()
                if row:
                    # Mettre à jour l'utilisation
                    cursor.execute("""
                        UPDATE web_searches 
                        SET usage_count = usage_count + 1, last_used_at = ?
                        WHERE query_hash = ?
                    """, (now, query_hash))
                    
                    return row[0]
                
                return None
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération du cache de recherche: {e}")
            return None
    
    def clean_expired_cache(self):
        """Nettoie les entrées de cache expirées."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                cursor.execute("""
                    DELETE FROM web_searches WHERE cache_expires_at < ?
                """, (now,))
                
                deleted_count = cursor.rowcount
                if deleted_count > 0:
                    print(f"Nettoyage cache: {deleted_count} entrées expirées supprimées")
                
        except sqlite3.Error as e:
            print(f"Erreur lors du nettoyage du cache: {e}")
    
    # ===============================
    # MÉTHODES GESTION CONVERSATIONS
    # ===============================
    
    def create_conversation(self, user_id: int, title: str, expert_profile_id: str = None,
                          custom_profile_id: int = None, conversation_type: str = "chat") -> int:
        """Crée une nouvelle conversation."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                cursor.execute("""
                    INSERT INTO conversations 
                    (user_id, title, expert_profile_id, custom_profile_id, 
                     conversation_type, created_at, last_updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (user_id, title, expert_profile_id, custom_profile_id, 
                      conversation_type, now, now))
                
                conversation_id = cursor.lastrowid
                
                # Log de création
                self.log_activity(
                    user_id=user_id,
                    action_type="conversation_created",
                    resource_type="conversation",
                    resource_id=conversation_id,
                    description=f"Conversation '{title}' créée"
                )
                
                return conversation_id
                
        except sqlite3.Error as e:
            print(f"Erreur création conversation: {e}")
            raise
    
    def add_message(self, conversation_id: int, role: str, content: str,
                   expert_profile_used: str = None, custom_profile_used: int = None,
                   token_count: int = 0, response_time: float = None) -> int:
        """Ajoute un message à une conversation."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                # Hash du contenu pour déduplication
                content_hash = hashlib.md5(content.encode()).hexdigest()
                
                cursor.execute("""
                    INSERT INTO messages 
                    (conversation_id, role, content, content_hash, expert_profile_used,
                     custom_profile_used, token_count, response_time, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (conversation_id, role, content, content_hash, expert_profile_used,
                      custom_profile_used, token_count, response_time, now))
                
                message_id = cursor.lastrowid
                
                # Mettre à jour la conversation
                cursor.execute("""
                    UPDATE conversations 
                    SET message_count = message_count + 1,
                        total_tokens = total_tokens + ?,
                        last_updated_at = ?
                    WHERE id = ?
                """, (token_count, now, conversation_id))
                
                # Incrémenter l'usage du profil utilisé
                if expert_profile_used:
                    self.increment_profile_usage(expert_profile_used)
                elif custom_profile_used:
                    self.increment_custom_profile_usage(custom_profile_used)
                
                return message_id
                
        except sqlite3.Error as e:
            print(f"Erreur ajout message: {e}")
            raise
    
    def get_conversation_messages(self, conversation_id: int, limit: int = 50) -> List[Dict]:
        """Récupère les messages d'une conversation."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT * FROM messages 
                    WHERE conversation_id = ? 
                    ORDER BY created_at ASC 
                    LIMIT ?
                """, (conversation_id, limit))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except sqlite3.Error as e:
            print(f"Erreur récupération messages: {e}")
            return []
    
    def get_user_conversations(self, user_id: int, limit: int = 20) -> List[Dict]:
        """Récupère les conversations d'un utilisateur."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT c.*, ep.name as expert_profile_name, 
                           cp.display_name as custom_profile_name
                    FROM conversations c
                    LEFT JOIN expert_profiles ep ON c.expert_profile_id = ep.profile_id
                    LEFT JOIN custom_profiles cp ON c.custom_profile_id = cp.id
                    WHERE c.user_id = ? 
                    ORDER BY c.last_updated_at DESC 
                    LIMIT ?
                """, (user_id, limit))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except sqlite3.Error as e:
            print(f"Erreur récupération conversations: {e}")
            return []
    
    # ===============================
    # MÉTHODES GESTION LOGS
    # ===============================
    
    def log_activity(self, user_id: int = None, action_type: str = "", 
                    resource_type: str = None, resource_id: int = None,
                    description: str = "", success: bool = True, 
                    execution_time: float = None, **kwargs):
        """Enregistre une activité utilisateur."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                metadata = json.dumps(kwargs) if kwargs else "{}"
                
                cursor.execute("""
                    INSERT INTO activity_logs 
                    (user_id, action_type, resource_type, resource_id, description,
                     success, execution_time, metadata, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (user_id, action_type, resource_type, resource_id, description,
                      success, execution_time, metadata, now))
                
        except sqlite3.Error as e:
            print(f"Erreur lors de l'enregistrement du log: {e}")
    
    def get_user_activity(self, user_id: int, limit: int = 50) -> List[Dict]:
        """Récupère l'activité récente d'un utilisateur."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT * FROM activity_logs 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT ?
                """, (user_id, limit))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération de l'activité: {e}")
            return []
    
    # ===============================
    # MÉTHODES GESTION STATISTIQUES
    # ===============================
    
    def record_usage_statistic(self, metric_type: str, metric_name: str, 
                              value: float, user_id: int = None, 
                              expert_profile_id: str = None, **additional_data):
        """Enregistre une statistique d'utilisation."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now()
                date_str = now.strftime("%Y-%m-%d")
                
                additional_json = json.dumps(additional_data) if additional_data else "{}"
                
                cursor.execute("""
                    INSERT INTO usage_statistics 
                    (date, metric_type, metric_name, value, user_id, 
                     expert_profile_id, additional_data, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (date_str, metric_type, metric_name, value, user_id,
                      expert_profile_id, additional_json, now.isoformat()))
                
        except sqlite3.Error as e:
            print(f"Erreur lors de l'enregistrement de la statistique: {e}")
    
    def get_usage_statistics(self, metric_type: str = None, 
                           start_date: str = None, end_date: str = None,
                           limit: int = 100) -> List[Dict]:
        """Récupère les statistiques d'utilisation."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                query = "SELECT * FROM usage_statistics WHERE 1=1"
                params = []
                
                if metric_type:
                    query += " AND metric_type = ?"
                    params.append(metric_type)
                
                if start_date:
                    query += " AND date >= ?"
                    params.append(start_date)
                
                if end_date:
                    query += " AND date <= ?"
                    params.append(end_date)
                
                query += " ORDER BY created_at DESC LIMIT ?"
                params.append(limit)
                
                cursor.execute(query, params)
                
                return [dict(row) for row in cursor.fetchall()]
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération des statistiques: {e}")
            return []
    
    # ===============================
    # MÉTHODES GESTION DOCUMENTS
    # ===============================
    
    def save_document(self, filename: str, file_path: str, file_size: int,
                     file_type: str, file_hash: str, user_id: int = None,
                     project_id: int = None, conversation_id: int = None) -> int:
        """Sauvegarde les métadonnées d'un document."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                cursor.execute("""
                    INSERT INTO documents 
                    (user_id, project_id, conversation_id, filename, file_path,
                     file_size, file_type, file_hash, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (user_id, project_id, conversation_id, filename, file_path,
                      file_size, file_type, file_hash, now))
                
                doc_id = cursor.lastrowid
                
                # Log de l'upload
                self.log_activity(user_id, "document_uploaded", "document", doc_id,
                                f"Document {filename} uploadé")
                
                return doc_id
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la sauvegarde du document: {e}")
            raise
    
    def update_document_analysis(self, doc_id: int, analysis_summary: str,
                               analysis_metadata: Dict = None):
        """Met à jour l'analyse d'un document."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                metadata_json = json.dumps(analysis_metadata or {})
                
                cursor.execute("""
                    UPDATE documents 
                    SET analysis_status = 'completed', 
                        analysis_summary = ?, 
                        analysis_metadata = ?,
                        is_processed = 1,
                        processed_at = ?
                    WHERE id = ?
                """, (analysis_summary, metadata_json, now, doc_id))
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la mise à jour de l'analyse: {e}")
    
    def get_user_documents(self, user_id: int, limit: int = 50) -> List[Dict]:
        """Récupère les documents d'un utilisateur."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                cursor.execute("""
                    SELECT * FROM documents 
                    WHERE user_id = ? 
                    ORDER BY created_at DESC 
                    LIMIT ?
                """, (user_id, limit))
                
                return [dict(row) for row in cursor.fetchall()]
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération des documents: {e}")
            return []
    
    # ===============================
    # MÉTHODES MAINTENANCE ET DIAGNOSTIC
    # ===============================
    
    def verify_database_integrity(self) -> Dict[str, bool]:
        """Vérifie l'intégrité de la base de données."""
        results = {}
        
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Vérifier l'intégrité SQLite
                cursor.execute("PRAGMA integrity_check")
                integrity_result = cursor.fetchone()[0]
                results['sqlite_integrity'] = integrity_result == 'ok'
                
                # Vérifier que toutes les tables existent
                expected_tables = [
                    'users', 'user_sessions', 'expert_profiles', 'custom_profiles',
                    'conversations', 'messages', 'projects', 'project_tasks',
                    'documents', 'knowledge_documents', 'knowledge_snippets',
                    'profile_sharing', 'web_searches', 'activity_logs',
                    'usage_statistics', 'project_notes', 'schema_version'
                ]
                
                cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
                existing_tables = [row[0] for row in cursor.fetchall()]
                
                for table in expected_tables:
                    results[f'table_{table}'] = table in existing_tables
                
                # Vérifier les contraintes de clés étrangères
                cursor.execute("PRAGMA foreign_key_check")
                fk_violations = cursor.fetchall()
                results['foreign_keys_ok'] = len(fk_violations) == 0
                
                return results
                
        except Exception as e:
            print(f"Erreur lors de la vérification d'intégrité: {e}")
            return {'error': str(e)}
    
    def test_basic_operations(self) -> bool:
        """Teste les opérations de base de la base de données."""
        try:
            # Test création utilisateur
            test_username = f"test_user_{int(datetime.now().timestamp())}"
            user_id = self.create_user(test_username, "test@example.com")
            
            # Test récupération utilisateur
            user = self.get_user(user_id)
            if not user or user['username'] != test_username:
                return False
            
            # Test création profil personnalisé
            profile_data = {
                'profile_name': 'test_profile',
                'display_name': 'Test Profile',
                'profile_content': 'Test content'
            }
            profile_id = self.create_custom_profile(user_id, profile_data)
            
            # Test récupération profils
            profiles = self.get_user_custom_profiles(user_id)
            if not profiles or len(profiles) == 0:
                return False
            
            # Nettoyer les données de test
            self.delete_custom_profile(profile_id, user_id)
            
            # Supprimer l'utilisateur de test
            with self._connect() as conn:
                cursor = conn.cursor()
                cursor.execute("DELETE FROM users WHERE id = ?", (user_id,))
            
            print("Tests de base réussis.")
            return True
            
        except Exception as e:
            print(f"Erreur lors des tests de base: {e}")
            return False
    
    def get_schema_version(self) -> int:
        """Récupère la version actuelle du schéma."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT version FROM schema_version ORDER BY version DESC LIMIT 1")
                result = cursor.fetchone()
                return result[0] if result else 0
        except:
            return 0
    
    def get_database_stats(self) -> Dict:
        """Récupère les statistiques de la base de données."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                stats = {}
                
                # Compter les enregistrements dans chaque table
                tables = [
                    "users", "conversations", "messages", "projects", 
                    "project_tasks", "documents", "web_searches", 
                    "activity_logs", "usage_statistics", "expert_profiles",
                    "custom_profiles", "knowledge_documents", "knowledge_snippets"
                ]
                
                for table in tables:
                    cursor.execute(f"SELECT COUNT(*) FROM {table}")
                    stats[f"{table}_count"] = cursor.fetchone()[0]
                
                # Taille de la base de données
                cursor.execute("PRAGMA page_count")
                page_count = cursor.fetchone()[0]
                cursor.execute("PRAGMA page_size") 
                page_size = cursor.fetchone()[0]
                stats["database_size_mb"] = round((page_count * page_size) / (1024 * 1024), 2)
                
                # Dernières activités
                cursor.execute("""
                    SELECT created_at FROM activity_logs 
                    ORDER BY created_at DESC LIMIT 1
                """)
                last_activity = cursor.fetchone()
                stats["last_activity"] = last_activity[0] if last_activity else None
                
                # Version du schéma
                stats["schema_version"] = self.get_schema_version()
                
                return stats
                
        except sqlite3.Error as e:
            print(f"Erreur lors de la récupération des stats DB: {e}")
            return {}
    
    def optimize_database(self):
        """Optimise la base de données (VACUUM, ANALYZE)."""
        try:
            with self._connect() as conn:
                print("Début de l'optimisation de la base de données...")
                
                # Analyser les tables pour optimiser les requêtes
                conn.execute("ANALYZE")
                
                # Nettoyer et compacter la base de données
                conn.execute("VACUUM")
                
                # Nettoyer le cache expiré
                self.clean_expired_cache()
                
                print("Optimisation de la base de données terminée.")
                
        except sqlite3.Error as e:
            print(f"Erreur lors de l'optimisation de la DB: {e}")
    
    def backup_database(self, backup_path: str = None) -> str:
        """Crée une sauvegarde de la base de données."""
        try:
            if not backup_path:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                backup_path = f"backup_constructo_ai_{timestamp}.db"
            
            with self._connect() as source:
                backup = sqlite3.connect(backup_path)
                source.backup(backup)
                backup.close()
            
            print(f"Sauvegarde créée: {backup_path}")
            return backup_path
            
        except Exception as e:
            print(f"Erreur lors de la sauvegarde: {e}")
            raise
    
    # ===============================
    # MÉTHODES RECHERCHE ET ANALYSE
    # ===============================
    
    def search_knowledge_base(self, user_id: int, query: str, 
                            custom_profile_id: int = None) -> List[Dict]:
        """Recherche dans la base de connaissances personnalisée."""
        try:
            with self._connect() as conn:
                cursor = conn.cursor()
                
                # Recherche dans les profils accessibles
                profiles_query = """
                    SELECT cp.id, cp.display_name, cp.profile_content, cp.description
                    FROM custom_profiles cp
                    LEFT JOIN profile_sharing ps ON cp.id = ps.custom_profile_id
                    WHERE (cp.user_id = ? OR cp.is_public = 1 OR 
                           (ps.shared_with_user_id = ? AND ps.is_active = 1))
                    AND cp.is_active = 1
                """
                
                params = [user_id, user_id]
                
                if custom_profile_id:
                    profiles_query += " AND cp.id = ?"
                    params.append(custom_profile_id)
                
                profiles_query += " AND (cp.display_name LIKE ? OR cp.description LIKE ? OR cp.profile_content LIKE ?)"
                search_term = f"%{query}%"
                params.extend([search_term, search_term, search_term])
                
                cursor.execute(profiles_query, params)
                profile_results = [dict(row) for row in cursor.fetchall()]
                
                # Recherche dans les documents
                docs_query = """
                    SELECT kd.*, cp.display_name as profile_name
                    FROM knowledge_documents kd
                    JOIN custom_profiles cp ON kd.custom_profile_id = cp.id
                    LEFT JOIN profile_sharing ps ON cp.id = ps.custom_profile_id
                    WHERE (cp.user_id = ? OR cp.is_public = 1 OR 
                           (ps.shared_with_user_id = ? AND ps.is_active = 1))
                    AND (kd.document_name LIKE ? OR kd.content_summary LIKE ? OR kd.content_extracted LIKE ?)
                """
                
                cursor.execute(docs_query, [user_id, user_id, search_term, search_term, search_term])
                doc_results = [dict(row) for row in cursor.fetchall()]
                
                # Recherche dans les snippets
                snippets_query = """
                    SELECT ks.*, cp.display_name as profile_name
                    FROM knowledge_snippets ks
                    JOIN custom_profiles cp ON ks.custom_profile_id = cp.id
                    LEFT JOIN profile_sharing ps ON cp.id = ps.custom_profile_id
                    WHERE (cp.user_id = ? OR cp.is_public = 1 OR 
                           (ps.shared_with_user_id = ? AND ps.is_active = 1))
                    AND (ks.title LIKE ? OR ks.content LIKE ?)
                """
                
                cursor.execute(snippets_query, [user_id, user_id, search_term, search_term])
                snippet_results = [dict(row) for row in cursor.fetchall()]
                
                return {
                    'profiles': profile_results,
                    'documents': doc_results,
                    'snippets': snippet_results
                }
                
        except sqlite3.Error as e:
            print(f"Erreur recherche base de connaissances: {e}")
            return {'profiles': [], 'documents': [], 'snippets': []}


# ===============================
# FONCTION UTILITAIRE
# ===============================

def create_database_manager(db_path: str = "constructo_ai.db") -> DatabaseManager:
    """Fonction utilitaire pour créer une instance du gestionnaire de base de données."""
    return DatabaseManager(db_path)


# Exemple d'utilisation et tests de diagnostic
if __name__ == "__main__":
    print("=== DIAGNOSTIC DATABASE MANAGER ===\n")
    
    try:
        # Créer le gestionnaire
        print("1. Création du gestionnaire...")
        db_manager = DatabaseManager("test_constructo.db")
        print("✓ DatabaseManager créé avec succès\n")
        
        # Vérifier l'intégrité
        print("2. Vérification de l'intégrité...")
        integrity = db_manager.verify_database_integrity()
        for check, result in integrity.items():
            status = "✓" if result else "✗"
            print(f"   {status} {check}: {result}")
        print()
        
        # Tests de base
        print("3. Tests des opérations de base...")
        basic_tests = db_manager.test_basic_operations()
        status = "✓" if basic_tests else "✗"
        print(f"   {status} Tests de base: {basic_tests}\n")
        
        # Afficher les statistiques
        print("4. Statistiques de la base de données:")
        stats = db_manager.get_database_stats()
        for key, value in stats.items():
            print(f"   {key}: {value}")
        
        print("\n=== DIAGNOSTIC TERMINÉ AVEC SUCCÈS ===")
        
    except Exception as e:
        print(f"❌ ERREUR CRITIQUE: {e}")
        print("\nDétails de l'erreur:")
        import traceback
        traceback.print_exc()
        
        print("\n=== SOLUTIONS POSSIBLES ===")
        print("1. Vérifiez que tous les modules sont installés")
        print("2. Vérifiez les permissions d'écriture dans le dossier")
        print("3. Supprimez le fichier .db existant si corrompu")
        print("4. Contactez le support technique")