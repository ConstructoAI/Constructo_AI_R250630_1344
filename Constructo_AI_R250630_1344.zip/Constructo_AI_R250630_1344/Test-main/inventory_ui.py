# inventory_ui.py
import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import plotly.express as px
import plotly.graph_objects as go
from typing import Dict, List

class InventoryUI:
    """Interface utilisateur pour le gestionnaire d'inventaire."""
    
    def __init__(self, inventory_manager):
        self.inventory_manager = inventory_manager
        self.init_session_state()
    
    def init_session_state(self):
        """Initialise les variables d'état de session."""
        if 'inventory_view_mode' not in st.session_state:
            st.session_state.inventory_view_mode = 'dashboard'
        if 'selected_category' not in st.session_state:
            st.session_state.selected_category = None
        if 'inventory_search_term' not in st.session_state:
            st.session_state.inventory_search_term = ""
    
    def render_inventory_section(self):
        """Affiche la section complète de gestion d'inventaire."""
        st.markdown("# 📦 Gestion d'Inventaire IA")
        
        # Menu de navigation
        self._render_navigation_menu()
        
        # Affichage selon le mode sélectionné
        if st.session_state.inventory_view_mode == 'dashboard':
            self._render_dashboard()
        elif st.session_state.inventory_view_mode == 'items':
            self._render_items_management()
        elif st.session_state.inventory_view_mode == 'add_item':
            self._render_add_item_form()
        elif st.session_state.inventory_view_mode == 'stock_movements':
            self._render_stock_movements()
        elif st.session_state.inventory_view_mode == 'suppliers':
            self._render_suppliers_management()
        elif st.session_state.inventory_view_mode == 'purchase_orders':
            self._render_purchase_orders()
        elif st.session_state.inventory_view_mode == 'ai_predictions':
            self._render_ai_predictions()
        elif st.session_state.inventory_view_mode == 'reorder_suggestions':
            self._render_reorder_suggestions()
    
    def _render_navigation_menu(self):
        """Affiche le menu de navigation."""
        st.markdown("---")
        
        # Menu principal avec icônes
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            if st.button("📊 Tableau de Bord", use_container_width=True, 
                        type="primary" if st.session_state.inventory_view_mode == 'dashboard' else "secondary"):
                st.session_state.inventory_view_mode = 'dashboard'
                st.rerun()
        
        with col2:
            if st.button("📦 Articles", use_container_width=True,
                        type="primary" if st.session_state.inventory_view_mode == 'items' else "secondary"):
                st.session_state.inventory_view_mode = 'items'
                st.rerun()
        
        with col3:
            if st.button("📋 Mouvements", use_container_width=True,
                        type="primary" if st.session_state.inventory_view_mode == 'stock_movements' else "secondary"):
                st.session_state.inventory_view_mode = 'stock_movements'
                st.rerun()
        
        with col4:
            if st.button("🤖 IA Prédictive", use_container_width=True,
                        type="primary" if st.session_state.inventory_view_mode in ['ai_predictions', 'reorder_suggestions'] else "secondary"):
                st.session_state.inventory_view_mode = 'ai_predictions'
                st.rerun()
        
        # Menu secondaire
        col5, col6, col7, col8 = st.columns(4)
        
        with col5:
            if st.button("🏪 Fournisseurs", use_container_width=True,
                        type="primary" if st.session_state.inventory_view_mode == 'suppliers' else "secondary"):
                st.session_state.inventory_view_mode = 'suppliers'
                st.rerun()
        
        with col6:
            if st.button("🛒 Commandes", use_container_width=True,
                        type="primary" if st.session_state.inventory_view_mode == 'purchase_orders' else "secondary"):
                st.session_state.inventory_view_mode = 'purchase_orders'
                st.rerun()
        
        with col7:
            if st.button("➕ Nouvel Article", use_container_width=True):
                st.session_state.inventory_view_mode = 'add_item'
                st.rerun()
        
        with col8:
            if st.button("💡 Suggestions IA", use_container_width=True,
                        type="primary" if st.session_state.inventory_view_mode == 'reorder_suggestions' else "secondary"):
                st.session_state.inventory_view_mode = 'reorder_suggestions'
                st.rerun()
        
        st.markdown("---")
    
    def _render_dashboard(self):
        """Affiche le tableau de bord principal."""
        st.markdown("## 📊 Tableau de Bord - Vue d'ensemble")
        
        # Récupérer les données du tableau de bord
        summary = self.inventory_manager.get_dashboard_summary()
        
        # Métriques principales
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric(
                label="📦 Articles Totaux",
                value=summary['total_items'],
                help="Nombre total d'articles dans l'inventaire"
            )
        
        with col2:
            st.metric(
                label="⚠️ Stock Faible",
                value=summary['low_stock_items'],
                delta=f"-{summary['low_stock_items']}" if summary['low_stock_items'] > 0 else "0",
                delta_color="inverse",
                help="Articles en dessous du seuil minimum"
            )
        
        with col3:
            st.metric(
                label="💰 Valeur Inventaire",
                value=f"{summary['total_value']:,.2f} $",
                help="Valeur totale de l'inventaire"
            )
        
        with col4:
            st.metric(
                label="🏪 Fournisseurs",
                value=summary['total_suppliers'],
                help="Nombre de fournisseurs actifs"
            )
        
        st.markdown("---")
        
        # Colonnes pour les graphiques et alertes
        col_left, col_right = st.columns([2, 1])
        
        with col_left:
            # Graphique de répartition par catégorie
            self._render_category_distribution_chart()
            
            # Activité récente
            st.markdown("### 📈 Activité Récente (7 derniers jours)")
            recent_movements = self.inventory_manager.get_stock_movements(limit=10)
            
            if recent_movements:
                movements_df = pd.DataFrame(recent_movements)
                movements_df['created_at'] = pd.to_datetime(movements_df['created_at'])
                movements_df = movements_df.sort_values('created_at', ascending=False)
                
                for _, movement in movements_df.head(5).iterrows():
                    movement_type_icon = {
                        'IN': '📥', 'OUT': '📤', 'ADJUSTMENT': '⚖️', 'TRANSFER': '🔄'
                    }.get(movement['movement_type'], '📦')
                    
                    st.write(f"{movement_type_icon} **{movement['item_name']}** - "
                            f"{movement['quantity']} {movement['unit']} "
                            f"({movement['movement_type']}) - "
                            f"{movement['created_at'].strftime('%d/%m %H:%M')}")
            else:
                st.info("Aucune activité récente")
        
        with col_right:
            # Alertes de stock faible
            st.markdown("### 🚨 Alertes Stock Faible")
            
            if summary['low_stock_details']:
                for item in summary['low_stock_details']:
                    with st.container():
                        st.markdown(f"""
                        <div style="
                            border-left: 4px solid #ef4444;
                            padding: 10px;
                            margin: 8px 0;
                            background-color: #fef2f2;
                            border-radius: 0 8px 8px 0;
                        ">
                            <strong>{item['icon']} {item['name']}</strong><br>
                            <small>Stock: {item['current_stock']} {item['unit']} / Min: {item['minimum_stock']} {item['unit']}</small>
                        </div>
                        """, unsafe_allow_html=True)
                
                if st.button("💡 Voir Suggestions IA", use_container_width=True):
                    st.session_state.inventory_view_mode = 'reorder_suggestions'
                    st.rerun()
            else:
                st.success("✅ Tous les stocks sont au niveau optimal!")
            
            # Actions rapides
            st.markdown("### ⚡ Actions Rapides")
            
            if st.button("➕ Ajouter Article", use_container_width=True):
                st.session_state.inventory_view_mode = 'add_item'
                st.rerun()
            
            if st.button("📋 Mouvement Stock", use_container_width=True):
                st.session_state.inventory_view_mode = 'stock_movements'
                st.rerun()
            
            if st.button("🛒 Nouvelle Commande", use_container_width=True):
                st.session_state.inventory_view_mode = 'purchase_orders'
                st.rerun()
    
    def _render_category_distribution_chart(self):
        """Affiche un graphique de répartition par catégorie."""
        st.markdown("### 📊 Répartition par Catégorie")
        
        # Récupérer les données
        items = self.inventory_manager.get_items()
        categories = self.inventory_manager.get_categories()
        
        if not items:
            st.info("Aucun article dans l'inventaire")
            return
        
        # Préparer les données pour le graphique
        category_data = {}
        for item in items:
            cat_name = item['category_name'] or 'Sans catégorie'
            if cat_name not in category_data:
                category_data[cat_name] = {'count': 0, 'value': 0}
            category_data[cat_name]['count'] += 1
            category_data[cat_name]['value'] += item['current_stock'] * item['unit_cost']
        
        # Créer le graphique en secteurs
        labels = list(category_data.keys())
        values = [data['count'] for data in category_data.values()]
        
        fig = px.pie(
            values=values,
            names=labels,
            title="Nombre d'articles par catégorie"
        )
        fig.update_traces(textposition='inside', textinfo='percent+label')
        fig.update_layout(height=400)
        
        st.plotly_chart(fig, use_container_width=True)
    
    def _render_items_management(self):
        """Affiche la gestion des articles."""
        st.markdown("## 📦 Gestion des Articles")
        
        # Filtres et recherche
        col1, col2, col3 = st.columns([2, 1, 1])
        
        with col1:
            search_term = st.text_input(
                "🔍 Rechercher un article",
                value=st.session_state.inventory_search_term,
                placeholder="Nom ou description..."
            )
            st.session_state.inventory_search_term = search_term
        
        with col2:
            categories = self.inventory_manager.get_categories()
            category_options = [{"id": None, "name": "Toutes catégories"}] + categories
            selected_cat = st.selectbox(
                "Catégorie",
                options=category_options,
                format_func=lambda x: f"{x.get('icon', '📦')} {x['name']}",
                index=0
            )
            st.session_state.selected_category = selected_cat['id']
        
        with col3:
            show_low_stock = st.checkbox("🚨 Stock faible seulement")
        
        # Récupérer et filtrer les articles
        if search_term:
            items = self.inventory_manager.search_items(search_term)
        else:
            items = self.inventory_manager.get_items(
                category_id=st.session_state.selected_category,
                low_stock_only=show_low_stock
            )
        
        # Affichage des articles
        if not items:
            st.info("Aucun article trouvé avec ces critères")
            return
        
        st.markdown(f"**{len(items)} article(s) trouvé(s)**")
        
        # Tableau des articles avec actions
        for item in items:
            with st.container():
                # Déterminer le statut du stock
                stock_status = "🔴" if item['current_stock'] <= 0 else \
                              "🟡" if item['current_stock'] <= item['minimum_stock'] else "🟢"
                
                col_info, col_stock, col_actions = st.columns([3, 2, 1])
                
                with col_info:
                    st.markdown(f"""
                    **{item['category_icon']} {item['name']}**  
                    {item['description']}  
                    📍 {item['location'] or 'Non spécifié'} | 🏪 {item['supplier_name'] or 'Aucun fournisseur'}
                    """)
                
                with col_stock:
                    st.markdown(f"""
                    {stock_status} **Stock:** {item['current_stock']} {item['unit']}  
                    📉 Min: {item['minimum_stock']} | 📈 Max: {item['maximum_stock']}  
                    💰 {item['unit_cost']:.2f}$ / {item['unit']}
                    """)
                
                with col_actions:
                    if st.button("📝", key=f"edit_{item['id']}", help="Modifier"):
                        st.session_state.editing_item = item
                        st.session_state.inventory_view_mode = 'edit_item'
                        st.rerun()
                    
                    if st.button("📊", key=f"history_{item['id']}", help="Historique"):
                        st.session_state.selected_item_id = item['id']
                        st.session_state.inventory_view_mode = 'item_history'
                        st.rerun()
                
                st.markdown("---")
    
    def _render_add_item_form(self):
        """Affiche le formulaire d'ajout d'article."""
        st.markdown("## ➕ Ajouter un Nouvel Article")
        
        with st.form("add_item_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                name = st.text_input("Nom de l'article *", placeholder="Ex: Ciment Portland")
                description = st.text_area("Description", placeholder="Description détaillée...")
                
                categories = self.inventory_manager.get_categories()
                if not categories:
                    st.error("Aucune catégorie disponible. Veuillez en créer une.")
                    return
                
                category = st.selectbox(
                    "Catégorie *",
                    options=categories,
                    format_func=lambda x: f"{x['icon']} {x['name']}"
                )
                
                unit = st.selectbox(
                    "Unité de mesure *",
                    options=["kg", "t", "m", "m²", "m³", "l", "unité", "boîte", "sac", "palette"]
                )
            
            with col2:
                current_stock = st.number_input("Stock initial", min_value=0.0, value=0.0, step=0.1)
                minimum_stock = st.number_input("Stock minimum", min_value=0.0, value=0.0, step=0.1)
                maximum_stock = st.number_input("Stock maximum", min_value=0.0, step=0.1)
                unit_cost = st.number_input("Coût unitaire ($)", min_value=0.0, value=0.0, step=0.01)
                
                suppliers = self.inventory_manager.get_suppliers()
                supplier = st.selectbox(
                    "Fournisseur principal",
                    options=[None] + suppliers,
                    format_func=lambda x: "Aucun fournisseur" if x is None else x['name']
                )
                
                location = st.text_input("Emplacement", placeholder="Ex: Entrepôt A, Allée 3")
            
            submitted = st.form_submit_button("➕ Ajouter l'Article", use_container_width=True)
            
            if submitted:
                if not name or not category:
                    st.error("Veuillez remplir tous les champs obligatoires (*)")
                else:
                    try:
                        item_id = self.inventory_manager.add_item(
                            name=name,
                            description=description,
                            category_id=category['id'],
                            unit=unit,
                            minimum_stock=minimum_stock,
                            maximum_stock=maximum_stock,
                            unit_cost=unit_cost,
                            supplier_id=supplier['id'] if supplier else None,
                            location=location
                        )
                        
                        # Si stock initial > 0, créer un mouvement d'entrée
                        if current_stock > 0:
                            self.inventory_manager.update_stock(
                                item_id=item_id,
                                movement_type='IN',
                                quantity=current_stock,
                                unit_cost=unit_cost,
                                reference_type='INITIAL',
                                notes="Stock initial"
                            )
                        
                        st.success(f"✅ Article '{name}' ajouté avec succès!")
                        st.session_state.inventory_view_mode = 'items'
                        st.rerun()
                        
                    except Exception as e:
                        st.error(f"Erreur lors de l'ajout: {str(e)}")
        
        # Bouton retour
        if st.button("← Retour à la liste", use_container_width=True):
            st.session_state.inventory_view_mode = 'items'
            st.rerun()
    
    def _render_stock_movements(self):
        """Affiche la gestion des mouvements de stock."""
        st.markdown("## 📋 Mouvements de Stock")
        
        # Formulaire de nouveau mouvement
        with st.expander("➕ Ajouter un Mouvement", expanded=False):
            self._render_stock_movement_form()
        
        st.markdown("---")
        
        # Historique des mouvements
        st.markdown("### 📈 Historique des Mouvements")
        
        # Filtres
        col1, col2, col3 = st.columns(3)
        
        with col1:
            items = self.inventory_manager.get_items()
            selected_item = st.selectbox(
                "Filtrer par article",
                options=[None] + items,
                format_func=lambda x: "Tous les articles" if x is None else f"{x['category_icon']} {x['name']}"
            )
        
        with col2:
            movement_type_filter = st.selectbox(
                "Type de mouvement",
                options=[None, 'IN', 'OUT', 'ADJUSTMENT', 'TRANSFER'],
                format_func=lambda x: "Tous types" if x is None else {
                    'IN': '📥 Entrée', 'OUT': '📤 Sortie', 
                    'ADJUSTMENT': '⚖️ Ajustement', 'TRANSFER': '🔄 Transfert'
                }[x]
            )
        
        with col3:
            limit = st.selectbox("Nombre d'entrées", options=[25, 50, 100], index=1)
        
        # Récupérer les mouvements
        movements = self.inventory_manager.get_stock_movements(
            item_id=selected_item['id'] if selected_item else None,
            limit=limit
        )
        
        if movements:
            # Convertir en DataFrame pour l'affichage
            df = pd.DataFrame(movements)
            df['created_at'] = pd.to_datetime(df['created_at'])
            
            # Filtrer par type si sélectionné
            if movement_type_filter:
                df = df[df['movement_type'] == movement_type_filter]
            
            # Affichage formaté
            for _, movement in df.iterrows():
                movement_icon = {
                    'IN': '📥', 'OUT': '📤', 'ADJUSTMENT': '⚖️', 'TRANSFER': '🔄'
                }.get(movement['movement_type'], '📦')
                
                col_info, col_qty, col_cost = st.columns([3, 1, 1])
                
                with col_info:
                    st.markdown(f"""
                    {movement_icon} **{movement['item_name']}**  
                    {movement['notes'] or 'Aucune note'}  
                    🕒 {movement['created_at'].strftime('%d/%m/%Y %H:%M')} | 👤 {movement['created_by']}
                    """)
                
                with col_qty:
                    qty_color = "🟢" if movement['movement_type'] == 'IN' else "🔴"
                    st.markdown(f"{qty_color} **{movement['quantity']} {movement['unit']}**")
                
                with col_cost:
                    if movement['total_cost'] > 0:
                        st.markdown(f"💰 **{movement['total_cost']:.2f} $**")
                
                st.markdown("---")
        else:
            st.info("Aucun mouvement trouvé")
    
    def _render_stock_movement_form(self):
        """Formulaire pour ajouter un mouvement de stock."""
        with st.form("stock_movement_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                items = self.inventory_manager.get_items()
                if not items:
                    st.error("Aucun article disponible")
                    return
                
                selected_item = st.selectbox(
                    "Article *",
                    options=items,
                    format_func=lambda x: f"{x['category_icon']} {x['name']} (Stock: {x['current_stock']} {x['unit']})"
                )
                
                movement_type = st.selectbox(
                    "Type de mouvement *",
                    options=['IN', 'OUT', 'ADJUSTMENT'],
                    format_func=lambda x: {'IN': '📥 Entrée', 'OUT': '📤 Sortie', 'ADJUSTMENT': '⚖️ Ajustement'}[x]
                )
                
                quantity = st.number_input("Quantité *", min_value=0.1, step=0.1)
                
            with col2:
                unit_cost = st.number_input("Coût unitaire ($)", min_value=0.0, step=0.01)
                
                reference_type = st.selectbox(
                    "Type de référence",
                    options=['MANUAL', 'PROJECT', 'PURCHASE', 'ADJUSTMENT'],
                    format_func=lambda x: {
                        'MANUAL': 'Manuel', 'PROJECT': 'Projet', 
                        'PURCHASE': 'Achat', 'ADJUSTMENT': 'Ajustement'
                    }[x]
                )
                
                notes = st.text_area("Notes", placeholder="Raison du mouvement...")
            
            submitted = st.form_submit_button("✅ Enregistrer le Mouvement", use_container_width=True)
            
            if submitted:
                if not selected_item or quantity <= 0:
                    st.error("Veuillez remplir tous les champs obligatoires")
                else:
                    # Vérifier si on a assez de stock pour une sortie
                    if movement_type == 'OUT' and quantity > selected_item['current_stock']:
                        st.error(f"Stock insuffisant! Stock actuel: {selected_item['current_stock']} {selected_item['unit']}")
                    else:
                        success = self.inventory_manager.update_stock(
                            item_id=selected_item['id'],
                            movement_type=movement_type,
                            quantity=quantity,
                            unit_cost=unit_cost,
                            reference_type=reference_type,
                            notes=notes,
                            created_by="user"
                        )
                        
                        if success:
                            st.success("✅ Mouvement enregistré avec succès!")
                            st.rerun()
                        else:
                            st.error("❌ Erreur lors de l'enregistrement")
    
    def _render_suppliers_management(self):
        """Affiche la gestion des fournisseurs."""
        st.markdown("## 🏪 Gestion des Fournisseurs")
        
        # Formulaire d'ajout de fournisseur
        with st.expander("➕ Ajouter un Fournisseur", expanded=False):
            self._render_add_supplier_form()
        
        st.markdown("---")
        
        # Liste des fournisseurs
        suppliers = self.inventory_manager.get_suppliers()
        
        if not suppliers:
            st.info("Aucun fournisseur enregistré")
            return
        
        st.markdown(f"**{len(suppliers)} fournisseur(s) enregistré(s)**")
        
        for supplier in suppliers:
            with st.container():
                col_info, col_contact, col_rating = st.columns([2, 2, 1])
                
                with col_info:
                    st.markdown(f"""
                    **🏪 {supplier['name']}**  
                    📍 {supplier['address']}, {supplier['city']} {supplier['postal_code']}  
                    🚚 Délai livraison: {supplier['delivery_time_days']} jours
                    """)
                
                with col_contact:
                    contact_info = []
                    if supplier['contact_person']:
                        contact_info.append(f"👤 {supplier['contact_person']}")
                    if supplier['phone']:
                        contact_info.append(f"📞 {supplier['phone']}")
                    if supplier['email']:
                        contact_info.append(f"📧 {supplier['email']}")
                    
                    if contact_info:
                        st.markdown("  \n".join(contact_info))
                
                with col_rating:
                    rating_stars = "⭐" * int(supplier['rating']) + "☆" * (5 - int(supplier['rating']))
                    st.markdown(f"**{rating_stars}**  \n{supplier['rating']:.1f}/5")
                
                st.markdown("---")
    
    def _render_add_supplier_form(self):
        """Formulaire d'ajout de fournisseur."""
        with st.form("add_supplier_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                name = st.text_input("Nom du fournisseur *", placeholder="Ex: Béton Provincial")
                contact_person = st.text_input("Personne contact", placeholder="Ex: Marie Tremblay")
                phone = st.text_input("Téléphone", placeholder="Ex: 418-123-4567")
                email = st.text_input("Email", placeholder="Ex: contact@fournisseur.ca")
            
            with col2:
                address = st.text_input("Adresse", placeholder="Ex: 123 Rue Industrielle")
                
                col_city, col_postal = st.columns(2)
                with col_city:
                    city = st.text_input("Ville", value="Québec")
                with col_postal:
                    postal_code = st.text_input("Code postal", placeholder="G1A 1A1")
                
                rating = st.slider("Évaluation", min_value=0.0, max_value=5.0, value=3.0, step=0.5)
                delivery_time = st.number_input("Délai livraison (jours)", min_value=1, value=7)
            
            submitted = st.form_submit_button("➕ Ajouter le Fournisseur", use_container_width=True)
            
            if submitted:
                if not name:
                    st.error("Le nom du fournisseur est obligatoire")
                else:
                    try:
                        supplier_id = self.inventory_manager.add_supplier(
                            name=name,
                            contact_person=contact_person,
                            phone=phone,
                            email=email,
                            address=address,
                            city=city,
                            postal_code=postal_code,
                            rating=rating,
                            delivery_time_days=delivery_time
                        )
                        
                        st.success(f"✅ Fournisseur '{name}' ajouté avec succès!")
                        st.rerun()
                        
                    except Exception as e:
                        st.error(f"Erreur lors de l'ajout: {str(e)}")
    
    def _render_purchase_orders(self):
        """Affiche la gestion des commandes d'achat."""
        st.markdown("## 🛒 Commandes d'Achat")
        
        # Bouton pour créer une nouvelle commande
        if st.button("➕ Nouvelle Commande", use_container_width=True):
            st.session_state.inventory_view_mode = 'new_purchase_order'
            st.rerun()
        
        st.markdown("---")
        st.info("🚧 Module en développement - Commandes d'achat à venir")
    
    def _render_ai_predictions(self):
        """Affiche les prédictions IA."""
        st.markdown("## 🤖 Prédictions IA")
        
        st.markdown("### 📊 Analyse Prédictive de Consommation")
        
        # Sélection d'article pour prédiction
        items = self.inventory_manager.get_items()
        if not items:
            st.info("Aucun article disponible pour les prédictions")
            return
        
        col1, col2 = st.columns(2)
        
        with col1:
            selected_item = st.selectbox(
                "Sélectionner un article",
                options=items,
                format_func=lambda x: f"{x['category_icon']} {x['name']}"
            )
        
        with col2:
            prediction_days = st.selectbox(
                "Période de prédiction",
                options=[7, 14, 30, 60, 90],
                format_func=lambda x: f"{x} jours"
            )
        
        if st.button("🔮 Générer Prédiction", use_container_width=True):
            with st.spinner("Analyse en cours..."):
                prediction = self.inventory_manager.predict_consumption(
                    selected_item['id'], 
                    prediction_days
                )
                
                # Affichage des résultats
                col_pred, col_conf, col_suggest = st.columns(3)
                
                with col_pred:
                    st.metric(
                        "📉 Consommation Prédite",
                        f"{prediction['predicted_consumption']} {selected_item['unit']}",
                        help="Quantité prédite pour la période sélectionnée"
                    )
                
                with col_conf:
                    confidence_pct = prediction['confidence'] * 100
                    st.metric(
                        "🎯 Niveau de Confiance",
                        f"{confidence_pct:.0f}%",
                        help="Fiabilité de la prédiction basée sur l'historique"
                    )
                
                with col_suggest:
                    suggestion_icon = "🔴" if prediction['reorder_suggestion'] else "🟢"
                    suggestion_text = "Réapprovisionnement recommandé" if prediction['reorder_suggestion'] else "Stock suffisant"
                    st.metric(
                        "💡 Recommandation",
                        suggestion_text,
                        help="Suggestion basée sur la prédiction"
                    )
                
                # Facteurs considérés
                st.markdown("### 🔍 Facteurs Analysés")
                for factor in prediction['factors']:
                    st.write(f"• {factor}")
        
        st.markdown("---")
        
        # Lien vers les suggestions
        if st.button("💡 Voir Toutes les Suggestions IA", use_container_width=True):
            st.session_state.inventory_view_mode = 'reorder_suggestions'
            st.rerun()
    
    def _render_reorder_suggestions(self):
        """Affiche les suggestions de réapprovisionnement IA."""
        st.markdown("## 💡 Suggestions de Réapprovisionnement IA")
        
        with st.spinner("Analyse intelligente en cours..."):
            suggestions = self.inventory_manager.get_intelligent_reorder_suggestions()
        
        if not suggestions:
            st.success("🎉 Excellent! Aucun réapprovisionnement nécessaire pour le moment.")
            return
        
        st.markdown(f"**{len(suggestions)} suggestion(s) de réapprovisionnement**")
        
        # Grouper par urgence
        high_urgency = [s for s in suggestions if s['urgency'] == 'HIGH']
        medium_urgency = [s for s in suggestions if s['urgency'] == 'MEDIUM']
        low_urgency = [s for s in suggestions if s['urgency'] == 'LOW']
        
        # Urgence élevée
        if high_urgency:
            st.markdown("### 🔴 Urgence Élevée")
            for suggestion in high_urgency:
                self._render_suggestion_card(suggestion, "danger")
        
        # Urgence moyenne
        if medium_urgency:
            st.markdown("### 🟡 Urgence Moyenne")
            for suggestion in medium_urgency:
                self._render_suggestion_card(suggestion, "warning")
        
        # Urgence faible
        if low_urgency:
            st.markdown("### 🟢 Urgence Faible")
            for suggestion in low_urgency:
                self._render_suggestion_card(suggestion, "info")
    
    def _render_suggestion_card(self, suggestion, alert_type):
        """Affiche une carte de suggestion."""
        item = suggestion['item']
        predicted_qty = suggestion['suggested_quantity']
        prediction = suggestion['prediction']
        
        urgency_colors = {
            "danger": "#fee2e2",
            "warning": "#fef3c7", 
            "info": "#dbeafe"
        }
        
        urgency_borders = {
            "danger": "#ef4444",
            "warning": "#f59e0b",
            "info": "#3b82f6"
        }
        
        with st.container():
            st.markdown(f"""
            <div style="
                border-left: 4px solid {urgency_borders[alert_type]};
                padding: 15px;
                margin: 10px 0;
                background-color: {urgency_colors[alert_type]};
                border-radius: 0 8px 8px 0;
            ">
                <h4>{item['category_icon']} {item['name']}</h4>
                <p><strong>Stock actuel:</strong> {item['current_stock']} {item['unit']} | 
                   <strong>Stock minimum:</strong> {item['minimum_stock']} {item['unit']}</p>
                <p><strong>Quantité suggérée:</strong> {predicted_qty} {item['unit']}</p>
                <p><strong>Fournisseur:</strong> {item['supplier_name'] or 'Non défini'}</p>
                <p><strong>Coût estimé:</strong> {predicted_qty * item['unit_cost']:.2f} $</p>
                <p><strong>Confiance IA:</strong> {prediction['confidence'] * 100:.0f}%</p>
            </div>
            """, unsafe_allow_html=True)
            
            col_action, col_details = st.columns([1, 3])
            
            with col_action:
                if st.button(f"🛒 Commander", key=f"order_{item['id']}", use_container_width=True):
                    st.session_state.selected_item_for_order = item
                    st.session_state.suggested_quantity = predicted_qty
                    st.session_state.inventory_view_mode = 'create_order'
                    st.rerun()
            
            with col_details:
                with st.expander(f"📊 Détails prédiction - {item['name']}", expanded=False):
                    st.write("**Facteurs analysés:**")
                    for factor in prediction['factors']:
                        st.write(f"• {factor}")
                    
                    st.write(f"**Consommation prédite (30j):** {prediction['predicted_consumption']} {item['unit']}")
                    st.write(f"**Recommandation:** {'Réapprovisionnement nécessaire' if prediction['reorder_suggestion'] else 'Stock suffisant'}")
            
            st.markdown("---")
