# database_integration.py
"""
Fichier d'intégration pour connecter le nouveau DatabaseManager 
à l'application Constructo AI existante.
"""

import streamlit as st
from database_manager import DatabaseManager
from datetime import datetime
import hashlib
import time

class ConstructoAIIntegration:
    """Classe d'intégration pour connecter DatabaseManager à Streamlit."""
    
    def __init__(self):
        self.db = None
        self.current_user_id = None
        self.init_database()
    
    def init_database(self):
        """Initialise la connexion à la base de données."""
        try:
            self.db = DatabaseManager("constructo_ai.db")
            
            # Initialiser l'utilisateur par défaut si nécessaire
            if 'user_id' not in st.session_state:
                # Pour une version simple, on utilise un utilisateur par défaut
                # En production, ceci serait remplacé par un vrai système d'auth
                default_user = self.db.get_user(username="default_user")
                if not default_user:
                    user_id = self.db.create_user(
                        username="default_user",
                        email="user@constructoai.ca",
                        full_name="Utilisateur Constructo AI",
                        role="user"
                    )
                    st.session_state.user_id = user_id
                else:
                    st.session_state.user_id = default_user['id']
                
                # Mettre à jour la dernière connexion
                self.db.update_user_last_login(st.session_state.user_id)
            
            self.current_user_id = st.session_state.user_id
            
            # Enregistrer l'activité de connexion
            self.db.log_activity(
                user_id=self.current_user_id,
                action_type="app_opened",
                description="Application Constructo AI ouverte"
            )
            
        except Exception as e:
            st.error(f"Erreur d'initialisation de la base de données: {e}")
            self.db = None
    
    def log_conversation_start(self, expert_profile_name: str) -> int:
        """Démarre une nouvelle conversation dans la DB."""
        try:
            if not self.db:
                return None
            
            with self.db._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                # Générer un titre basé sur l'heure et l'expert
                title = f"Consultation {expert_profile_name} - {datetime.now().strftime('%d/%m/%Y %H:%M')}"
                
                cursor.execute("""
                    INSERT INTO conversations 
                    (user_id, title, expert_profile_id, conversation_type, created_at, last_updated_at)
                    VALUES (?, ?, ?, 'chat', ?, ?)
                """, (self.current_user_id, title, expert_profile_name, now, now))
                
                conversation_id = cursor.lastrowid
                
                # Log de l'activité
                self.db.log_activity(
                    user_id=self.current_user_id,
                    action_type="conversation_started",
                    resource_type="conversation",
                    resource_id=conversation_id,
                    description=f"Nouvelle conversation avec {expert_profile_name}",
                    expert_profile=expert_profile_name
                )
                
                return conversation_id
                
        except Exception as e:
            print(f"Erreur lors de la création de la conversation: {e}")
            return None
    
    def save_message_to_db(self, conversation_id: int, role: str, content: str, 
                          expert_profile: str = None, response_time: float = None):
        """Sauvegarde un message dans la base de données."""
        try:
            if not self.db or not conversation_id:
                return
            
            with self.db._connect() as conn:
                cursor = conn.cursor()
                now = datetime.now().isoformat()
                
                # Calculer le hash du contenu
                content_hash = hashlib.md5(content.encode()).hexdigest()
                
                # Estimer le nombre de tokens (approximation)
                token_count = len(content.split())
                
                cursor.execute("""
                    INSERT INTO messages 
                    (conversation_id, role, content, content_hash, expert_profile_used, 
                     token_count, response_time, created_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (conversation_id, role, content, content_hash, expert_profile,
                      token_count, response_time, now))
                
                # Mettre à jour le compteur de messages de la conversation
                cursor.execute("""
                    UPDATE conversations 
                    SET message_count = message_count + 1, 
                        total_tokens = total_tokens + ?,
                        last_updated_at = ?
                    WHERE id = ?
                """, (token_count, now, conversation_id))
                
                # Enregistrer statistique d'utilisation
                if role == "assistant" and expert_profile:
                    self.db.record_usage_statistic(
                        metric_type="expert_usage",
                        metric_name="message_generated",
                        value=1,
                        user_id=self.current_user_id,
                        expert_profile_id=expert_profile,
                        token_count=token_count,
                        response_time=response_time
                    )
                
        except Exception as e:
            print(f"Erreur lors de la sauvegarde du message: {e}")
    
    def cache_search_result(self, query: str, results: str, expert_profile: str = None):
        """Met en cache un résultat de recherche web."""
        try:
            if not self.db:
                return
            
            self.db.cache_web_search(
                query=query,
                results=results,
                user_id=self.current_user_id,
                expert_profile_id=expert_profile,
                cache_hours=24
            )
            
            # Enregistrer statistique
            self.db.record_usage_statistic(
                metric_type="search_usage",
                metric_name="web_search_performed",
                value=1,
                user_id=self.current_user_id,
                expert_profile_id=expert_profile,
                query=query
            )
            
        except Exception as e:
            print(f"Erreur lors de la mise en cache de la recherche: {e}")
    
    def get_cached_search(self, query: str) -> str:
        """Récupère un résultat de recherche en cache."""
        try:
            if not self.db:
                return None
            
            cached_result = self.db.get_cached_search(query)
            
            if cached_result:
                # Enregistrer statistique de cache hit
                self.db.record_usage_statistic(
                    metric_type="search_usage",
                    metric_name="cache_hit",
                    value=1,
                    user_id=self.current_user_id,
                    query=query
                )
            
            return cached_result
            
        except Exception as e:
            print(f"Erreur lors de la récupération du cache: {e}")
            return None
    
    def save_document_upload(self, filename: str, file_content: bytes, 
                           conversation_id: int = None, project_id: int = None):
        """Sauvegarde un document uploadé."""
        try:
            if not self.db:
                return None
            
            # Calculer le hash du fichier
            file_hash = hashlib.md5(file_content).hexdigest()
            file_size = len(file_content)
            
            # Déterminer le type de fichier
            file_type = filename.split('.')[-1].lower() if '.' in filename else 'unknown'
            
            # Pour cet exemple, on sauvegarde juste les métadonnées
            # En production, on sauvegarderait le fichier sur disque ou cloud
            doc_id = self.db.save_document(
                filename=filename,
                file_path=f"uploads/{file_hash}_{filename}",
                file_size=file_size,
                file_type=file_type,
                file_hash=file_hash,
                user_id=self.current_user_id,
                project_id=project_id,
                conversation_id=conversation_id
            )
            
            return doc_id
            
        except Exception as e:
            print(f"Erreur lors de la sauvegarde du document: {e}")
            return None
    
    def update_document_analysis_result(self, doc_id: int, analysis_summary: str):
        """Met à jour le résultat d'analyse d'un document."""
        try:
            if not self.db:
                return
            
            self.db.update_document_analysis(
                doc_id=doc_id,
                analysis_summary=analysis_summary,
                analysis_metadata={
                    "analyzed_at": datetime.now().isoformat(),
                    "analysis_length": len(analysis_summary),
                    "user_id": self.current_user_id
                }
            )
            
            # Log de l'activité
            self.db.log_activity(
                user_id=self.current_user_id,
                action_type="document_analyzed",
                resource_type="document",
                resource_id=doc_id,
                description=f"Document analysé avec succès"
            )
            
        except Exception as e:
            print(f"Erreur lors de la mise à jour de l'analyse: {e}")
    
    def cache_expert_profiles(self, profile_manager):
        """Met en cache tous les profils experts dans la DB."""
        try:
            if not self.db or not profile_manager:
                return
            
            profile_names = profile_manager.get_profile_names()
            
            for profile_name in profile_names:
                profile_data = profile_manager.get_profile_by_name(profile_name)
                if profile_data:
                    self.db.cache_expert_profile(
                        profile_id=profile_data.get('id', profile_name),
                        name=profile_data.get('name', profile_name),
                        content=profile_data.get('content', ''),
                        specialty=profile_data.get('specialty', ''),
                        file_path=profile_data.get('file_path', '')
                    )
            
            print(f"Mise en cache de {len(profile_names)} profils experts")
            
        except Exception as e:
            print(f"Erreur lors de la mise en cache des profils: {e}")
    
    def get_dashboard_analytics(self) -> dict:
        """Récupère les analytics pour le tableau de bord."""
        try:
            if not self.db:
                return {}
            
            # Statistiques générales
            db_stats = self.db.get_database_stats()
            
            # Profils experts les plus utilisés
            expert_stats = self.db.get_expert_profiles_stats()
            top_experts = sorted(expert_stats, key=lambda x: x['usage_count'], reverse=True)[:5]
            
            # Activité récente de l'utilisateur
            recent_activity = self.db.get_user_activity(self.current_user_id, limit=10)
            
            # Statistiques d'utilisation récentes
            recent_stats = self.db.get_usage_statistics(
                start_date=(datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d"),
                limit=50
            )
            
            return {
                "database_stats": db_stats,
                "top_experts": top_experts,
                "recent_activity": recent_activity,
                "usage_statistics": recent_stats,
                "user_id": self.current_user_id
            }
            
        except Exception as e:
            print(f"Erreur lors de la récupération des analytics: {e}")
            return {}
    
    def cleanup_and_optimize(self):
        """Nettoie et optimise la base de données."""
        try:
            if not self.db:
                return
            
            # Nettoyer le cache expiré
            self.db.clean_expired_cache()
            
            # Optimiser la base de données (à faire périodiquement)
            self.db.optimize_database()
            
            # Log de l'activité de maintenance
            self.db.log_activity(
                user_id=self.current_user_id,
                action_type="database_maintenance",
                description="Nettoyage et optimisation de la base de données"
            )
            
        except Exception as e:
            print(f"Erreur lors du nettoyage/optimisation: {e}")


# ===============================
# FONCTIONS D'INTÉGRATION STREAMLIT
# ===============================

def init_database_for_app():
    """Initialise la base de données pour l'application Streamlit."""
    if 'db_integration' not in st.session_state:
        st.session_state.db_integration = ConstructoAIIntegration()
    
    return st.session_state.db_integration

def track_expert_usage(expert_profile_name: str, success: bool = True):
    """Enregistre l'utilisation d'un profil expert."""
    if 'db_integration' in st.session_state and st.session_state.db_integration.db:
        st.session_state.db_integration.db.increment_profile_usage(
            profile_id=expert_profile_name,
            success=success
        )

def track_user_action(action_type: str, description: str = "", **kwargs):
    """Enregistre une action utilisateur."""
    if 'db_integration' in st.session_state:
        db_integration = st.session_state.db_integration
        if db_integration.db:
            db_integration.db.log_activity(
                user_id=db_integration.current_user_id,
                action_type=action_type,
                description=description,
                **kwargs
            )

def get_performance_metrics():
    """Récupère les métriques de performance pour affichage."""
    if 'db_integration' in st.session_state:
        return st.session_state.db_integration.get_dashboard_analytics()
    return {}

# ===============================
# EXEMPLES D'UTILISATION
# ===============================

def example_integration_in_app():
    """
    Exemple d'intégration dans app.py
    
    Ajoutez ces modifications à votre app.py existant :
    """
    
    # ===== DÉBUT DE L'APPLICATION =====
    # À ajouter après l'initialisation des autres managers
    db_integration = init_database_for_app()
    
    # ===== LORS DU CHANGEMENT DE PROFIL EXPERT =====
    # À ajouter quand l'utilisateur change de profil
    if selected_profile != st.session_state.get("selected_profile_name"):
        # Votre code existant...
        
        # NOUVEAU : Mettre en cache les profils experts
        db_integration.cache_expert_profiles(st.session_state.profile_manager)
        
        # NOUVEAU : Tracker l'usage du profil
        track_expert_usage(selected_profile, success=True)
        
        # NOUVEAU : Logger l'action
        track_user_action(
            action_type="profile_changed",
            description=f"Changement vers profil {selected_profile}",
            old_profile=st.session_state.get("selected_profile_name"),
            new_profile=selected_profile
        )
    
    # ===== LORS D'UNE RECHERCHE WEB =====
    # À modifier dans votre logique de recherche existante
    def enhanced_web_search(query: str, expert_profile: str):
        # NOUVEAU : Vérifier le cache d'abord
        cached_result = db_integration.get_cached_search(query)
        if cached_result:
            st.info("Résultat récupéré du cache")
            return cached_result
        
        # Votre logique de recherche existante
        search_result = st.session_state.expert_advisor.perform_web_search(query)
        
        # NOUVEAU : Mettre en cache le résultat
        db_integration.cache_search_result(query, search_result, expert_profile)
        
        return search_result
    
    # ===== LORS DE L'ANALYSE DE DOCUMENTS =====
    # À modifier dans votre logique d'analyse existante
    def enhanced_document_analysis(uploaded_files, conversation_id):
        for uploaded_file in uploaded_files:
            # NOUVEAU : Sauvegarder les métadonnées du document
            doc_id = db_integration.save_document_upload(
                filename=uploaded_file.name,
                file_content=uploaded_file.getvalue(),
                conversation_id=conversation_id
            )
            
            # Votre logique d'analyse existante
            analysis_result = st.session_state.expert_advisor.analyze_documents([uploaded_file], [])
            
            # NOUVEAU : Sauvegarder le résultat d'analyse
            if doc_id:
                db_integration.update_document_analysis_result(doc_id, analysis_result[0])
    
    # ===== SIDEBAR AVEC ANALYTICS =====
    # À ajouter dans votre sidebar
    with st.sidebar:
        st.markdown("---")
        st.markdown("### 📊 Analytics")
        
        if st.button("Voir Statistiques"):
            analytics = get_performance_metrics()
            
            if analytics:
                st.markdown("#### Base de Données")
                db_stats = analytics.get("database_stats", {})
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Conversations", db_stats.get("conversations_count", 0))
                with col2:
                    st.metric("Messages", db_stats.get("messages_count", 0))
                
                st.markdown("#### Experts Populaires")
                top_experts = analytics.get("top_experts", [])
                for expert in top_experts[:3]:
                    st.caption(f"🏗️ {expert['name']}: {expert['usage_count']} utilisations")
        
        # Bouton de maintenance (admin uniquement en production)
        if st.button("🔧 Optimiser DB"):
            with st.spinner("Optimisation..."):
                db_integration.cleanup_and_optimize()
            st.success("Base de données optimisée!")

# ===============================
# MODIFICATIONS RECOMMANDÉES POUR APP.PY
# ===============================

"""
ÉTAPES D'INTÉGRATION :

1. Ajoutez ces imports en haut de app.py :
   from database_integration import init_database_for_app, track_expert_usage, track_user_action

2. Initialisez la DB après vos autres managers :
   db_integration = init_database_for_app()

3. Trackez les actions importantes :
   - Changements de profil expert
   - Recherches web (avec cache)
   - Analyses de documents
   - Création/modification de projets

4. Ajoutez des analytics dans la sidebar

5. Optionnel : Migration des données existantes
   - Conversations depuis conversation_manager.py
   - Projets depuis project_manager.py

6. Tests et validation
   - Vérifiez que toutes les fonctionnalités existantes marchent
   - Testez les nouvelles fonctionnalités analytics
   - Optimisez les performances si nécessaire
"""