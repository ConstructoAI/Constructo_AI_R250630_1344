# knowledge_base_ui.py - Interface de Gestion Base de Connaissances

import streamlit as st
import json
from datetime import datetime
from typing import Dict, List, Optional
import io
import hashlib

class KnowledgeBaseUI:
    """Interface utilisateur pour la gestion de la base de connaissances personnalisée."""
    
    def __init__(self, db_manager, expert_advisor):
        self.db = db_manager
        self.expert_advisor = expert_advisor
        
        # Initialiser les variables de session
        if 'kb_view_mode' not in st.session_state:
            st.session_state.kb_view_mode = 'dashboard'
        if 'current_profile_edit_id' not in st.session_state:
            st.session_state.current_profile_edit_id = None
        if 'kb_search_query' not in st.session_state:
            st.session_state.kb_search_query = ""

    def render_knowledge_base_section(self):
        """Rend la section complète de gestion de la base de connaissances."""
        
        st.markdown("""
        <div class="project-header">
            <h2>🧠 Base de Connaissances Personnalisée</h2>
            <p>Créez vos propres experts IA avec vos documents et expertise</p>
        </div>
        """, unsafe_allow_html=True)
        
        # Menu de navigation
        cols = st.columns(6)
        
        with cols[0]:
            if st.button("🏠 Tableau de Bord", use_container_width=True):
                st.session_state.kb_view_mode = 'dashboard'
                st.rerun()
        
        with cols[1]:
            if st.button("👤 Mes Profils", use_container_width=True):
                st.session_state.kb_view_mode = 'profiles'
                st.rerun()
        
        with cols[2]:
            if st.button("➕ Créer Profil", use_container_width=True):
                st.session_state.kb_view_mode = 'create_profile'
                st.rerun()
        
        with cols[3]:
            if st.button("📚 Bibliothèque", use_container_width=True):
                st.session_state.kb_view_mode = 'library'
                st.rerun()
        
        with cols[4]:
            if st.button("🔍 Rechercher", use_container_width=True):
                st.session_state.kb_view_mode = 'search'
                st.rerun()
        
        with cols[5]:
            if st.button("🤝 Partagés", use_container_width=True):
                st.session_state.kb_view_mode = 'shared'
                st.rerun()
        
        st.divider()
        
        # Rendu selon le mode
        if st.session_state.kb_view_mode == 'dashboard':
            self.render_dashboard()
        elif st.session_state.kb_view_mode == 'profiles':
            self.render_profiles_list()
        elif st.session_state.kb_view_mode == 'create_profile':
            self.render_create_profile()
        elif st.session_state.kb_view_mode == 'edit_profile':
            self.render_edit_profile()
        elif st.session_state.kb_view_mode == 'library':
            self.render_library()
        elif st.session_state.kb_view_mode == 'search':
            self.render_search()
        elif st.session_state.kb_view_mode == 'shared':
            self.render_shared_profiles()

    def render_dashboard(self):
        """Tableau de bord de la base de connaissances."""
        st.markdown("### 🏠 Tableau de Bord")
        
        # Récupérer les statistiques
        user_id = self.get_current_user_id()
        if not user_id:
            st.error("Utilisateur non identifié")
            return
        
        profiles = self.db.get_user_custom_profiles(user_id)
        
        # Métriques principales
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            total_profiles = len([p for p in profiles if not p.get('is_shared')])
            st.metric("Mes Profils", total_profiles)
        
        with col2:
            shared_profiles = len([p for p in profiles if p.get('is_shared')])
            st.metric("Profils Partagés", shared_profiles)
        
        with col3:
            # Compter les documents
            total_docs = 0
            for profile in profiles:
                docs = self.db.get_profile_documents(profile['id'])
                total_docs += len(docs)
            st.metric("Documents", total_docs)
        
        with col4:
            # Usage total
            total_usage = sum(p.get('usage_count', 0) for p in profiles)
            st.metric("Utilisations", total_usage)
        
        st.divider()
        
        # Profils récents
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("#### 📈 Profils les Plus Utilisés")
            sorted_profiles = sorted(profiles, key=lambda x: x.get('usage_count', 0), reverse=True)
            
            for profile in sorted_profiles[:5]:
                usage = profile.get('usage_count', 0)
                rating = profile.get('rating', 0.0)
                st.markdown(f"""
                <div class="info-card">
                    <strong>👤 {profile['display_name']}</strong><br>
                    <small>Utilisations: {usage} • Note: ⭐{rating:.1f}</small>
                </div>
                """, unsafe_allow_html=True)
        
        with col2:
            st.markdown("#### 🕒 Activité Récente")
            recent_profiles = sorted(profiles, key=lambda x: x['updated_at'], reverse=True)
            
            for profile in recent_profiles[:5]:
                updated = profile['updated_at'][:10]
                st.markdown(f"""
                <div class="info-card">
                    <strong>👤 {profile['display_name']}</strong><br>
                    <small>Modifié: {updated} • Catégorie: {profile.get('category', 'Custom')}</small>
                </div>
                """, unsafe_allow_html=True)

    def render_profiles_list(self):
        """Liste des profils personnalisés."""
        st.markdown("### 👤 Mes Profils Personnalisés")
        
        user_id = self.get_current_user_id()
        if not user_id:
            st.error("Utilisateur non identifié")
            return
        
        # Filtres
        col1, col2, col3 = st.columns([2, 2, 1])
        
        with col1:
            category_filter = st.selectbox(
                "Catégorie:",
                ["Toutes", "custom", "technique", "business", "specialise"],
                key="kb_category_filter"
            )
        
        with col2:
            search_term = st.text_input(
                "Rechercher:",
                placeholder="Nom ou spécialité...",
                key="kb_search_profiles"
            )
        
        with col3:
            if st.button("🔄 Actualiser", use_container_width=True):
                st.rerun()
        
        # Récupérer les profils
        profiles = self.db.get_user_custom_profiles(user_id, include_shared=False)
        
        # Appliquer les filtres
        if category_filter != "Toutes":
            profiles = [p for p in profiles if p.get('category') == category_filter]
        
        if search_term:
            profiles = [p for p in profiles if 
                       search_term.lower() in p['display_name'].lower() or
                       search_term.lower() in p.get('specialty', '').lower()]
        
        if not profiles:
            st.info("Aucun profil trouvé. Créez votre premier profil personnalisé !")
            if st.button("➕ Créer Mon Premier Profil", type="primary"):
                st.session_state.kb_view_mode = 'create_profile'
                st.rerun()
            return
        
        # Affichage des profils
        for profile in profiles:
            with st.container():
                col1, col2, col3, col4 = st.columns([4, 1, 1, 1])
                
                with col1:
                    tags = json.loads(profile.get('tags', '[]'))
                    tags_str = " ".join([f"#{tag}" for tag in tags[:3]])
                    
                    visibility = "🔒 Privé" if not profile.get('is_public') else "🌐 Public"
                    
                    st.markdown(f"""
                    <div class="project-card">
                        <h4>👤 {profile['display_name']}</h4>
                        <p><strong>Spécialité:</strong> {profile.get('specialty', 'Non spécifiée')}</p>
                        <p>{profile.get('description', 'Aucune description')}</p>
                        <p><strong>Visibilité:</strong> {visibility} • <strong>Utilisations:</strong> {profile.get('usage_count', 0)}</p>
                        <p><small>Tags: {tags_str} • Créé: {profile['created_at'][:10]}</small></p>
                    </div>
                    """, unsafe_allow_html=True)
                
                with col2:
                    if st.button("📝 Éditer", key=f"edit_profile_{profile['id']}", use_container_width=True):
                        st.session_state.current_profile_edit_id = profile['id']
                        st.session_state.kb_view_mode = 'edit_profile'
                        st.rerun()
                
                with col3:
                    if st.button("🔗 Utiliser", key=f"use_profile_{profile['id']}", use_container_width=True):
                        self.load_custom_profile_as_expert(profile)
                
                with col4:
                    if st.button("🗑️ Supprimer", key=f"delete_profile_{profile['id']}", use_container_width=True):
                        if st.session_state.get(f'confirm_delete_profile_{profile["id"]}', False):
                            self.db.delete_custom_profile(profile['id'], user_id)
                            st.success(f"Profil '{profile['display_name']}' supprimé.")
                            st.rerun()
                        else:
                            st.session_state[f'confirm_delete_profile_{profile["id"]}'] = True
                            st.warning("Cliquez à nouveau pour confirmer.")
                
                st.divider()

    def render_create_profile(self):
        """Formulaire de création d'un nouveau profil."""
        st.markdown("### ➕ Créer un Nouveau Profil Expert")
        
        with st.form("create_custom_profile"):
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### 📋 Informations Générales")
                profile_name = st.text_input(
                    "Nom du profil (identifiant) *",
                    placeholder="ex: expert_renovation_patrimoniale",
                    help="Nom technique sans espaces"
                )
                display_name = st.text_input(
                    "Nom d'affichage *",
                    placeholder="ex: Expert en Rénovation Patrimoniale"
                )
                specialty = st.text_input(
                    "Spécialité",
                    placeholder="ex: Rénovation de bâtiments historiques"
                )
                category = st.selectbox(
                    "Catégorie",
                    ["custom", "technique", "business", "specialise", "consultant"]
                )
            
            with col2:
                st.markdown("#### 🏷️ Métadonnées")
                description = st.text_area(
                    "Description courte",
                    placeholder="Décrivez brièvement l'expertise de ce profil...",
                    height=100
                )
                tags_input = st.text_input(
                    "Tags (séparés par des virgules)",
                    placeholder="rénovation, patrimoine, historique"
                )
                is_public = st.checkbox(
                    "Profil public (visible par d'autres utilisateurs)",
                    help="Si coché, ce profil pourra être découvert par d'autres"
                )
            
            st.markdown("#### 🧠 Contenu du Profil Expert")
            st.markdown("*Définissez ici l'expertise, la personnalité et les connaissances de votre expert IA*")
            
            profile_content = st.text_area(
                "Contenu du profil expert *",
                placeholder="""Exemple:
Je suis un expert en rénovation de bâtiments patrimoniaux avec 25 ans d'expérience au Québec.

MES EXPERTISES:
- Analyse structurelle des bâtiments historiques
- Conformité patrimoine et municipal
- Matériaux d'époque et techniques traditionnelles
- Subventions gouvernementales patrimoniales

JE PEUX T'AIDER AVEC:
- Évaluation de faisabilité de rénovation
- Plans et devis respectueux du patrimoine
- Négociation avec les instances patrimoniales
- Estimation coûts spécialisés

MA MÉTHODE:
Je commence toujours par une analyse historique du bâtiment, puis j'évalue les contraintes patrimoniales avant de proposer des solutions techniques appropriées.""",
                height=300,
                help="Plus le contenu est détaillé et spécifique, plus l'expert sera performant"
            )
            
            # Upload de documents
            st.markdown("#### 📄 Documents de Base (Optionnel)")
            uploaded_files = st.file_uploader(
                "Ajoutez des documents pour enrichir la base de connaissances",
                accept_multiple_files=True,
                type=['pdf', 'docx', 'txt', 'csv'],
                help="Ces documents seront analysés et intégrés à l'expertise du profil"
            )
            
            submitted = st.form_submit_button("🚀 Créer le Profil Expert", use_container_width=True)
            
            if submitted:
                if not profile_name or not display_name or not profile_content:
                    st.error("Les champs marqués * sont obligatoires.")
                else:
                    self.create_custom_profile_with_documents(
                        profile_name, display_name, specialty, category,
                        description, tags_input, is_public, profile_content, uploaded_files
                    )

    def render_edit_profile(self):
        """Interface d'édition d'un profil existant."""
        if not st.session_state.current_profile_edit_id:
            st.error("Aucun profil sélectionné pour édition.")
            return
        
        profile_id = st.session_state.current_profile_edit_id
        user_id = self.get_current_user_id()
        
        # Récupérer le profil
        profiles = self.db.get_user_custom_profiles(user_id, include_shared=False)
        profile = next((p for p in profiles if p['id'] == profile_id), None)
        
        if not profile:
            st.error("Profil non trouvé ou non autorisé.")
            return
        
        st.markdown(f"### 📝 Édition: {profile['display_name']}")
        
        # Bouton retour
        if st.button("⬅️ Retour à Mes Profils"):
            st.session_state.kb_view_mode = 'profiles'
            st.session_state.current_profile_edit_id = None
            st.rerun()
        
        # Onglets d'édition
        tab1, tab2, tab3 = st.tabs(["📋 Profil", "📚 Documents", "📊 Statistiques"])
        
        with tab1:
            self.render_profile_edit_form(profile)
        
        with tab2:
            self.render_profile_documents_management(profile_id)
        
        with tab3:
            self.render_profile_statistics(profile_id)

    def render_profile_edit_form(self, profile):
        """Formulaire d'édition du profil."""
        with st.form("edit_profile_form"):
            col1, col2 = st.columns(2)
            
            with col1:
                display_name = st.text_input(
                    "Nom d'affichage", 
                    value=profile['display_name']
                )
                specialty = st.text_input(
                    "Spécialité", 
                    value=profile.get('specialty', '')
                )
                category = st.selectbox(
                    "Catégorie",
                    ["custom", "technique", "business", "specialise", "consultant"],
                    index=["custom", "technique", "business", "specialise", "consultant"].index(
                        profile.get('category', 'custom')
                    )
                )
            
            with col2:
                description = st.text_area(
                    "Description", 
                    value=profile.get('description', ''),
                    height=100
                )
                tags = json.loads(profile.get('tags', '[]'))
                tags_input = st.text_input(
                    "Tags", 
                    value=", ".join(tags)
                )
                is_public = st.checkbox(
                    "Profil public", 
                    value=profile.get('is_public', False)
                )
            
            profile_content = st.text_area(
                "Contenu du profil expert",
                value=profile['profile_content'],
                height=300
            )
            
            if st.form_submit_button("💾 Sauvegarder les Modifications", use_container_width=True):
                updates = {
                    'display_name': display_name,
                    'specialty': specialty,
                    'category': category,
                    'description': description,
                    'tags': [tag.strip() for tag in tags_input.split(',') if tag.strip()],
                    'is_public': is_public,
                    'profile_content': profile_content
                }
                
                user_id = self.get_current_user_id()
                if self.db.update_custom_profile(profile['id'], user_id, updates):
                    st.success("Profil mis à jour avec succès !")
                    st.rerun()
                else:
                    st.error("Erreur lors de la mise à jour.")

    def render_profile_documents_management(self, profile_id):
        """Gestion des documents d'un profil."""
        st.markdown("#### 📚 Documents du Profil")
        
        # Upload de nouveaux documents
        with st.expander("➕ Ajouter des Documents"):
            uploaded_files = st.file_uploader(
                "Sélectionnez des documents",
                accept_multiple_files=True,
                type=['pdf', 'docx', 'txt', 'csv'],
                key=f"upload_docs_{profile_id}"
            )
            
            if uploaded_files and st.button("📤 Traiter et Ajouter", use_container_width=True):
                self.process_and_add_documents(profile_id, uploaded_files)
        
        # Liste des documents existants
        documents = self.db.get_profile_documents(profile_id)
        
        if documents:
            st.markdown("##### 📄 Documents Existants")
            
            for doc in documents:
                col1, col2, col3 = st.columns([6, 2, 1])
                
                with col1:
                    status = "✅ Traité" if doc['is_processed'] else "⏳ En cours"
                    file_size = f"{doc['file_size'] / 1024:.1f} KB" if doc['file_size'] else "N/A"
                    
                    st.markdown(f"""
                    <div class="info-card">
                        <strong>📄 {doc['document_name']}</strong><br>
                        <small>Type: {doc['file_type']} • Taille: {file_size} • Statut: {status}</small><br>
                        <small>Ajouté: {doc['upload_date'][:10]}</small>
                    </div>
                    """, unsafe_allow_html=True)
                
                with col2:
                    if doc['content_summary']:
                        if st.button("👁️ Voir", key=f"view_doc_{doc['id']}", use_container_width=True):
                            with st.expander(f"Contenu: {doc['document_name']}", expanded=True):
                                st.markdown("**Résumé:**")
                                st.write(doc['content_summary'])
                                if doc['content_extracted']:
                                    st.markdown("**Contenu extrait:**")
                                    st.text_area("", value=doc['content_extracted'][:1000] + "...", height=200)
                
                with col3:
                    if st.button("🗑️", key=f"delete_doc_{doc['id']}", help="Supprimer"):
                        # TODO: Implémenter suppression document
                        st.warning("Fonctionnalité à implémenter")
        else:
            st.info("Aucun document ajouté à ce profil.")

    def render_profile_statistics(self, profile_id):
        """Statistiques d'utilisation du profil."""
        st.markdown("#### 📊 Statistiques d'Utilisation")
        
        # TODO: Récupérer les vraies statistiques depuis la DB
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Utilisations Totales", "42")
        
        with col2:
            st.metric("Note Moyenne", "4.8 ⭐")
        
        with col3:
            st.metric("Dernière Utilisation", "Il y a 2 jours")
        
        st.info("Statistiques détaillées en développement...")

    # ===============================
    # MÉTHODES UTILITAIRES
    # ===============================

    def get_current_user_id(self) -> Optional[int]:
        """Récupère l'ID de l'utilisateur actuel."""
        # Adapter selon votre système de session
        return st.session_state.get('user_id', 1)  # Valeur par défaut pour le développement

    def create_custom_profile_with_documents(self, profile_name, display_name, specialty, 
                                           category, description, tags_input, is_public, 
                                           profile_content, uploaded_files):
        """Crée un profil personnalisé avec traitement des documents."""
        try:
            user_id = self.get_current_user_id()
            if not user_id:
                st.error("Utilisateur non identifié")
                return
            
            # Préparer les tags
            tags = [tag.strip() for tag in tags_input.split(',') if tag.strip()]
            
            # Données du profil
            profile_data = {
                'profile_name': profile_name,
                'display_name': display_name,
                'specialty': specialty,
                'category': category,
                'description': description,
                'tags': tags,
                'is_public': is_public,
                'profile_content': profile_content
            }
            
            # Créer le profil
            profile_id = self.db.create_custom_profile(user_id, profile_data)
            
            # Traiter les documents si présents
            if uploaded_files:
                with st.spinner("Traitement des documents..."):
                    self.process_and_add_documents(profile_id, uploaded_files)
            
            st.success(f"✅ Profil '{display_name}' créé avec succès !")
            
            # Proposer de l'utiliser immédiatement
            if st.button("🔗 Utiliser ce Profil Maintenant"):
                # Charger le profil créé
                profiles = self.db.get_user_custom_profiles(user_id)
                new_profile = next((p for p in profiles if p['id'] == profile_id), None)
                if new_profile:
                    self.load_custom_profile_as_expert(new_profile)
            
            # Retourner à la liste
            st.session_state.kb_view_mode = 'profiles'
            st.rerun()
            
        except Exception as e:
            st.error(f"Erreur lors de la création: {e}")

    def process_and_add_documents(self, profile_id, uploaded_files):
        """Traite et ajoute des documents à un profil."""
        try:
            user_id = self.get_current_user_id()
            
            for uploaded_file in uploaded_files:
                # Lire le contenu du fichier
                file_content = self.expert_advisor.read_file(uploaded_file)
                
                if isinstance(file_content, str) and file_content.startswith("Erreur"):
                    st.warning(f"Erreur traitement {uploaded_file.name}: {file_content}")
                    continue
                
                # Préparer les données du document
                document_data = {
                    'document_name': uploaded_file.name,
                    'file_type': uploaded_file.name.split('.')[-1].lower(),
                    'file_size': uploaded_file.size,
                    'content_extracted': str(file_content) if isinstance(file_content, str) else '',
                    'content_summary': self.generate_content_summary(str(file_content)[:2000]),
                    'keywords': self.extract_keywords(str(file_content))
                }
                
                # Ajouter à la base
                doc_id = self.db.add_knowledge_document(user_id, profile_id, document_data)
                st.success(f"✅ Document '{uploaded_file.name}' ajouté et traité")
            
        except Exception as e:
            st.error(f"Erreur traitement documents: {e}")

    def generate_content_summary(self, content: str) -> str:
        """Génère un résumé du contenu (simplifié)."""
        # Version simple - en production, utiliser l'IA pour un vrai résumé
        words = content.split()
        if len(words) > 100:
            return " ".join(words[:100]) + "..."
        return content

    def extract_keywords(self, content: str) -> List[str]:
        """Extrait des mots-clés du contenu (simplifié)."""
        # Version simple - en production, utiliser NLP
        words = content.lower().split()
        # Filtrer les mots courts et communs
        keywords = [w for w in words if len(w) > 4 and w.isalpha()]
        # Retourner les plus fréquents (simplifié)
        return list(set(keywords))[:20]

    def load_custom_profile_as_expert(self, profile):
        """Charge un profil personnalisé comme expert actuel."""
        try:
            # Créer un profil temporaire pour l'expert advisor
            custom_profile = {
                'id': f"custom_{profile['id']}",
                'name': profile['display_name'],
                'content': profile['profile_content']
            }
            
            # L'ajouter temporairement au profile manager
            if hasattr(self.expert_advisor, 'profile_manager'):
                profile_manager = self.expert_advisor.profile_manager
                profile_manager.add_profile(
                    custom_profile['id'],
                    custom_profile['name'],
                    custom_profile['content']
                )
                
                # L'activer
                success = self.expert_advisor.set_current_profile_by_name(custom_profile['name'])
                
                if success:
                    st.session_state.selected_profile_name = custom_profile['name']
                    st.success(f"✅ Profil '{profile['display_name']}' activé ! Retour au chat.")
                    
                    # Incrementer l'usage
                    user_id = self.get_current_user_id()
                    updates = {'usage_count': profile.get('usage_count', 0) + 1}
                    self.db.update_custom_profile(profile['id'], user_id, updates)
                    
                    # Revenir au chat principal
                    st.session_state.show_knowledge_base = False
                    st.rerun()
                else:
                    st.error("Erreur lors de l'activation du profil")
            else:
                st.error("Profile manager non disponible")
                
        except Exception as e:
            st.error(f"Erreur chargement profil: {e}")

    def render_library(self):
        """Bibliothèque de tous les documents."""
        st.markdown("### 📚 Bibliothèque de Documents")
        st.info("Fonctionnalité en développement - Vue d'ensemble de tous les documents")

    def render_search(self):
        """Interface de recherche dans la base de connaissances."""
        st.markdown("### 🔍 Recherche dans la Base de Connaissances")
        st.info("Fonctionnalité en développement - Recherche sémantique dans tous les profils et documents")

    def render_shared_profiles(self):
        """Gestion des profils partagés."""
        st.markdown("### 🤝 Profils Partagés")
        st.info("Fonctionnalité en développement - Profils partagés par d'autres utilisateurs")